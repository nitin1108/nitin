<?php
session_start();
if(!isset($_SESSION['username'])||empty($_SESSION['username'])){ 
header("location: login.php");
}?>
<!DOCTYPE html>
<html>
<head>
	<title>User Registration</title>
    
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
     .user-reg{
        margin: 100px 50px 50px 50px;
     }
     .change-margin{
      margin: auto; 
     }
     .button-align{
       margin :0 0 0 80px;

     }
     .bm{
      margin-right:5px;
     }
     
    </style>
</head>
<body>
<nav class='navbar navbar-expand-lg navbar-light bg-light  fixed-top' id='mainNav'>
      <div class='container'>
        <a class='navbar-brand js-scroll-trigger text-primary' href='#'>Add User</a>
      
        <div class='collapse navbar-collapse' id='navbarResponsive'>
          <ul class='navbar-nav ml-auto'>
            <li class='nav-item'>
                <a class=' text-white ' href='index.php'  style='text-decoration:none'><button type="button" class="btn bg-dark bm text-white">View Tabs</button></a>
            </li>
            <li class='nav-item'>
              <a class=' text-white ' href='addcategory.php'  style="text-decoration:none"><button type="button" class="btn bg-success bm text-white"> Add Category</button></a>
            </li>
            <li class='nav-item'>
<a class=' text-white ' href='client_reg_form.php'  style="text-decoration:none">              <button type="button" class="btn bg-primary bm text-white"> Add Client</button></a>
            </li>
            <li class='nav-item'>
               <a class=' text-white ' href='logout.php'  style="text-decoration:none"><button type="button" class="btn bg-danger bm text-white">Logout</button></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
<div class="container">
<div class="col-5 change-margin">
<form action="user_reg.php" method="post" class='user-reg' onsubmit="return validate();">



  <div class='form-group'>
    <label for='username'>User Name</label>
    <input type='text' name='username' class='form-control' id='username' placeholder='Enter Username'>
  </div>
<div class='form-group'>
    <label for='role'>Role</label>
    <input type='text' name='role' class='form-control' id='role' placeholder='Enter Role'>
  </div>
  <div class='form-group'>
  <label for='clientid'>Select Client</label>
<select class="custom-select" name="clientid">
<option hidden>Select Client</option><?php 
	require_once "dbconnect.php";
	$logqry = 'select id,clientname from client';
	$res = mysqli_query($con , $logqry) ;
	$count = mysqli_num_rows($res); 
	while ($row = mysqli_fetch_assoc($res)) {

		?>
		<option value="<?php echo $row["id"]; ?>"><?php  echo $row["clientname"]; ?></option>
    
   <?php  
}
?>
</select> 
</div>
  <div class='form-group'>
    <label for='password'>Password</label>
    <input type='password' name='password' class='form-control' id='password' placeholder='Enter Password'>
  </div>
  <div class='form-group'>
    <label for='enterby'>Entered by</label>
    <input type='text' name='enterby' class='form-control' id='enterby' placeholder='Entered by'>
  </div>
  <div class='button-align'>
  <input type='submit' name='register' id="submit" class='btn btn-success text-white' value='Submit'>
  
  <a href='index.php' class='btn btn-secondary text-white'>Cancel</a>
  
</div>

</form>
<script type="text/javascript">

function validate(){  	
var err=true;
var username = document.getElementById('username').value;
var password = document.getElementById('password').value;
var role = document.getElementById('role').value;
var enterby = document.getElementById('enterby').value;
   if (username==""||password==""||role==""||enterby=="") {
        alert("All fields required");
        err = false;
    }
    return err;
}
</script>
</div>
</div>
<footer class='page-footer font-small  bg-light fixed-bottom'>


  <div class='footer-copyright text-center py-3 text-dark'>Copyright 2018 © :
    <a href='https://eabyas.in' target='_blank' class='text-primary font-weight-bold'>  eAbyas Info Solutions</a>
  </div>


</footer>
</body>
</html>