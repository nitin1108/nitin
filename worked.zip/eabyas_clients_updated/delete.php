
<?php

session_start();
if(!isset($_SESSION['username'])||empty($_SESSION['username'])){ 
header("location: login.php");
}

$uid = $_GET['uid'];
if(!empty($uid))
{
	if(is_numeric($uid))
	{
		// echo $uid;
		require_once "dbconnect.php";
		$delete_qry = "delete from user where id='".$uid."'";
		$delete_res = mysqli_query($con ,$delete_qry) ;
		if($delete_res)
		{
			header("location: index.php");
		}
	}
}

?>