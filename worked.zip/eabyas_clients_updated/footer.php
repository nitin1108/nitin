<?php

$output.='<footer class="page-footer font-small  bg-light   fixed-bottom">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3 text-dark">Copyright 2018 © :
    <a href="https://eabyas.in" target="_blank" class="text-primary font-weight-bold">  eAbyas Info Solutions</a>
  </div>
  <!-- Copyright -->

</footer>';
echo $output;

?>