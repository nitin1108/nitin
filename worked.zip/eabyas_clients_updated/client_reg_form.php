<?php
session_start();
if(!isset($_SESSION['username'])||empty($_SESSION['username'])){ 
header("location: login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Client Registration</title>

	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <style type="text/css">
        .client-reg{
            margin:100px 50px 50px 50px;
        }
        .custom-select{
            margin-bottom: 15px;
        }
        .change-margin{
      margin: 100px auto auto auto; 
     }
     .button-align{
       margin :0 0 0 80px;

     }
     .bm{
      margin-left:5px;
     }
    </style>
	
</head>
<body>
<nav class='navbar navbar-expand-lg navbar-light bg-light  fixed-top' id='mainNav'>
      <div class='container'>
        <a class='navbar-brand js-scroll-trigger text-primary' href='#'>Add Client </a>
      
        <div class='collapse navbar-collapse' id='navbarResponsive'>
          <ul class='navbar-nav ml-auto'>
            <li class='nav-item'>
              <a class=' text-white ' href='index.php'  style="text-decoration:none"><button type="button" class="btn bg-dark text-white bm ">View Tabs</button></a>
            </li>
            <li class='nav-item'>
              <a class=' text-white' href='addcategory.php'  style="text-decoration:none"><button type="button" class="btn bg-success text-white bm ">Add Category</button></a>
            </li>
            <li class='nav-item'>
              <a class=' text-white' href='user_reg_form.php' style="text-decoration:none"><button type="button" class="btn bg-info text-white bm ">Add User</button> </a>
            </li>
            <li class='nav-item'>
              <a class=' text-white' href='logout.php'  style="text-decoration:none"><button type="button" class="btn bg-danger text-white  bm ">Logout</button></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
     <div class='container'> 
     <div class='col-5 change-margin '>  
<form action="client_reg.php" method="post" class='client-reg' onsubmit="return validate();">
<div class='form-group'>
    <label for='clientname'>Client Name</label>
    <input type='text' name='clientname' class='form-control' id='clientname' placeholder='Enter Client Name'>
  </div>
<div class='form-group'>
    <label for='url'>Client URL</label>
    <input type='text' name='url' class='form-control' id='url' placeholder='Enter Client Url'>
  </div>
  <div class='form-group'>
  <label for='categoryid'>Select Category</label>
<select name="categoryid" class="custom-select">
<option hidden>Select Category</option>
<?php 
	require_once "dbconnect.php";
	$cat = 'select id,category_name	from category';
	$res = mysqli_query($con , $cat) ;
	$count = mysqli_num_rows($res); 
	while ($row = mysqli_fetch_assoc($res)) {

		?>
		<option value="<?php echo $row[id]; ?>"><?php  echo $row["category_name"]; ?></option>
    
   <?php  
}
?>
</select> 
</div>
<div class='form-group'>
    <label for='specified'>Specific For</label>
    <input type='text' name='specified' class='form-control' id='specified' placeholder='Specific For'>
  </div>
<div class='button-align'>
<input type='submit' name='register' id="submit" class='btn btn-success text-white' value='Submit'>
  
 <a href='index.php' class='btn btn-secondary text-white'>Cancel</a>
  
</form>
<script type="text/javascript">

function validate(){  	
var err=true;
var clientname = document.getElementById('clientname').value;
var url = document.getElementById('url').value;
var categoryid = document.getElementById('categoryid').value;

   if (clientname==""||url==""||categoryid=="") {
        alert("Client Name , URL , Category are Mandatory");
        err = false;
    }
    return err;
}
</script>
</div>
</div>
<footer class='page-footer font-small  bg-light fixed-bottom'>


  <div class='footer-copyright text-center py-3 text-dark'>Copyright 2018 © :
    <a href='https://eabyas.in' target='_blank' class='text-primary font-weight-bold'>  eAbyas Info Solutions</a>
  </div>


</footer>
</body>
</html>