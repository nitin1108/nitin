
<!DOCTYPE html>
<html>
<head>
	<title>User Registration</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style type="text/css">
		       #nav{
  list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
#nav li {
     float: right;
}
#nav li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}
#nav li a:hover {
    background-color: #111;
}

	</style>
</head>
<body>

<ul id='nav' width='100%'>
            <li ><a href="index.php">View Tabs</a></li>
            <li ><a href="client_reg_form.php">Client Registration</a></li>
            <li ><a href="user_reg_form.php">User Registration</a></li>
            <li ><a href="addcategory.php">Add Category</a></li>
            <li ><a href="logout.php">Logout</a></li>
        </ul>

        <?php

extract($_POST);
if(isset($register))
{
	if(empty($clientname)||empty($url)||empty($categoryid))
	{
		echo "Client Name , URL , Category are Mandatory";
	}
	else{
		
		require_once "dbconnect.php";
		$date = date('m-d-y');
		$sql = 'INSERT into client(clientname , url , categoryid ,specified)
		           values("'.$clientname.'","'.$url.'",'.$categoryid.',"'.$specified.'")';

		if (mysqli_query($con, $sql)) {
		    header("location: index.php");
		} else {
		    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}
}

?>
</body>
</html>