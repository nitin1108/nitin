<?php
session_start();
if(!isset($_SESSION['username'])||empty($_SESSION['username'])){ 
header("location: login.php");
}?>
<html>
<head>
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

<link rel="stylesheet" href="icon.css">
    <style>

.set-height{
  margin-top: 10px;  
  margin-bottom: 10px;  
height: auto !important;

}

.right{
  float: right;
}


    </style> 

<script>

    $(document).ready(function(){
    $( '.jQuery_accordion').accordion({
      collapsible: true,
      active: false,
       
    });
         $( '#dialog-confirm' ).dialog({
        autoOpen: false
    });



$('.del_user').click(function(){
  var uid = $(this).attr('data-value');
  var uid = parseInt(uid);

  var name = $(this).attr('name');
  // alert(name);
  $('.ap').empty();
  $('.ap').append(name+' '+'User');

  
    $( '#dialog-confirm' ).dialog('open');

    $( '#dialog-confirm' ).dialog({
     
      resizable: false,
      height: 'auto',
      width: 400,
      modal: true,
      buttons: {
        'Delete': function() {
          $( this ).dialog( 'close' );
          
          window.location.replace('delete.php?uid='+uid);
        },
        Cancel: function() {
          $( this ).dialog( 'close' );
        }
      }
    });


    });


$('.del_client').click(function(){
  var cid = $(this).attr('data-value');
  var cid = parseInt(cid);
  //alert(typeof x);

 var name = $(this).attr('name');
  // alert(name);
  $('.ap').empty();
  $('.ap').append(name+' '+'Client');

    $( '#dialog-confirm' ).dialog('open');


    $( '#dialog-confirm' ).dialog({
     
      resizable: false,
      height: 'auto',
      width: 400,
      modal: true,
      buttons: {
        'Delete': function() {
          $( this ).dialog( 'close' );
          
          window.location.replace('delete_client.php?cid='+cid);
        },
        Cancel: function() {
          $( this ).dialog( 'close' );
        }
      }
    });


    });

});


  </script>

</head>
<body>
<div class="jQuery_accordion">
 <?php
  $cid = $_GET['id'];
  

     require_once "dbconnect.php";
     $projects = "SELECT id,clientname,url from client where categoryid=$cid";
     $res = mysqli_query($con , $projects) ;
     $output = '';
     while ($row = mysqli_fetch_assoc($res)) {
      $output .= "<h3>";
      $output .= "<span class='left'>".$row['clientname']."</span>";
      $output .= "<span class='right'>".$row['url']."</span>";
      $output .= "</h3>";
      // echo "<p>";
      $data = "SELECT id as uid, role,username,password,entertedby from user where clientid=$row[id]";
       $res1 = mysqli_query($con , $data) ;

    $output .=  "<div class='set-height'>  <table  class='table table-bordered text-center  table-hover  ' >
      <caption class='text-center text-primary' style='caption-side:top'>Client</caption>
      <thead class='bg-dark text-white'><tr>
      <th >Client Name</th>
      <th >URl</th>
      <th colspan='2' >Actions</th>
      </tr></thead><tbody><tr><td>".$row['clientname']."</td>
      <td><a href='".$row['url']."' target='_blank' class='text-info' title='Go To URL'>".$row['url']."</a></td>
      <td><a href='update_client.php?cid=".$row['id']."' class='text-info'><img src='gear.png' height='20px' width='20px' alt='Update' title='Update Client'> </a></a></td>
      <td ><a data-value='".$row['id']."' class='del_client' name='".$row['clientname']."' ><img src='delete.jpeg' height='20px' width='20px' alt='delete' title='Delete Client'></a></td>
      </tr></tbody></table>
      <table  class='table table-bordered text-center  table-hover  ' >
      <caption class='text-center text-primary' style='caption-side:top'>Users</caption>
      <thead class='bg-dark text-white'><tr>
      <th >Role</th>
      <th >Username</th>
      <th >Password</th>
      <th >Entered by</th>
      <th colspan='2' >Actions</th>
      </tr></thead><tbody>";
  
  while ($row1 = mysqli_fetch_assoc($res1)) {
    $output .= "<tr >";
    $output .= "<td >".$row1['role']."</td>";
    $output .= "<td >".$row1['username']."</td>";
    $output .= "<td >".$row1['password']."</td>";
    $output .= "<td >".$row1['entertedby']."</td>";
    $output .= "<td ><a href='updateuser.php?uid=".$row1['uid']."'><img src='gear.png' height='20px' width='20px' alt='Update' title='Update User'> </a></td>";
    $output .= "<td ><a  data-value='".$row1['uid']."' class='del_user' name='".$row1['username']."'><img src='delete.jpeg' height='20px' width='20px' alt='delete' title='Delete User'></a></td>";
    $output .= "</tr>";
   }
   $output .=  "</tbody></table></div>";
      }
      echo $output;
      ?>

</div>

<div id="dialog-confirm" title="Delete Confirmation..!">
  <p ><span class="ui-icon ui-icon-alert" style="float:left; margin:12px 12px 20px 0;"></span>Are You Sure To Delete <span class='ap ' ></span>  Details?</p>
</div>
 
</body>
</html>

