<?php
session_start();
if(!isset($_SESSION['username'])||empty($_SESSION['username'])){ 
header("location: login.php");
}
   $output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>
   
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
    <style>
    .update-form{
      margin-top:100px;

    }
    .change-margin{
      margin: auto; 
     }
     .button-align{
       margin :0 0 0 80px;

     }
     .bm{
      margin-right:5px;
     }
    </style>

    <title>Update Client</title>

 
  </head>
  <body>
  <nav class='navbar navbar-expand-lg navbar-light bg-light  fixed-top' id='mainNav'>
      <div class='container'>
        <a class='navbar-brand js-scroll-trigger text-primary ' href='#'>Update Client</a>
      
        <div class='collapse navbar-collapse' id='navbarResponsive'>
          <ul class='navbar-nav ml-auto'>
            <li class='nav-item'>
              <a class=' text-white' href='index.php' style='text-decoration:none'><button type='button' class='btn bg-dark text-white  bm'>View Tabs</button></a>
            </li>
            <li class='nav-item'>
<a class=' text-white' href='client_reg_form.php' style='text-decoration:none'>              <button type='button' class='btn bg-primary text-white bm'>Add Client</button></a>
            </li>
            <li class='nav-item'>
             <a class=' text-white' href='user_reg_form.php' style='text-decoration:none'> <button type='button' class='btn bg-info text-white bm'>Add User</button></a>
            </li>
            <li class='nav-item'>
              <a class=' text-white' href='addcategory.php' style='text-decoration:none'><button type='button' class='btn bg-success text-white bm'>Add Category</button></a>
            </li>
            <li class='nav-item'>
              <a class=' text-white' href='logout.php' style='text-decoration:none'><button type='button' class='btn bg-danger text-white bm'>Logout</button></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>";
  $cid = $_GET['cid'];


     require_once "dbconnect.php";
     $client = "SELECT c.clientname , c.url , ct.category_name ,c.specified  from client as c
join category as ct on c.categoryid = ct.id where c.id='".$cid."'";
     $res1 = mysqli_query($con , $client) ;

     $output.="<div class='container'><div class='col-4 change-margin '>";
  
     $output.="<form action='' method 
='post' class='update-form'>";

      /*$output.= " <table class='table'>
    <thead class='thead-dark'>
      <tr>
        <th scope='col'>update</th>
        
      </tr>
    </thead>
    <tbody>";*/

     while ($row1 = mysqli_fetch_assoc($res1)) {
   $output.=  "
       <div class='form-group'>
    <label for='clientname'>Client Name</label>
    
  
      <input type='text' name='clientname' class='form-control' id='clientname'
       value='".$row1['clientname']."'>
      </div>
      
      <div class='form-group'>
    <label for='url'>Client URL</label>
    
  
      <input type='text' name='url' class='form-control' id='url' value='".$row1['url']."'>
      </div>
      
   <div class='form-group'>
    <label for='specified'>Specific For</label>
    

 
 <input type='text' name='specified' class='form-control' id='specified' value='".$row1['specified']."'>
      </div>
     ";
   }
    $output.="<div class='form-group'>
    <label for='categoryid'>Select Category</label>
     <select name='categoryid' id='categoryid' class='custom-select'>";

     $selected = 'select ct.id as ctid,ct.category_name from category as ct 
join client as c on c.categoryid=ct.id where c.id="'.$cid.'"';
   $res3 = mysqli_query($con ,  $selected) ; 
    while ($row3 = mysqli_fetch_assoc($res3)) {
     $output.= " <option selected value='". $row3['ctid']."'>". $row3["category_name"]."</option>";
}

    $cat = 'select id,category_name from category';
   $res2 = mysqli_query($con , $cat) ;
   $count = mysqli_num_rows($res2); 
   while ($row2 = mysqli_fetch_assoc($res2)) {
     $output.= " <option value='". $row2['id']."'>". $row2["category_name"]."</option>";
}

  $output.="</select> </div>  
  <div class='button-align'>
<button type='submit' class='btn btn-success text-white' name='update_client'>Update</button>
<a href='index.php' class='btn btn-secondary text-white'>Cancel</a></div>
</form>
";

extract($_POST);
if(isset($update_client))
 {
  if(!empty($url)&&!empty($clientname))
  {
   $update_client_sql =' UPDATE client SET clientname =  "'.$clientname.'",
url =  "'.$url.'" , categoryid ='.$categoryid.' , specified="'.$specified.'" WHERE id ="'.$cid.'"';
    
    $update_client_res = mysqli_query($con ,$update_client_sql) ;
    if($update_client_res)
    {
       header("location: index.php?par='updated'");
    }
  }
  else
  {
     $output.= "Client Name , URL , Category are Mandatory";
  }

}

 $output.="</div></div>
 <footer class='page-footer font-small  bg-light fixed-bottom'>


  <div class='footer-copyright text-center py-3 text-dark'>Copyright 2018 © :
    <a href='https://eabyas.in' target='_blank' class='text-primary font-weight-bold'>  eAbyas Info Solutions</a>
  </div>


</footer>
  </body>
</html>";

echo $output;
  
?>







