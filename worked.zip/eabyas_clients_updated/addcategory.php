<?php
session_start();
if(!isset($_SESSION['username'])||empty($_SESSION['username'])){ 
header("location: login.php");
}

$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>

    <title>Add Category</title>
    <style>
    .category-form{
    	margin-top:100px;
    }
    .change-margin{
      margin: 50px 100px 100px 70px; 
     }
      .button-align{
       margin :0 0 0 80px;

     }
     .bm{
      margin-left:5px;
      }
    </style>
   
  </head>
  <body>
    
    <nav class='navbar navbar-expand-lg navbar-light bg-light   fixed-top' id='mainNav'>
      <div class='container'>
        <a class='navbar-brand js-scroll-trigger text-primary' href='#'>Add Category</a>
      
        <div class='collapse navbar-collapse' id='navbarResponsive'>
          <ul class='navbar-nav ml-auto'>
            <li class='nav-item'>
              <a class=' text-white' href='index.php' style='text-decoration:none'><button type='button' class='btn bg-dark text-white bm' >View Tabs</button></a>
            </li>
            <li class='nav-item'>
               <a class=' text-white' href='client_reg_form.php' style='text-decoration:none'><button type='button' class='btn bg-primary text-white bm'>Add Client </button></a>
            </li>
            <li class='nav-item'>
               <a class=' text-white' href='user_reg_form.php' style='text-decoration:none'><button type='button' class='btn bg-info text-white bm'>Add User</button> </a>
            </li>
            <li class='nav-item'>
               <a class=' text-white' href='logout.php' style='text-decoration:none'><button type='button' class='btn bg-danger text-white bm'>Logout</button></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
 ";
  $output.="<div class='container category-form '><div class='col-4 change-margin '>";
 
  $output .= "<form action='' method='post'>
  <div class='form-group'>
    <label for='category'>Category</label>
    <input type='text' name='category' class='form-control' id='category' placeholder='Enter Category'>
  </div>
   <div class='button-align'>
  <button type='submit' name='addcategory' class='btn btn-success text-white'>Add Category</button>
  
  <a href='index.php' class='btn btn-secondary text-white'>Cancel</a>
  </div>
</form>";

extract($_POST);
  if(isset($addcategory))
  {
    if(!empty($category))
    {
    	require_once "dbconnect.php";
		
		$sql = 'INSERT into category(category_name )
		           values("'.$category.'")';

		if (mysqli_query($con, $sql)) {
		  header("location: index.php");
		} else {
		   $output .= "Error: " . $sql . "<br>" . mysqli_error($conn);
		}

      
     

    }
    else
    {
      $output .="Category cannot be empty";
    }
  }
$output .="</div></div>

<footer class='page-footer font-small  bg-light fixed-bottom'>


  <div class='footer-copyright text-center py-3 text-dark'>Copyright 2018 © :
    <a href='https://eabyas.in' target='_blank' class='text-primary font-weight-bold'>  eAbyas Info Solutions</a>
  </div>


</footer>

  </body>
</html>";
   echo $output;
?>
  

