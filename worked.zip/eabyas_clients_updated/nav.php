<?php
$output.=' ';
   
    $output.='<nav class="navbar navbar-expand-lg navbar-light bg-light  fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger text-primary" href="#">eAbyas Clients</a>
      
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            
            <li class="nav-item">
              <a href="addcategory.php" class="text-white" style="text-decoration:none"><button type="button" class="btn  bg-success text-white bm">Add Category</button></a>
            </li>
            <li class="nav-item">
              <a href="client_reg_form.php" class="text-white" style="text-decoration:none"><button type="button" class="btn  bg-primary text-white bm">Add Client</button></a>
            </li>
            <li class="nav-item">
              <a href="user_reg_form.php" class="text-white" style="text-decoration:none"><button type="button" class="btn bg-info text-white bm">Add User</button></a>
            </li>
            <li class="nav-item">
              <a href="logout.php" class="text-white" style="text-decoration:none"><button type="button" class="btn  bg-danger text-white bm">Logout</button></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>';

    echo $output;

    ?>