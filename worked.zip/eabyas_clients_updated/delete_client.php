
<?php

session_start();
if(!isset($_SESSION['username'])||empty($_SESSION['username'])){ 
header("location: login.php");
}

$cid = $_GET['cid'];

if(!empty($cid))
{
	if(is_numeric($cid))
	{
		// echo $uid;
		require_once "dbconnect.php";
    $delete_client_qry = "delete from client where id='".$cid."'";
		$delete_user_qry = "delete from user where clientid='".$cid."'";
    $delete_client_res = mysqli_query($con ,$delete_client_qry) ;
		$delete_user_res = mysqli_query($con ,$delete_user_qry) ;
		if($delete_client_res && $delete_user_res)
		{
			header("location: index.php");
		}
	}
}

?>