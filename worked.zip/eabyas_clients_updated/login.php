<?php
session_start();
if(isset($_SESSION['username'])&&!empty($_SESSION['username'])){ 
header("location: index.php");
}

$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
    <style>body{margin:50px;}
    .change-margin{
      margin: 150px auto auto auto; 
     }
     .button-center{
      margin :auto auto auto 120px;
     }
    </style>

    <title>Login Form</title>
  </head>
  <body>";
  $output.="<div class='container'><div class='col-md-4 col-sm-4 col-lg-4 change-margin '>";
  $output.=" <h3 class='display-12 text-center' >Admin Login</h3><hr>
  ";
  $output .= "<form action='' method='post'>
  <div class='form-group'>
    <label for='username'>Username</label>
    <input type='text' name='username' class='form-control' id='username' placeholder='Enter Username'>
  </div>
  <div class='form-group'>
    <label for='password'>Password</label>
    <input type='password' name='password' class='form-control' id='password' placeholder='Password'>
  </div>
  <button type='submit' name='login' class='btn btn-success text-white button-center'>Login</button>
  
</form>";
    
  
  extract($_POST);
  if(isset($login))
  {
    if($username=='admin' && $password=='Admin123$')
    {
      
      // Store Session Data
      $_SESSION['username']= $username;
      header("location: index.php");
      // $output .=$_SESSION['username'];

    }
    else
    {
      $output .="Login Failed";
    }
  }
$output .="</div></div>
  </body>
</html>";
   echo $output;
?>
  





    

  



















