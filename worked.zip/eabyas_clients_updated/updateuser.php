<?php
session_start();
if(!isset($_SESSION['username'])||empty($_SESSION['username'])){ 
header("location: login.php");
}
   $output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>
    <!-- Required meta tags -->
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

    <!-- Bootstrap CSS -->
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
    <style>
    .update-form{
      margin-top:100px;

    }
    .change-margin{
      margin: auto; 
     }
     .button-align{
       margin :0 0 0 80px;

     }
     .bm{
      margin-right:5px;
     }
    </style>

    <title>Update User</title>

 
  </head>
  <body>
   <nav class='navbar navbar-expand-lg navbar-light bg-light  fixed-top' id='mainNav'>
      <div class='container'>
        <a class='navbar-brand js-scroll-trigger text-primary' href='#'>Update User</a>
      
        <div class='collapse navbar-collapse' id='navbarResponsive'>
          <ul class='navbar-nav ml-auto'>
            <li class='nav-item'>
             <a class=' text-white' href='index.php' style='text-decoration:none'><button type='button' class='btn bg-dark bm text-white'>View Tabs</button></a>
            </li>
            <li class='nav-item'>
              <a class=' text-white' href='user_reg_form.php' style='text-decoration:none'><button type='button' class='btn bg-info bm text-white'>Add User</button></a>
            </li>
            <li class='nav-item'>
              <a class=' text-white' href='client_reg_form.php' style='text-decoration:none'><button type='button' class='btn bg-primary bm text-white'>Add Client</button></a>
            </li>
            <li class='nav-item'>
              <a class=' text-white' href='addcategory.php' style='text-decoration:none'><button type='button' class='btn bg-success bm text-white'>Add Category</button></a>
            </li>
            <li class='nav-item'>
              <a class=' text-white' href='logout.php' style='text-decoration:none'><button type='button' class='btn bg-danger bm text-white'>Logout</button></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  ";
  $uid = $_GET['uid'];


     require_once "dbconnect.php";
     $user = "SELECT u.id as userid,c.id ,u.role,u.username,u.password,u.entertedby,c.clientname from user 
 as u join client as c on u.clientid=c.id where  u.id='".$uid."'";
     // $user = "SELECT role,username,password,entertedby from user where id='".$uid."'";
     $res = mysqli_query($con , $user) ;

     $output.="<div class='container'><div class='col-4 change-margin '>
     ";
  
     $output.="<form action='' method='post' class='update-form'>";

     while ($row = mysqli_fetch_assoc($res)) {
   $output.=  "
       <div class='form-group'>
    <label for='role'>Role</label>
    
  
      <input type='text' name='role' class='form-control' id='role' value=".$row['role'].">
      </div>
      
      <div class='form-group'>
    <label for='username'>Username</label>
    
  
      <input type='text' name='username' class='form-control' id='username' value=".$row['username'].">
      </div>
      
   <div class='form-group'>
    <label for='password'>Password</label>
    
  
      <input type='text' name='password' class='form-control' id='password' value=".$row['password'].">
      </div>
      
     <div class='form-group'>
    <label for='entertedby'>Entered By</label>
    
  
      <input type='text' name='entertedby' class='form-control' id='entertedby' value=".$row['entertedby'].">
      </div>";
     
   }
    $output.= "<div class='form-group'>
    <label for='clientid'>Select Client</label>
     <select name='clientid' id='clientid' class='custom-select'>";
     $res = mysqli_query($con , $user) ;
     while ($row = mysqli_fetch_assoc($res)) {
     $output.= " <option selected value='". $row['id']."'>". $row["clientname"]."</option>";
     }

     $clients = 'select id,clientname from client';
   $clients_res = mysqli_query($con , $clients) ;
 
   while ($row_clients_res = mysqli_fetch_assoc($clients_res)) {
    if(!empty($row_clients_res["clientname"])&&$row_clients_res["clientname"]!=NULL)
    {

     $output.= " <option value='". $row_clients_res['id']."'>". $row_clients_res["clientname"]."</option>";
     }
     }

     $output.="
     
     </select></div>";
   $output.= "<div class='button-align'>
<button type='submit' class='btn btn-success text-white' name='update'>Update</button>
  <a href='index.php' class='btn btn-secondary text-white'>Cancel</a>
 </form>
";

extract($_POST);
if(isset($update))
{
  if(!empty($role)&&!empty($username)&&!empty($password)&&!empty($entertedby))
  {
    $date = date('m-d-y');
    $update_sql = 'UPDATE user SET role="'.$role.'" ,username="'.$username.'",password="'.$password.'",entertedby="'.$entertedby.'", clientid='.$clientid.' ,date="'.$date.'" WHERE id="'.$uid.'"';
    $update_res = mysqli_query($con ,$update_sql) ;
    if( $update_res)
    {
       header("location: index.php");
    }
  }
  else
  {
     $output.= "all fields are mandatory";
  }

}

 $output.="</div></div>
 <footer class='page-footer font-small  bg-light fixed-bottom'>


  <div class='footer-copyright text-center py-3 text-dark'>Copyright 2018 © :
    <a href='https://eabyas.in' target='_blank' class='text-primary font-weight-bold'>  eAbyas Info Solutions</a>
  </div>


</footer>
  </body>
</html>";

echo $output;
  
?>







