
<?php
session_start();
if(!isset($_SESSION['username'])||empty($_SESSION['username'])){ 
header("location: login.php");
}
$output='';
$output.="<html>
<head>
<link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
    <style>

.height-here{
  margin-top: 10px;  
  margin-bottom: 10px;  
height: auto !important;

}


    </style>
    <script>

    $(document).ready(function(){
    $( '.fetch_accordion').accordion({
      collapsible: true,
      active: false,
       
    });

        $( '#dialog-confirm' ).dialog({
        autoOpen: false
    });



$('.del_user').click(function(){
  var uid = $(this).attr('data-value');
  var uid = parseInt(uid);

  var name = $(this).attr('name');
  $('.ap').empty();
  $('.ap').append(name+' '+'User');
 
    $( '#dialog-confirm' ).dialog('open');


    $( '#dialog-confirm' ).dialog({
     
      resizable: false,
      height: 'auto',
      width: 400,
      modal: true,
      buttons: {
        'Delete': function() {
          $( this ).dialog( 'close' );
          
          window.location.replace('delete.php?uid='+uid);
        },
        Cancel: function() {
          $( this ).dialog( 'close' );
        }
      }
    });


    });



$('.del_client').click(function(){
  var cid = $(this).attr('data-value');
  var cid = parseInt(cid);
  
var name = $(this).attr('name');
  
  $('.ap').empty();
  $('.ap').append(name+' '+'Client');
 
    $( '#dialog-confirm' ).dialog('open');


    $( '#dialog-confirm' ).dialog({
     
      resizable: false,
      height: 'auto',
      width: 400,
      modal: true,
      buttons: {
        'Delete': function() {
          $( this ).dialog( 'close' );
          
          window.location.replace('delete_client.php?cid='+cid);
        },
        Cancel: function() {
          $( this ).dialog( 'close' );
        }
      }
    });


    });

});
</script>
    </head>
    <body><div class='fetch_accordion'>";

require_once "dbconnect.php";
extract($_POST);
// echo"<pre>";
// echo $search;
// echo"</pre>";
$data = 'SELECT id as clid ,clientname,url from client  
 where specified="'.$search.'"';
     $res = mysqli_query($con , $data) ;
     while ($row = mysqli_fetch_assoc($res)) {
      $output .= "<h3>";
      $output .= "<span class='left'>".$row['clientname']."</span>";
      $output .= "<span class='right'>".$row['url']."</span>";
      $output .= "</h3>";
      // echo "<p>";
$sql_qry = 'SELECT DISTINCT(u.id) as uid, u.role,u.username,u.password,u.entertedby from user as u
join client as c on u.clientid='.$row['clid'].' and c.specified = "'.$search.'"';
$res1 = mysqli_query($con , $sql_qry);

   
   $output .=  "<div class='height-here'>
   <table class='table   table-bordered text-center  table-hover' >
   <caption class='text-center text-primary' style='caption-side:top'>Client</caption>
      <thead class='bg-dark text-white'><tr>
      <th>Client Name</th>
      <th>URL</th>
      <th colspan='2'>Actions</th>
      </tr></thead>
      <tbody><tr><td>".$row['clientname']."</td>
      <td><a href='".$row['url']."' target='_blank' class='text-info' title='Go To URL'>".$row['url']."</a></td>
      <td><a href='update_client.php?cid=".$row['clid']."'><img src='gear.png' height='20px' width='20px' alt='Update' title='Update Client'></a></td>
      <td ><a data-value='".$row['clid']."' class='del_client' name='".$row['clientname']."'><img src='delete.jpeg' height='20px' width='20px' alt='delete' title='Delete Client'></a></td>
      </tr></tbody>
      </table>
   <table class='table   table-bordered text-center  table-hover' >
   <caption class='text-center text-primary' style='caption-side:top'>Users</caption>
      <thead class='bg-dark text-white'><tr>
      <th>Role</th>
      <th>User Name</th>
      <th>Password</th>
      <th>Entered by</th>
      <th colspan='2'>Actions</th>
      </tr></thead>";
      while ($row1 = mysqli_fetch_assoc($res1)) 
      {
      $output .= "<tr>";
      $output .= "<td>".$row1['role']."</td>";
      $output .= "<td>".$row1['username']."</td>";
      $output .= "<td>".$row1['password']."</td>";
      $output .= "<td>".$row1['entertedby']."</td>";
      $output .= "<td ><a href='updateuser.php?uid=".$row1['uid']."'><img src='gear.png' height='20px' width='20px' alt='Update' title='Update User'></a></td>";
      $output .= "<td ><a data-value='".$row1['uid']."' class='del_user' name='".$row1['username']."'><img src='delete.jpeg' height='20px' width='20px' alt='delete' title='Delete User'></a></td>";
      $output .= "</tr>";
       }
      $output .=  "</table></div>";
     

}
$output .="</div></body>
</html>";
echo $output;

   ?>
  
 