<?php
session_start();
if(!isset($_SESSION['username'])||empty($_SESSION['username'])){ 
header("location: login.php");
}
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Client Records</title>
        <link rel="stylesheet" href="tabsjqui.css">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="icon.css">
        <script src="tabsjquery.js"></script>
        <script src="tabsjqui.js"></script>
        <style type="text/css">
          .tabs{
            margin :100px 30px 30px 80px;

          }
          section{
            margin-bottom: 70px;
          }
          .ui-tabs-nav{
            width:979px;
          }
          .ui-tabs-panel{
            width:981px;
          }
          .bm{
            margin-right:5px; 
          }

         
        </style>
  
    </head>
    <body >
    
    <?php require_once "nav.php";
        ?>
  

    <section>
    <div class="container">
    <div class="row">

        <div class="tabs">
        
         <?php
          require_once "dbconnect.php";
            $categories = "SELECT category_name , id
        from category ";
          $res = mysqli_query($con ,  $categories) ;
          
          $count = mysqli_num_rows($res); 
           ?>
           <ul >
           <?php
          while ($row = mysqli_fetch_assoc($res)) {
          ?>
        <li><a href="tabdata.php?id=<?php echo $row['id'];?>"><?php echo $row['category_name'];?></a></li>
            <?php
            }
            ?>
           <li><a href="all.php">All Data</a></li>

          </ul>

        </div>

        <script>
        $( function() {
          $( ".tabs" ).tabs({
           cache : true ,
            beforeLoad: function( event, ui ) {

              ui.jqXHR.fail(function() {
                ui.panel.html(
                  "Couldn't load this tab. We'll try to fix this as soon as possible. " +
                  "If this wouldn't be a demo." );
              });
            }
           });
          

         } );
        </script>
        </div>
        </div>
        </section>
        <?php require_once "footer.php";
        ?>

    </body>
</html>

          


  
 