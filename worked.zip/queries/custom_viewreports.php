<?php
require_once(dirname(__FILE__) . '/../../config.php');
global $CFG, $DB, $USER;
$PAGE->set_pagelayout('admin');
$PAGE->set_context(context_system::instance());
$PAGE->set_url('/local/queries/custom_viewreports.php');
require_login();
$PAGE->requires->js('/local/queries/js/jquery.min.js',true);
$PAGE->requires->js('/local/queries/js/jqueryui.js',true);
$PAGE->requires->css('/local/queries/css/jqueryui.css',true);
$PAGE->set_heading('Custom Reports');
$PAGE->set_title('Custom Reports');
$PAGE->navbar->add('custom_reports');
echo $OUTPUT->header();
$dirs = array_filter(glob($CFG->dataroot.'/Archive_customreports/*'), 'is_dir');
echo "<h2 class='text-info'>CUSTOM REPORTS</h2>";
echo "<div id='accordian'>";
foreach($dirs as $dir) {
	$folderpath = explode("/",$dir);
	$folder = end($folderpath);
	echo "<h3>".$folder."</h3>";
	$files = array_filter(preg_grep('/^([^.])/', scandir($dir)));
	echo "<div>";
	foreach($files as $file) {
		echo '<p><i class="fa fa-download" aria-hidden="true"></i>&nbsp;<a href="download_custom_report.php?file='.urlencode($folder.'/'.$file).'">'.$file.'</a></p>';
	}
	echo "</div>";
}
echo "</div>";
echo "<script>
	 $( function() {
	    $('#accordian').accordion({
	      	collapsible: true
	    });
	});
  </script>";
echo $OUTPUT->footer();
