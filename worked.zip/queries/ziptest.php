<?php
require_once(dirname(__FILE__) . '/../../config.php');
global $CFG, $DB, $USER;
$PAGE->set_pagelayout('admin');
$PAGE->set_context(context_system::instance());
$PAGE->set_url('/local/queries/ziptest.php');
require_login();
$PAGE->requires->js('/local/queries/js/jquery.min.js',true);
$PAGE->requires->js('/local/queries/js/jqueryui.js',true);
$PAGE->requires->css('/local/queries/css/jqueryui.css',true);
$PAGE->set_heading('Custom Reports');
$PAGE->set_title('Custom Reports');
$PAGE->navbar->add('custom_reports');
echo $OUTPUT->header();
$dirs = array_filter(glob($CFG->dataroot.'/Archive_customreports/*'), 'is_dir');
// echo "<h2 class='text-info'>CUSTOM REPORTS</h2>";
// echo "<div id='accordian'>";
// echo "hi";die();
foreach($dirs as $dir) {

	$folderpath = explode("/",$dir);
	$folder = end($folderpath);
	// echo "<h3>".$folder."</h3>";
	$files = array_filter(preg_grep('/^([^.])/', scandir($dir)));
	print_r($files);
$zipname = $CFG->dataroot.'/nitinzp.zip';
$zip = new ZipArchive;
$zip->open($zipname, ZipArchive::CREATE);
foreach ($files as $file) {
	echo $file;
  $zip->addFile($file);
}
print_object($zip);
$zip->close();
break;
}
// die();
///Then download the zipped file.
header('Content-Type: application/zip');
header('Content-disposition: attachment; filename='.$zipname);
header('Content-Length: ' . filesize($zipname));
readfile($zipname);
?>