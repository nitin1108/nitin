<?php
require_once(dirname(__FILE__) . '/../../config.php');
require_once($CFG->dirroot.'/local/sms_gateway/gate_way.php');
require_once($CFG->dirroot.'/local/sms_gateway/lib.php');
global $DB, $USER, $CFG,$PAGE;
$PAGE->set_url('/local/queries/reply.php');
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('admin');
$id = required_param('id',  PARAM_INT);
$uid = required_param('uid',  PARAM_INT);
$qid = required_param('qid',  PARAM_INT);
ini_set('memory_limit',-1);
$status = 1;
if($commentformdata = data_submitted()) {
    $commentdata = new stdclass();
    $commentdata->queryid = $commentformdata->queryid;
    $commentdata->summary = '';
    $commentdata->comment = $commentformdata->comment;
    $commentdata->postedtime = time();
    $commentdata->responduser = $uid;
    // email will be triggered by this mail id //$fromresult
    $fromresult = $DB->get_record('user',array('id'=>2));
    $toupdate = new stdclass();
    $toupdate->id = $commentformdata->queryid;
    $toupdate->status = 1;
    $sql = "SELECT id,dbhost,dbuser,dbpassword,dbname FROM {school_dbnames} WHERE id='".$id."' ";
    $records = $DB->get_records_sql($sql);
    //saving confgns in variable
    foreach ($records as  $value) {
        $host = $value->dbhost;
        $user = $value->dbuser;
        $password = $value->dbpassword;
        $dbname = $value->dbname;
    }
    //assinging confgn
    $db_class = get_class($DB);
    $remoteDB = new $db_class();
    $remoteDBhost = 'localhost';
    $remoteDBuser = 'root';
    $remoteDBpass = 'leooffice';
    $remoteDBname = $dbname;
    $CFG->prefix = 'mdl_';
    $remoteDB->connect($remoteDBhost, $remoteDBuser, $remoteDBpass,
                        $remoteDBname, $CFG->prefix);
    $DB = $remoteDB;
    if(!$queryresponse=$DB->insert_record('block_query_response',$commentdata)) {
        $status = 0;
    }
    if(!$update = $DB->update_record('block_queries',$toupdate)) {
    	$status = 0;
    } 
    if($status ==1) {
        $queryrecord = $DB->get_record_sql("SELECT id,postedby,subject 
                                            FROM {block_queries} 
                                            WHERE id=$commentformdata->queryid");
        // $touser = $DB->get_record_sql("SELECT * FROM {user} 
        //                                 WHERE id=$queryrecord->postedby");
        $touser = $DB->get_record('user',array('id'=>$queryrecord->postedby));
        $emailobject = new stdClass();
        $emailobject->fullname = $touser->firstname;
        $emailobject->summary = $commentformdata->summary;
        $emailobject->comment = $commentformdata->comment;
        $instructor_id = new stdClass();
        $logged_user = $DB->get_field_sql("SELECT CONCAT(firstname, ' ', lastname)
                                             as fullname FROM {user} 
                                             WHERE id = $uid");
        $logged_user_phone = $DB->get_field_sql("SELECT phone1 FROM {user}  WHERE id = $uid");
        $instructor_id->fullname = $logged_user;
        $emailobject->link = 'http://mydy.dypatil.edu';
        $emailobject->regards = get_string('lecture_regards','local_queries',$instructor_id);
        $subject = get_string('subjectforemailtostudent','local_queries',
                                                        $queryrecord->subject);
        $emailtext = get_string('replytostudenttext','local_queries',$emailobject);   
        $emailhtml = get_string('replytostudenthtml','local_queries',$emailobject);
        $sent = email_to_user($touser,$fromresult,$subject,$emailtext,$emailhtml);
        if(!$sent) {
            $status = 0; //ifemail no sent
        }
        else{
            echo "email sent<br>";
        }
        $lect_info = new stdclass();
        $lec_info->setto = '91'.$logged_user_phone;
        $lec_info->message =get_string('dr1_faculty','local_queries');
        $stu_results = local_sms_gateway_sendsms($lec_info);
        if(!empty($stu_results)) {
            $sms_info = new stdClass();
            $sms_info->message = get_string('dr1_faculty','local_queries');
            $sms_info->messagefrom = $uid; 
            $sms_info->messagearea = 'queries';
            $sms_info->messagetime = time();
            $log->id = $DB->insert_record('local_sms_gateway', $sms_info);
            if(!empty($log->id)) {
                $userlog = new stdClass();
                $userlog->smsid = $log->id;
                $userlog->userto = $uid;
                $userlog->status = $stu_results->getStatus()->getName();/*'succcess'*/
                $userlog->role = 'faculty';
                $userlog->time = time();
                if(!$DB->insert_record('local_sms_gateway_log', $userlog))
                    $status=0; //if sms to inst not sent
                else
                    echo "SMS to instructor sent<br>";
            }
        }
        //send sms to student about the instructor reply
        $to_stu = new stdclass();
        $to_stu->setto = '91'.$touser->phone1;
        $stu_link->stu_link = "http://mydy.dypatil.edu";
        $to_stu->message =get_string('dr1_student','local_queries',$stu_link);
        $to_stu_results = local_sms_gateway_sendsms($to_stu);
        if(!empty($to_stu_results)) {
            $sms_info = new stdClass();
            $sms_info->message = get_string('dr1_student','local_queries');
            $sms_info->messagefrom = $uid; 
            $sms_info->messagearea = 'queries';
            $sms_info->messagetime = time();
            $log->id = $DB->insert_record('local_sms_gateway', $sms_info);
            if(!empty($log->id)) {
                $userlog = new stdClass();
                $userlog->smsid = $log->id;
                $userlog->userto = $touser->id;
                $userlog->status = $to_stu_results->getStatus()->getName();/*'succcess'*/
                $userlog->role = 'student';
                $userlog->time = time();
                if(!$DB->insert_record('local_sms_gateway_log', $userlog))
                    $status = 0; //if sms to student not sent
                else
                    echo "SMS to student sent <br>";
            }
        } 
    }
}
if($status==1) {
    echo "Success<br>";
}
else{
    echo "Either email or phone sms failed<br>";
}