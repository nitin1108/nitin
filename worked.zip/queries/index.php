<?php
require_once(dirname(__FILE__) . '/../../config.php');
global $CFG, $DB, $USER;
$PAGE->set_pagelayout('admin');
$PAGE->set_context(context_system::instance());
$PAGE->set_url('/local/queries/index.php');
require_login();
$PAGE->requires->js('/local/queries/js/jquery.min.js',true);
$PAGE->requires->js('/local/queries/js/jqueryui.js',true);
$PAGE->requires->js('/local/queries/js/jquery.dataTables.min.js',true);
$PAGE->requires->css('/local/queries/css/jqueryui.css',true);
$PAGE->requires->css('/local/queries/css/datatable.min.css',true);
$PAGE->set_heading($SITE->fullname);
$PAGE->set_title('Queries');
$PAGE->navbar->add('Queries');
echo $OUTPUT->header();
$qry ="SELECT id,dbhost,dbuser,dbpassword,dbname,schoolname FROM {school_dbnames}";
$records = $DB->get_records_sql($qry);
$logged_user_email = "SELECT id,email FROM {user} WHERE id='".$USER->id."' ";
$email_rec = $DB->get_record_sql($logged_user_email);
$email = $email_rec->email;
$output=' ';
$output.='
<div class="tabs"><ul>';
foreach ($records as $recs) {
    $count = '';
    $host = $recs->dbhost ;
    $user = $recs->dbuser;
    $password = $recs->dbpassword;
    $dbname = $recs->dbname;

    $db_class = get_class($DB);
    $remoteDB = new $db_class();
    $remoteDBhost = 'localhost'; //$host
    $remoteDBuser = 'root'; //$user
    $remoteDBpass = 'leooffice'; //$password
    $remoteDBname = $dbname; //$dbname
    $CFG->prefix = 'mdl_';
    try {
        $remoteDB->connect($remoteDBhost, $remoteDBuser, $remoteDBpass, $remoteDBname, 
        $CFG->prefix);
        $DB = $remoteDB;
        $logged_user_id_in_remote = "SELECT id,email FROM {user} WHERE email='".$email."' ";
        $uid='';
        if($userid = $DB->get_record_sql($logged_user_id_in_remote)) {
         $uid = $userid->id; //user id of logged user  in selected tab
        }
        $count = $DB->count_records_sql("SELECT count(id) FROM {block_queries} WHERE viewed=0 and userid='".$uid."'");
        if($count>0) {
        $output.= '<li><a href="myqueries.php?id='.$recs->id.'">'.$recs->schoolname.'('.$count.')'.'</a></li>';
        }
        else {
              $output.= '<li><a href="myqueries.php?id='.$recs->id.'">'.$recs->schoolname.'</a></li>';
        }
            
    }
    catch (dml_exception $ex) {
        
    }
 
}
$output.='</ul>';
echo $output;
echo html_writer::script("
$( function() {
    $('.tabs').tabs({
        cache : true ,
        beforeLoad: function( event, ui ) {           
            ui.jqXHR.fail(function() {
                ui.panel.html(
                'Couldnt load this tab. Well try to fix this as soon as possible. ' +
                'If this wouldnt be a demo.' );
            });
        }        
    });
} );
");
echo "<script>
        function view(qid,id,uid) {
            $.ajax({  
                cache: false,
                url: 'viewcomments.php?id='+id+'&qid='+qid+'&rid='+uid, 
                success: function (data) {   
                    $('.toggle'+id+qid+uid).empty();
                    $('.toggle'+id+qid+uid).append(data);
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert(textStatus);
                }
            });
            $('.toggle'+id+qid+uid).slideToggle('fast');
        }
        function mycommentpopupform(id,queryid,uid) {
            $('#popup'+id+queryid+uid).dialog({
               title: 'Post Reply',
               modal: true,
            });
            $('.ui-dialog').addClass('local_queries_popup');
        }
    </script>";

echo $OUTPUT->footer();
    
    
 
 
