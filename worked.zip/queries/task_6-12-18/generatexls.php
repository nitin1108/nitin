<?php
require_once(dirname(__FILE__) . '/../../config.php');
global $CFG, $DB, $USER;
$PAGE->set_pagelayout('admin');
$PAGE->set_context(context_system::instance());
$reports = $DB->get_records_sql("SELECT id,name,type FROM {block_learnerscript} 
								 WHERE not type='sql'");
foreach($reports as $report) {
	switch ($report->type) {
	    case 'mostengagingfaculty':
		    $schoolrecords = $DB->get_records_sql("SELECT sd.schoolname FROM {school_dbnames} as sd ");
			$tableobject = new html_table();
			$i=0;
			$headarray = array();
			foreach ($schoolrecords as $schoolrecord) {
				$sql = $DB->get_records_sql("SELECT rm.* FROM {report_mostviewedfaculty} rm 
												WHERE rm.school = '$schoolrecord->schoolname' 
												ORDER BY rm.percentage DESC LIMIT 0,5");
				foreach ($sql as $key => $value) {
					$value = (array) $value;
					if($showid) {
						unset($value['id']);
						unset($value['timecreated']);
						unset($value['timemodified']);
					}
					$tableobject->data[] = $value;	
					if(empty($headarray)) {
						if($i==0){
							foreach ($value as $key1 => $value1) {
								$headarray[$key1] = ucwords(str_replace('_',' ',$key1));
							}
						}
					}	
				}
				$i++;
			}
			$tableobject->head = $headarray;
			$tablecontent = html_writer::table($tableobject);
			custom_generate_xls($tablecontent,$report->name);
	    break;
	    case 'instancesetup_status':
		    $instancesetup_status = $DB->get_records_sql("SELECT id, schoolname as school, programname as program_name, academicyear as academic_year, activesemester_name as active_semester, batchname as batch, datarequested_date as data_requested_date, datareceived_date as data_recieved_date, statussince_date as status_since_date, timealloted as time_alloted, comments as comments, status as status FROM {local_schoolstatus_live}");
		    $content = custom_generate_table($instancesetup_status);
			custom_generate_xls($content,$report->name);	       
	    break;
	    case 'facultyoverview':
		    $facultyoverview = $DB->get_records_sql("SELECT id, school as School, program as 
				Program,semester as Semester, batch as Batch, batchsize as 
				Batch_Size, faculty as Faculty, subjects as Subjects,
				total_students as Total_Enrolled_Students, attendance as 
				Attendance, presentation as Presentation, casestudy as 
				Case_Sudy, forum as Discussion_Forum,  readingmaterial as 
				Reading_Material, video as Video, assign as Assignment, 
				dyquestion as Question_Bank,  questionpaper as
				Question_Paper, quiz as Quiz , total  as Total
				FROM {report_facultyoverview}");
		    $content = custom_generate_table($facultyoverview);
			custom_generate_xls($content,$report->name);       
	    break;
	    case 'programwiseinstance':
			$programwiseinstance = $DB->get_records_sql("SELECT id, sc.schoolname as school_name,sc.programname as program_name, 
				( SELECT round(count(batchname)/(count(sc.batchname))*100) FROM 
				{local_schoolstatus_live} WHERE status = 'live' AND sc.programname = 
				programname ) as live_percent,( SELECT round(count(batchname)/
				(count(sc.batchname))*100) FROM {local_schoolstatus_live} WHERE 
				status = 'pending' AND sc.programname = programname ) as in_progres_percent,
				( SELECT round(count(batchname)/(count(sc.batchname))*100) FROM 
				{local_schoolstatus_live} WHERE status = 'not live' AND 
				sc.programname = programname) as data_not_recieved_percent FROM
				{local_schoolstatus_live} AS sc  group by sc.programname");
			$content = custom_generate_table($programwiseinstance);
			custom_generate_xls($content,$report->name);  	       
	    break;
	    case 'universitywiseinstance':
		    $universitywiseinstance = $DB->get_records_sql("SELECT id,'Live Schools'  as type, 	count(status) as total, GROUP_CONCAT(schoolname) as schools 
		    	FROM {local_collegestatus} WHERE status = 1 union
	            SELECT id,'In Progress' as type, count(status) as total, 
	            GROUP_CONCAT(schoolname) as schools  
	            FROM {local_collegestatus} 
	            WHERE status = 2 union
	            SELECT id,'Data not Received' as type, count(status) as total, 
	            GROUP_CONCAT(schoolname) as schools  
	            FROM {local_collegestatus} WHERE status = 0");
		    $content = custom_generate_table($universitywiseinstance);
			custom_generate_xls($content,$report->name);	        
	    break;
	    case 'studentcontenthitrate':
		    $studentcontenthitrate = $DB->get_records_sql("SELECT 'Presentation'
			    as activity_type,
			    sum(rf.presentation) as 'total_uploaded', sum(rsad.presentation) as 'viewed', 
				sum(rf.presentation-rsad.presentation)  as 'notviewed' FROM 
				{report_facultyoverview} as rf  
				JOIN {report_studentcontent_accessed_data} as rsad 
				ON rsad.cobaltclassid = rf.cobaltclassid AND rsad.school = rf.school 
			    union
			    SELECT 'Case Study' as type, sum(rf.casestudy) as 'total', sum(rsad.casestudy)
				    as 'viewed', sum(rf.casestudy-rsad.casestudy) as 'unviewed' 
				    FROM {report_facultyoverview} as rf  
				    JOIN {report_studentcontent_accessed_data} as rsad 
				    ON rsad.cobaltclassid = rf.cobaltclassid AND rsad.school = rf.school 
		        union
		        SELECT 'Discussion Forum' as type, sum(rf.forum) as 'total', sum(rsad.forum) 
			        as 'viewed', sum(rf.forum-rsad.forum) as 'notviewed' 
			        FROM {report_facultyoverview} as rf  
			        JOIN {report_studentcontent_accessed_data} as rsad ON 
			        rsad.cobaltclassid = rf.cobaltclassid AND rsad.school = rf.school 
		        union
		        SELECT 'Reading Material' as type, sum(rf.readingmaterial) as 'total', sum(rsad.readingmaterial) as 'viewed', sum(rf.readingmaterial-rsad.readingmaterial) as 'notviewed' FROM {report_facultyoverview} as rf  JOIN {report_studentcontent_accessed_data} as rsad ON rsad.cobaltclassid = rf.cobaltclassid AND rsad.school = rf.school 
		        union
		        SELECT 'Video' as type, sum(rf.video) as 'total', sum(rsad.video) as 'viewed', sum(rf.video-rsad.video) as 'notviewed' FROM {report_facultyoverview} as rf  JOIN {report_studentcontent_accessed_data} as rsad ON rsad.cobaltclassid = rf.cobaltclassid AND rsad.school = rf.school 
		        union
		        SELECT 'Assignment' as type, sum(rf.assign) as 'total', sum(rsad.assign) as 'viewed', sum(rf.assign-rsad.assign) as 'notviewed' FROM {report_facultyoverview} as rf  JOIN {report_studentcontent_accessed_data} as rsad ON rsad.cobaltclassid = rf.cobaltclassid AND rsad.school = rf.school
		        union
		        SELECT 'Question Bank' as type, sum(rf.dyquestion) as 'total', sum(rsad.dyquestion) as 'viewed', sum(rf.dyquestion-rsad.dyquestion) as 'notviewed' FROM {report_facultyoverview} as rf  JOIN {report_studentcontent_accessed_data} as rsad ON rsad.cobaltclassid = rf.cobaltclassid AND rsad.school = rf.school 
		        union
		        SELECT 'Question Paper' as type, sum(rf.questionpaper) as 'total', sum(rsad.questionpaper) as 'viewed', sum(rf.questionpaper-rsad.questionpaper) as 'notviewed' FROM {report_facultyoverview} as rf  JOIN {report_studentcontent_accessed_data} as rsad ON rsad.cobaltclassid = rf.cobaltclassid AND rsad.school = rf.school 
		        union
		        SELECT 'Quiz' as type,sum(rf.quiz) as 'total', sum(rsad.quiz) as 'viewed', sum(rf.quiz-rsad.quiz) as 'notviewed' FROM {report_facultyoverview} as rf  JOIN {report_studentcontent_accessed_data} as rsad ON rsad.cobaltclassid = rf.cobaltclassid AND rsad.school = rf.school");
		    $content = custom_generate_table($studentcontenthitrate);
			custom_generate_xls($content,$report->name);
	        
	    break;
	    case 'studentaccesseduniversitywise':
		    $studentaccesseduniversitywise = $DB->get_records_sql("SELECT 'Active Students'  as type, sum(activestudent) as total
			    FROM mdl_report_activestudent_logins WHERE id > 1 
				union
				SELECT 'In-Active Students' as type, sum(notactivestudent) as total 
				FROM mdl_report_activestudent_logins WHERE id > 1 ");
		    $content = custom_generate_table($studentaccesseduniversitywise);
			custom_generate_xls($content,$report->name);	        
	    break;
	    case 'collegewisestudentslogin':
		    $collegewisestudentslogin = $DB->get_records_sql("SELECT id,round((sum(activestudent)/sum(totalstudents))*100) as activestudent, round((sum(notactivestudent)/sum(totalstudents))*100) as notactivestudent, sum(totalstudents) as totalstudents, school FROM mdl_report_activestudent_logins GROUP BY school");
	        $content = custom_generate_table($collegewisestudentslogin);
			custom_generate_xls($content,$report->name);
	    break;
	}

}

function custom_generate_table($object, $showid = true) {
	$tableobject = new html_table();
	$tableobject->head = array();
	$headarray = array();
	foreach ($object as $key => $value) {
		$value = (array) $value;
		if($showid) {
			unset($value['id']);
		}
		$tableobject->data[] = $value;	
		if(empty($headarray)) {
			foreach ($value as $key1 => $value1) {
				$headarray[$key1] = ucwords(str_replace('_',' ',$key1));
			}
		}	
	}
	$tableobject->head = $headarray;
	$tablecontent = html_writer::table($tableobject);
	return $tablecontent;
}

function custom_generate_xls($tablecontent,$filename) {
	global $CFG;
	$date = date("d-M-Y");	
	$filename = '/'.$filename.'_'.date('d M Y_H:i:s').'.xls';
	$path = $CFG->dataroot.'/Archive_customreports/'.$date;
	mkdir($path, 0777, true);
	file_put_contents($path.'/'.$filename, $tablecontent);
}