<?php
// define('AJAX_SCRIPT', true);
require_once(dirname(__FILE__).'/../../config.php');
global $DB, $USER, $CFG,$PAGE;
$id = required_param('id',  PARAM_INT);
$qid = required_param('qid',  PARAM_INT);
$rid = required_param('rid',  PARAM_INT);
$sql = "SELECT * FROM {school_dbnames} WHERE id='".$id."' ";
$school_confign = $DB->get_record_sql($sql);
$host = $school_confign->dbhost ;
$user = $school_confign->dbuser;
$password = $school_confign->dbpassword;
$dbname = $school_confign->dbname;
$db_class = get_class($DB);
$remoteDB = new $db_class();
$remoteDBhost = 'localhost'; //$host
$remoteDBuser = 'root'; //$user
$remoteDBpass = 'leooffice'; //$password
$remoteDBname = $dbname;
$CFG->prefix = 'mdl_';
$remoteDB->connect($remoteDBhost, $remoteDBuser, $remoteDBpass, 
                    $remoteDBname, $CFG->prefix);
$DB = $remoteDB;
$test= ' ';
$queryresponses = $DB->get_records_sql("SELECT id,responduser,postedtime,comment 
                                        FROM {block_query_response} 
                                        WHERE queryid=$qid ORDER BY id DESC");
if($queryresponses) {
    foreach($queryresponses as $queryresponse) {
        $test .= '<div class="togglediv">';
        $date = date("d/m/y h:i a",$queryresponse->postedtime);
        $test .= '<span>'.$date.'</span><br><br>';
        $comments = '<p><span style="color: #424244;"><b>Reply&nbsp:&nbsp</b>
                                    </span>'.$queryresponse->comment.'</p>';  
        $test .= $comments;
        $test .= '</div>';
        
    }
}
else {
    $test .= '<div class="togglediv">';
    $test .= html_writer:: tag('p',get_string('nocomments','local_queries'));
    $test .= '</div>';
}  
echo $test;          
