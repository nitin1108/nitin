<?php
require_once(dirname(__FILE__) . '/../../config.php');
global $CFG, $DB, $USER;
$PAGE->set_pagelayout('admin');
$PAGE->set_context(context_system::instance());
$dirs = array_filter(glob($CFG->dataroot.'/Archive_customreports/*'), 'is_dir');
foreach($dirs as $dir) {

	$folderpath = explode("/",$dir);

$folder = end($folderpath);
	$files = array_filter(preg_grep('/^([^.])/', scandir($dir)));

}

$tempzip = mkdir($CFG->dataroot.'/mycustomzip',077,true);
$zipper = new zip_packer();
if ($zipper->archive_to_pathname($filelist, $tempzip)) {
    send_temp_file($tempzip, 'myzip.zip');
}