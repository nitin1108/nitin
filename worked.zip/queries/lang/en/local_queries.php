<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Queries';
$string['notresponded'] = '<small>Not Responded</small>';
$string['responded'] = '<small>Responded</small>';
$string['by'] = 'Posted by';
$string['on'] = 'On';
$string['status'] = 'Status';
$string['nocomments'] = 'No replies to display';
$string['myqueries'] = 'My Queries';
$string['backtohome'] = 'Back to home';
$string['noqueries'] = 'You do not have queries';
$string['subjectt'] = 'Subject';
$string['descriptionn'] = 'Description';
$string['postedby'] = 'Posted by';  
$string['notenrolled'] = "Sorry you are not enrolled in this college";

$string['lecture_regards']='<span><b>Regards</b></span><br>
{$a->fullname}.';

$string['subjectforemailtostudent'] = 'Response of the "{$a}"';

$string['replytostudenttext'] = 'Hi {$a->fullname},
<p>{$a->summary}</p>
<p>{$a->comment}</p><br>,
<span style = "font-size:11px;">Please click on below link to view the faculty reply.</span><br>
<span style = "font-size:11px;">{$a->link}.</span><br>
{$a->regards}';

$string['replytostudenthtml'] = '<div style="margin:auto;"><p>Hi {$a->fullname},</p>
<p>{$a->summary}</p>
<p>{$a->comment}</p>
<span style = "font-size:11px;">Please click on below link to view the faculty reply.</span><br>
<span style = "font-size:11px;">{$a->link}.</span><br>
<p>{$a->regards}</p>
</div>';

$string['dr1_faculty'] ='Dear Faculty,
Thank you for using MYDY to reply student Query. Your reply has been submitted successfully. 
The Student will be notified regarding your reply.';


$string['dr1_student'] = 'Dear Student,
Your query has been responded. Please logon to the MYDY to know the reply. Keep posting on the LMS for any further queries. Thank you.
{$a->stu_link}';
