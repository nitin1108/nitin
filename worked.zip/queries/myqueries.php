<?php
require_once(dirname(__FILE__).'/../../config.php');
global $PAGE, $USER, $DB, $CFG, $OUTPUT;
require_once($CFG->dirroot.'/local/queries/myreplyform.php');
$logged_user_email = "SELECT id,email FROM {user} WHERE id='".$USER->id."' ";
$email_rec = $DB->get_record_sql($logged_user_email);
$email = $email_rec->email;
$id = required_param('id',  PARAM_INT);
$sql = "SELECT id,dbhost,dbuser,dbpassword,dbname FROM {school_dbnames} WHERE id='".$id."' ";
$school_confign = $DB->get_record_sql($sql);
$host = $school_confign->dbhost ;
$user = $school_confign->dbuser;
$password = $school_confign->dbpassword;
$dbname = $school_confign->dbname;
//assinging confgn
$db_class = get_class($DB);
$remoteDB = new $db_class();
$remoteDBhost = 'localhost'; //$host
$remoteDBuser = 'root'; //$user
$remoteDBpass = 'leooffice'; //$password
$remoteDBname = $dbname; //$dbname
$CFG->prefix = 'mdl_';
$remoteDB->connect($remoteDBhost, $remoteDBuser, $remoteDBpass, $remoteDBname, $CFG->prefix);
$DB = $remoteDB;
$uid='';
$logged_user_id_in_remote = "SELECT id,email FROM {user} WHERE email='".$email."' ";
if($userid = $DB->get_record_sql($logged_user_id_in_remote)) {
    $uid = $userid->id;
}
if($uid) {
    $sql_updt = "UPDATE {block_queries} SET viewed=1 WHERE userid=$uid";
    $DB->execute($sql_updt);
    $getqueries = $DB->get_records_sql("SELECT id,postedby,timecreated,
                                        status,subject,description 
                                        FROM {block_queries} 
                                        WHERE userid = $uid  
                                        ORDER BY id DESC");
    if(!empty($getqueries)) {
        $data = array();
        foreach ($getqueries as $getquery) {
            $row = array();
            $queryid = $getquery->id;
            $postedby = $getquery->postedby;
            if(!$postedby) {
                continue;
            }
            $timecreated = $getquery->timecreated;
            
            $date = date("d/m/y h:i a",$timecreated);
            if($getquery->status==0) {
                $status = '<span style="color: red"><b id="stat'.$id.$queryid.$uid.'">'.get_string('notresponded',
                            'local_queries').'</b></span>';
            }
            else {
                $status = '<span style="color: green"><b id="stat'.$id.$queryid.$uid.'">'.get_string('responded',
                            'local_queries').'</b></span>';
            }
            $subject = $getquery->subject;
            $description = $getquery->description;
            $fullname_qry = $DB->get_record_sql("SELECT id,CONCAT(firstname,' ',lastname) as fullname FROM mdl_user WHERE id = $postedby");
            $fullname =  $fullname_qry->fullname;
            $click_to_reply = html_writer:: tag('a','Click here to post reply',array("id"=>"showDialog$id$queryid$uid","class"=>"commenticonpostion","onclick"=>"mycommentpopupform($id,$queryid,$uid)"));
            $view_comment ='<a href="javascript:void(0)" onclick="view('.$queryid.','.$id.','.$uid.')">View replies</a>';
            $testdata = '<div class="qry">
            <p class="subjectclass"><b>'.ucfirst($subject).'</b><span class="mrg">'.get_string("by","local_queries").':&nbsp;&nbsp;<b><span>'.$fullname.'</span>&nbsp;&nbsp;</b>Posted on:&nbsp;&nbsp;<b>'.$date.'</b></span>
            </p>
            <p class="comment_summary">'.$description.'</p>
            <div class="informationdiv"><b>'.get_string('status','local_queries').': </b>'.$status.'&nbsp;&nbsp;|&nbsp;&nbsp;'.$click_to_reply.'&nbsp;&nbsp;|&nbsp;&nbsp;'.$view_comment.'
            </div>
            </div>
            <div class="toggle_style"><span style="display:none;"  class="toggle'.$id.$queryid.$uid.' plus_toggle">
            </span>
            </div>';
            $popup = replyform($id,$queryid,$uid);
            // echo $popup;            
            $testdata .= $popup; 
            $row[] = $testdata;
            $data[] = $row;
        }        
    }
    if(!empty($testdata)) {
        $mytable = new html_table();
        $mytable->head = array('');
        $mytable->width = '100%';
        $mytable->id = 'tablequery';
        $mytable->attributes['class'] = 'tablequeries';
        $mytable->data  = $data;
        echo html_writer::table($mytable);
    }
}
else {
    echo html_writer:: tag('h4',get_string('notenrolled','local_queries'));
}

echo html_writer::script('
    $(document).ready(function() {
        $(".tablequeries").dataTable({
            searching: true,
            responsive: true,
            "ordering": false,
            "lengthMenu": [[5, 10, 25,50,100, -1], [5,10,25, 50,100, "All"]],
            "destroy": true
        });
    });
');

        