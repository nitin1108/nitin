<?php 
function replyform($id,$queryid,$uid) {
    global $CFG, $DB;
    $popup ='';
    $popup .= "<script type='text/javascript'>
    $(document).ready(function() {
        $('.ld').hide();
        $('#cancel$id$queryid$uid').click(function() {
            $('#popup$id$queryid$uid').dialog('destroy');
        });
        $('#submit$id$queryid$uid').on('click',function(e) {
            var comment$id$queryid$uid = $('#comment$id$queryid$uid').val();
            if(comment$id$queryid$uid==undefined || comment$id$queryid$uid == ' ' ) {
                $('#error_box$id$queryid$uid').html('<p style=\'color:red;\'>Please fill the required fields</p>');
                e.preventDefault();
            }
            else if(!comment$id$queryid$uid.replace(/\s/g, '').length) {
                $('#error_box$id$queryid$uid').html('<p style=\'color:red;\'>Please fill the required fields</p>');
                e.preventDefault();
            }
            else {
                $('#error_box$id$queryid$uid').html('');
                e.preventDefault();
                $.ajax({
                    type: 'POST',
                    url: $('.frmdt$id$queryid$uid').attr('action'),
                    data: $('.frmdt$id$queryid$uid').serialize(),
                    cache: false,
                    success: function(data) {
                        $('.ld').hide();
                        $('.suc-msg').css('display', 'block');
                        var stat = $('#stat$id$queryid$uid small').html();
                        if(stat!='Responded') {
                            $('#stat$id$queryid$uid small').html('Responded');
                            $('#stat$id$queryid$uid small').css('color', 'green');
                        }
                        setTimeout(function () {
                            $('.suc-msg').css('display', 'none');
                            $('#popup$id$queryid$uid').dialog('destroy');
                            $('form')[0].reset();
                        }, 2000);                                            
                    },
                    error: function(xhr, status, error) {
                        $('.ld').hide();
                        $('.fail-msg').css('display', 'block');
                        $('form')[0].reset();
                    },
                    beforeSend: function(){
                        $('.ld').show();
                    }                    
                });
            }
        });
    });
    </script> ";
    $popup .= " <div id='popup".$id.$queryid.$uid."' style='display:none;' >
                <div class='suc-msg' style='display: none;'>
                <strong>Reply Sent Successfully!</strong>
                </div>
                <div class='fail-msg' style='display: none;'>
                <strong>Either E-mail or SMS not sent!</strong>
                </div>
               <div class='err' id='error_box$id$queryid$uid'></div>";
    $actionpage = 
            $CFG->wwwroot.'/local/queries/myreply.php?id='.$id.'&uid='.$uid.'&qid='.$queryid;
    $popup .= '<form name="myForm'.$id.$queryid.$uid.'" method="post" action="'.$actionpage.'" class="frmdt'.$id.$queryid.$uid.'">';
    $result = $DB->get_record('block_queries',array('id'=>$queryid));
    $postedby = $result->postedby;
    $fullname_qry = $DB->get_record_sql("SELECT id,CONCAT(firstname,' ',lastname) 
                                            as fullname FROM mdl_user 
                                            WHERE id = $postedby");
    $fullname =  $fullname_qry->fullname;
    $postedtime = "<span>".date("d/m/y h:i a",$result->timecreated)."</span>";
    $popup .= "<p><b>".get_string('postedby','local_queries').":</b>&nbsp;".$fullname." <b>".get_string('on','local_queries').":</b>&nbsp;".$postedtime."</p>";
    $popup .= "<p><b>".get_string('subjectt','local_queries').":</b>&nbsp;&nbsp; ".$result->subject."</p>";
    $popup .= "<p><b>".get_string('descriptionn','local_queries').":</b></p>";
    $popup .= "<p>".$result->description."</p>";
    $popup .= "<input type='hidden' name='queryid' value='$queryid'>";
    $popup .= "<label for='comment'><b>Reply</b><span style='color:red;'>*</span>:&nbsp;<img src='pix/loading.gif' class='ld'></label>";
    $popup .= "<textarea name='comment' id='comment$id$queryid$uid' rows='5' cols='51'></textarea>";
    $popup .= "<div class='queries_submitbutton'>
                <input type='submit'  name='submit' id='submit".$id.$queryid.$uid."' value='Submit'>
               <input type='reset' id='cancel".$id.$queryid.$uid."'   value='Cancel'>
                </div>";
    $popup .= "</form>";
    $popup .= "</div>";
    return $popup;
}


    
