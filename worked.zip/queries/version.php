<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_queries';
$plugin->version = 2015051108;
$plugin->release = '2.9 (Build: 2015081800)';
$plugin->requires = 2015051100;
// $plugin->maturity = MATURITY_STABLE;
