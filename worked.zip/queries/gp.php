<?php
require_once(dirname(__FILE__) . '/../../config.php');
global $DB, $USER,$CFG;
require_once($CFG->libdir."/pdflib.php"); 
$doc = new TCPDF(null, 'cm', 'A4', true, 'UTF-8', false);
$doc->setPrintHeader(false);
$doc->setPrintFooter(false);
$doc->Addpage($orientation = 'P', $format = 'A4', $keepmargins = false, $tocpage = true);
$doc->SetFont('times', '', 8);
$body = '<table style="width:100%;" >';
$body .= '  <tr>
                <td colspan="4"><strong>eAbyas info soln.</strong><br>lorem ipsum<br>947847447<br>https://eabays.in<br><br></td>
                
                <td colspan="2" style="text-align: right;"><img src="pix/loading.gif"/></td>                
            </tr>';
$body .='   <tr>
                <td colspan="6" style="text-align: left;"><br></td>                
            </tr>';
$body .='   <tr>                
                <td colspan="6" style="text-align: left;"><h2>INVOICE</h2><br></td>
            </tr>';       
$body .='   <tr>                
                <td colspan="2"><strong>BILL TO,</strong><br>Admin User<br></td>
                <td colspan="2"></td>
                <td colspan="2"><strong>Invoice:</strong>&nbsp;73<br><strong>DATE:</strong>&nbsp;4/12/18<br></td>                                
            </tr>';                
$body .='   <tr>               
                <td colspan="6"><hr></td>
            </tr>';                
$body .='   <tr style="background-color: #f1f1f1;" >
                <td height="15" width="15%"><strong>PRODUCT</strong></td>
                <td height="15"><strong>QUANTITY</strong></td>
                <td height="15"><strong>PRICE</strong></td>
                <td height="15"><strong>TAX</strong></td>
                <td height="15"><strong>DISCOUNT</strong></td>
                <td height="15"><strong>AMOUNT</strong></td>
            </tr>';       
$body .='   <tr>
                <td width="15%">Time Management</td>
                <td>1</td>
                <td>USD 50.00</td>
                <td>USD 10.00</td>
                <td>-</td>
                <td>USD 60.00</td>
            </tr>';                    
$body .='   <tr>
                <td colspan="6"><br><hr></td>
            </tr>';
$body .='   <tr  cellpadding="1">
                <td colspan="4"></td>
                <td style="text-align: right;">SUB-TOTAL</td>
                <td style="text-align: left; ">USD 50.00</td>
            </tr>';        
$body .='   <tr  cellpadding="1">
                <td colspan="4"></td>
                <td style="text-align: right;">DISCOUNT</td>
                <td style="text-align: left; ">USD 0.00</td>
            </tr>';        
$body .='   <tr style="text-align: right;" cellpadding="1">
                <td colspan="4"></td>
                <td style="text-align: right;">TAX</td>
                <td style="text-align: left; ">USD 10.00</td>
            </tr>';
        
$body .='   <tr  cellpadding="1">                
                <td colspan="4"></td>
                <td style="text-align: right;"><strong>BALANCE DUE</strong></td>
                <td style="text-align: left; ">USD 60.00</td>
            </tr>';        
$body.='</table>';
	
$doc->writeHTMLCell($w = 0, $h = 0, $x = 4, $y = '', $body, $border = 0, $ln = 1, $fill = 0, $reseth = true, $align = '', $autopadding = true);
ob_end_clean();
$doc->Output('Invoice.pdf', 'D');
?>