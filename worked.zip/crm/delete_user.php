<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']!=1)
{ 
header("location: index.php");
}
require_once "dbconnect.php";
if(isset($_GET['uid']))
{
  $uid = $_GET['uid'];
  $delete_user_qry = 'DELETE FROM `users` WHERE id="'.$uid.'"';
              
    if (mysqli_query($con, $delete_user_qry))
    {
       echo 'user deleted';
    } 
}

?>