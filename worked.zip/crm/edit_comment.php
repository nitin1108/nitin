<?php

session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']==''||empty($_SESSION['username']))
{ 
header("location: login.php");
}
require_once "dbconnect.php";

$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
    
    <title>Comments Form</title>
    <style>
    .change-margin{
      margin: 100px auto auto auto; 
     }
     </style>
  </head>
  <body>";

$commentid = $_GET['commentid'];
$crmid = $_GET['crmid'];
 
  $output .= "<section>

  <div class='container'> 
  <div class='col-4 change-margin '>  
  <form action='' method='post' >";

  $output.= "<div class='form-group'>
     <label for='crm'> Client</label>
     <select name='crm' id='crm' class='custom-select'>";
     $crm_qry = 'SELECT id , client from crm where id="'.$crmid.'"';
     $crm_res = mysqli_query($con , $crm_qry) ;
     while ($crm_row = mysqli_fetch_assoc($crm_res)) {
     $output.= " <option  value='". $crm_row['id']."' disabled selected >". $crm_row["client"]."</option>";
     }
     $output.="</select>
     </div>";

  $output .="<div class='form-group'>
    <label for='comment'>Comment</label>";
    $commnets_update_qry = 'SELECT  comment from comments where id="'.$commentid.'"';
    $commnets_update_res = mysqli_query($con , $commnets_update_qry) ;
    while ($commnets_update_row = mysqli_fetch_assoc($commnets_update_res)) {
    $output .=" <textarea  name='comment' class='form-control' id='comment'  style='height: 150px' >".$commnets_update_row['comment']."</textarea>
  </div>";
  }

$output .="<div class='button-align'>
<input type='submit' name='submit' class='btn btn-primary' value='Update'>
  
<a href='index.php' class='btn btn-primary text-white' style='text-decoration:none'>Back</a>
  
</form>";
 
  extract($_POST);
  if(isset($submit))
  {
    $timestamp = time();
    $uid = $_SESSION['uid'];
    // require_once "dbconnect.php";
    if(!empty($comment)){
    $comment_update_qry = 'UPDATE `comments` SET `comment`="'.$comment.'",`timemodified`='.$timestamp.',`usermodified`='.$uid.' WHERE id='.$commentid.'';
              
    if (mysqli_query($con, $comment_update_qry))
    {
      $_SESSION['status']='commentupdated';
      header("Location: index.php");
    }else
    {
        $output .="<br><span class='text-danger'>Not Updated</span>";
    }
  } else
  {
    $output .="<br><span class='text-danger'>Comment is Required</span>";
  }
   
  
  }

$output .="</div>
</div>
</section></body>
</html> ";

echo $output;

?>


