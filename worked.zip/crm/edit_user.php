<?php
session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']!=1)
{ 
header("location: index.php");
}
require_once "dbconnect.php";

$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
    
    <title>Update User</title>
    <style>
    .change-margin{
      margin: 100px auto auto auto; 
     }
     </style>
  </head>
  <body>";

$uid = $_GET['uid'];
 
  $output .= "<section>

 <div class='container'> 
  <div class='col-4 change-margin '>  
  <h3>Update User</h3><hr/>

<form action='' method='post' >";
$edit_user_qry = 'SELECT * from users where id="'.$uid.'"';
$edit_user_res = mysqli_query($con , $edit_user_qry) ;
     while ($edit_user_row = mysqli_fetch_assoc($edit_user_res)) {
$output .= "<div class='form-group'>
    <label for='username'>Username</label>
    <input type='text' name='username' class='form-control' value='".$edit_user_row['username']."'>
  </div>
  <div class='form-group'>
    <label for='name'>Name</label>
    <input type='text' name='name' class='form-control' value='".$edit_user_row['name']."'>
  </div>
<div class='form-group'>
    <label for='empid'>Employee ID</label>
    <input type='number' name='empid' class='form-control' value='".$edit_user_row['empid']."'>
  </div>
<div class='form-group'>
    <label for='email'>E-Mail</label>
    <input type='email' name='email' class='form-control' value='".$edit_user_row['email']."'>
  </div>

<div class='form-group'>
    <label for='password'>Password</label>
    <input type='password' name='password' class='form-control' value='".$edit_user_row['password']."'>
  </div>";
}
  
$output .="<input type='submit' name='submit' class='btn btn-primary' value='Update'>
  
<a href='index.php' class='btn btn-primary text-white' style='text-decoration:none'>Back</a>
  
</form>";
 
  extract($_POST);
  if(isset($submit))
  {
    
    if(!empty($username)&&!empty($password)&&!empty($email)&&!empty($empid)&&!empty($name)){
    $user_update_qry = 'UPDATE `users` SET `username`="'.$username.'",`name`="'.$name.'",`password`="'.$password.'",
    `email`="'.$email.'",`empid`="'.$empid.'" WHERE id='.$uid.'';
              
    if (mysqli_query($con, $user_update_qry))
    {
      $output .="<br><span class='text-success'>User Updated</span>";
    }else
    {
        $output .="<br><span class='text-danger'>Not Updated</span>";
    }
  } else
  {
    $output .="<br><span class='text-danger'>All Fields are Required</span>";
  }
   
  
  }

$output .="</div>
</div>
</section></body>
</html> ";

echo $output;

?>


