<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
 require 'phpmailer/class.phpmailer.php';
  require 'phpmailer/class.smtp.php';

$y = date('Y-m-d',time());
 // echo $y;
$con = mysqli_connect("localhost","root","leooffice","my_crm");

$qry = 'SELECT * from notify_on where notifyon="'.$y.'"'; 

 $res = mysqli_query($con , $qry) ;

 while ($row = mysqli_fetch_assoc($res))
  {

    $comment=' ';
    $count=1;
  	$qry1 = "SELECT client ,requirement from crm where id='".$row['crmid']."'";
  	$res1 = mysqli_query($con , $qry1) ;
  	while ($row1 = mysqli_fetch_assoc($res1))
  	{
  		$client = $row1['client'];
  		$requirement = $row1['requirement'];
  	}
  	$qry2 = "SELECT comment from comments where crmid='".$row['crmid']."'";
  	$res2 = mysqli_query($con , $qry2) ;
  	while ($row2 = mysqli_fetch_assoc($res2))
  	{
  		$comment.= $count.') '.$row2['comment'].'<br>';
      $count++;
  		
  	}
    $notifyto = $row['notifyto'];
    $crmid = $row['crmid'];
   // echo $notifyto;
    // die();
    custom_crm_mail($client,$comment,$requirement,$notifyto,$con,$crmid); 
    // $comment= ' ';
     }

   function custom_crm_mail($client,$comment,$requirement,$notifyto,$con,$crmid)
   {   
     $file = "";
     $file_count = 1;
     $mail = new PHPMailer;
     $mail->setFrom('nitin@eabyas.in','Admin');
// echo "<br>";
     $qry3 = "SELECT id,name ,email
 FROM users 
 WHERE id IN (".$notifyto.") "; 
  $res3 = mysqli_query($con , $qry3) ;
  while ($row3 = mysqli_fetch_assoc($res3))
    {
      $mail->addAddress($row3['email'],$row3['name']);
    }


    

$mail->isHTML(true);

  $mail->Subject = 'This is remainder for client '.$client;

$body='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title></title>
        <style></style>
    </head>
    <body>
    <h3>HI, This is remainder for Client '.$client.'</h3>
        <table border="0" cellpadding="0" cellspacing="0"   id="bodyTable">
            <tr>
                <td align="center" valign="top">
                    <table border="1" cellpadding="20" cellspacing="0"  id="emailContainer">
                    
                    <tr>
                            <th align="center" valign="top" >
                                Client.
                            </th>                            
                            <th align="center" valign="top" >
                               Requirement
                            </th>                            
                            <th align="center" valign="top" >
                                Comment
                            </th>
                            
                        </tr>
                        <tr>
                            <td align="center" valign="top">
                                '.$client.'
                            </td>                            
                            <td align="center" valign="top">
                                '.$requirement.'
                            </td>                        
                                <td align="center" valign="top">
                               '.$comment.'
                            </td>    
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </body>
</html>';
 $mail->Body = $body;
// $mail->AddAttachment('uploads/1542268376data.txt', '1542268376data.txt');
 $attachment_qry ="SELECT id,file
 FROM crm 
 WHERE id=".$crmid." ";
 
  $attachment_res = mysqli_query($con , $attachment_qry) ;
  while ($attachment_row = mysqli_fetch_assoc($attachment_res))
    {

      if($attachment_row['file']!='')
      {
       $mail->AddAttachment('uploads/'.$attachment_row['file'], $attachment_row['file']);
       $file.=$attachment_row['file'].',:';
      

      }
    }

$attachment_qry2 ="SELECT id,file
 FROM comments
 WHERE crmid=".$crmid." ";
  $attachment_res2 = mysqli_query($con , $attachment_qry2) ;
  while ($attachment_row2 = mysqli_fetch_assoc($attachment_res2))
    {
      if($attachment_row2['file']!=''){
      $mail->AddAttachment('uploads/'.$attachment_row2['file'], $attachment_row2['file']);
       $file.=$attachment_row2['file'].',:';
      
    }
    }
  $mail->IsSMTP();
  $mail->SMTPSecure = 'ssl';
  $mail->Host = 'ssl://smtp.zoho.com';
  $mail->SMTPAuth = true;
  $mail->Port = 465;

  // Set your existing gmail address as user name
  $mail->Username = 'nitin@eabyas.in';

  // Set the password of your gmail address here
  $mail->Password = '';

  if($mail->send())
    {  
      custom_crm_log($client,$body,$notifyto,$file,$crmid,$con); 
     }
 
   }

   function custom_crm_log($client,$body,$notifyto,$file,$crmid,$con)
   {
    // echo $body;
    // die();
    // $body = htmlspecialchars()
    $body = htmlspecialchars($body, ENT_QUOTES);

    $t = time();
     $sql = 'INSERT into custom_crm_log(crmid , client , notifyto,file,timecreated,body) values('.$crmid.',"'.$client.'", "'.$notifyto.'","'.$file.'",'.$t.',"'.$body.'")';
              if (mysqli_query($con, $sql))
              {
                echo "logged";
              }
              else{
                echo "not";
              }

   }
   ?>

