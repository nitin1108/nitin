<?php

$con=mysqli_connect("localhost","root","leooffice","my_crm");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

  if($con)
  {
  	$sql1 = "CREATE TABLE IF NOT EXISTS `users` (\n"
    . " `id` int(11) NOT NULL AUTO_INCREMENT,\n"
    . " `empid` int(11) NOT NULL ,\n"
    . " `username` varchar(255) NOT NULL,\n"
    . " `name` varchar(255) NOT NULL,\n"
    . " `email` varchar(255) NOT NULL,\n"
    . " `password` varchar(32) NOT NULL,\n"
    . " PRIMARY KEY (`id`)\n"
    . ") ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ";

    $sql2 = "CREATE TABLE IF NOT EXISTS `crm` (\n"
    . " `id` int(11) NOT NULL AUTO_INCREMENT,\n"
    . " `name` varchar(255) NOT NULL,\n"
    . " `file` varchar(255) NOT NULL,\n"
    . " `client` varchar(255) NOT NULL,\n"
    . " `requirement` text NOT NULL,\n"
    . " `timecreated` int(11) NOT NULL,\n"
    . " `timemodified` int(11) NOT NULL,\n"
    . " `usermodified` int(11) NOT NULL,\n"
    . " PRIMARY KEY (`id`)\n"
    . ") ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ";

	$sql3 = "CREATE TABLE IF NOT EXISTS `comments` (\n"
    . " `id` int(11) NOT NULL AUTO_INCREMENT,\n"
    . " `crmid` int(11) NOT NULL ,\n"
    . " `comment` longtext NOT NULL,\n"
    . " `file` varchar(255) NOT NULL,\n"
    . " `timecreated` int(11) NOT NULL,\n"
    . " `timemodified` int(11) NOT NULL,\n"
    . " `usermodified` int(11) NOT NULL,\n"
    . " PRIMARY KEY (`id`)\n"
    . ") ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ";

$sql4 = "CREATE TABLE IF NOT EXISTS `notify_on` (\n"
    . " `id` int(11) NOT NULL AUTO_INCREMENT,\n"
    . " `crmid` int(11) NOT NULL ,\n"
    . " `notifyon` varchar(255) NOT NULL,\n"
    . " `notifyto` varchar(255) NOT NULL,\n"
    . " `status` int NOT NULL DEFAULT 0,\n"
    . " `timecreated` int(11) NOT NULL,\n"
    . " `timemodified` int(11) NOT NULL,\n"
    . " `usermodified` int(11) NOT NULL,\n"
    . " PRIMARY KEY (`id`)\n"
    . ") ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ";

$sql5 = "CREATE TABLE IF NOT EXISTS `custom_crm_log` (\n"
    . " `id` int(11) NOT NULL AUTO_INCREMENT,\n"
    . " `crmid` varchar(32) NOT NULL,\n"
    . " `body` longtext NOT NULL,\n"
    . " `file` varchar(255) NOT NULL,\n"
    . " `notifyto` varchar(255) NOT NULL,\n"
    . " `timecreated` int(11) NOT NULL,\n"
    . " PRIMARY KEY (`id`)\n"
    . ") ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ";

    mysqli_query($con, $sql1);
		
  	mysqli_query($con, $sql2);
		
    mysqli_query($con, $sql3); 

    mysqli_query($con, $sql4); 

  	mysqli_query($con, $sql5); 

  }

?>
	    
	    