<?php
// echo __DIR__;
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']==''||empty($_SESSION['username']))
{ 
header("location: login.php");
}

$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap.min.css'>
    
    <title>CRM Form</title>
    <style>
    .change-margin{
      margin: 100px auto auto auto; 
     }
     </style>
  </head>
  <body>";
    require_once "dbconnect.php";
 
  $output .= "<section>

  <div class='container'> 
  <div class='col-4 change-margin '>  

<form action='' method='post' enctype='multipart/form-data'>";
if($_SESSION['uid']==1)
{
 $output.= "<div class='form-group'>
     <label for='lead'>Lead </label>
     <select name='lead'  class='custom-select'>";
     $lead_qry = 'SELECT id , username from users ';
     $lead_res = mysqli_query($con , $lead_qry) ;
     while ($lead_row = mysqli_fetch_assoc($lead_res)) {
     $output.= "<option  value='". $lead_row['id']."' >". $lead_row["username"]."</option>";
     }
     $output.="</select>
     </div>";
}
else{
$output.= "<div class='form-group'><label for='lead'>Lead </label>
     <select name='lead'  class='custom-select'>";
     $lead_qry = 'SELECT id , username from users where id="'.$_SESSION['uid'].'"';
     $lead_res = mysqli_query($con , $lead_qry) ;
     while ($lead_row = mysqli_fetch_assoc($lead_res)) {
     $output.= "<option  value='". $lead_row['id']."' selected disabled>". $lead_row["username"]."</option>";
     }
     $output.="</select>
     </div>";
}

$output.="<div class='form-group'>
    <label for='client'>Client</label>
    <input type='text' name='client' class='form-control' id='client' placeholder='Enter Client '>
  </div>
  
<div class='form-group'>
    <label for='requirement'>Requirement</label>
    <textarea  name='requirement' class='form-control' id='requirement' placeholder='Requirement' style='height: 150px'></textarea>
  </div>

    <div class='form-group'>
    <label for='file'>File input</label>
    <input type='file' class='form-control-file' name='file' id='file' aria-describedby='fileHelp'>
  </div>

<div class='button-align'>
<input type='submit' name='submit' class='btn btn-primary' value='Submit'>
  
<a href='index.php' class='text-white btn btn-primary' >Back</a>
  
</form>
";
 
  extract($_POST);

if(isset($_FILES['file']))
  {
    $tfname=$_FILES['file']['tmp_name'];
    $ufname=$_FILES['file']['name'];
   
    
    if(is_uploaded_file($tfname))
    {
      
          
          if(isset($submit))
          {
             if($_FILES['file']['size']<5242880)
             {
              $ranname = time();
              $ranname.=$ufname;
              $suc = move_uploaded_file($tfname, __DIR__.'/uploads/'.$ranname);
             }
            $timestamp = time();
              $uid = $_SESSION['uid'];
              if($uid!=1)
              {
                $lead = $uid;
              }
              // require_once "dbconnect.php";
              if(!empty($lead)&&!empty($client)&&!empty($requirement)){
              $sql = 'INSERT into crm(name , client , requirement , timecreated , usermodified,file)
                         values("'.$lead.'","'.$client.'","'.$requirement.'",'.$timestamp.','.$uid.',"'.$ranname.'")';
              if (mysqli_query($con, $sql))
              {
                $_SESSION['status']='crm';
                 header("Location: index.php");
              } 
              else
              {
                  $output .="<br><span class='text-danger'>not inserted</span>";
              }
              }
              else{
                $output .="<br><span class='text-danger'>All Fields Are Required</span>";
              }
          }

        


    }
  }


$output .="</div>
</div>
</section></body>
</html> ";

echo $output;
