<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']==''||empty($_SESSION['username']))
{ 
header("location: login.php");
}
require_once "config.php";
require_once "head.php";
require_once "nav.php";
 require_once "sidebar.php";  



  $output .=' <div class="container-fluid">
      <div class="row">';

    $output .='<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">';
    if(isset($_SESSION['status']))
    {
      $status = $_SESSION['status'];
      switch ($status) {
    case "comment":
        $output .='<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Comment Added Successfully!</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
unset($_SESSION['status']);
        break;
    case "crm":
       $output .='<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Ticket Added Successfully!</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
unset($_SESSION['status']);
        break;
        case "notified":
       $output .='<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Notified Successfully!</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
unset($_SESSION['status']);
        break; 
        case "commentupdated":
       $output .='<div class="alert alert-success" role="alert">
  <strong>Comment Updated Successfully!</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
unset($_SESSION['status']);
        break;   
       case "commentdeleted":
       $output .='<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Comment Deleted Successfully!</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
unset($_SESSION['status']);
        break;

    }
    }
    

         $output .='  <h2>Ticket Detail</h2><hr/>';
        if($_SESSION['uid']==1)
          { $crm_qry = "SELECT c.id,c.name ,c.client , c.requirement,c.timecreated,c.usermodified,u.username,c.file from crm as c join users as u on u.id=c.name ";}
        else{
          $crm_qry = "SELECT c.id,c.name ,c.client , c.requirement,c.timecreated,c.usermodified,u.username,c.file from crm as c join users as u on u.id=c.name where c.usermodified='".$_SESSION['uid']."'";
        }
           $crm_res = mysqli_query($con ,  $crm_qry) ;
           $output .='<div class="table-responsive">
            <table  class="table table-striped  table-bordered  example">
              <thead class="thead-dark ht">
                <tr>
                  <th><div >Client<span class="right"> Lead</span></div> </th>
                </tr>
              </thead>
              <tbody>';
              while($crm_row = mysqli_fetch_assoc($crm_res))
              {
                if($_SESSION['uid']==1)
                {
                  $comment_qry = "SELECT c.comment ,c.id as commentid ,c.file,cr.id  as crmid from comments as c 
                join crm as cr on c.crmid=cr.id where c.crmid='".$crm_row['id']."'";
              }
                else{
                  $comment_qry = "SELECT c.comment ,c.id as commentid ,c.file,cr.id  as crmid from comments as c 
                join crm as cr on c.crmid=cr.id where c.crmid='".$crm_row['id']."' AND c.usermodified='".$_SESSION['uid']."'";
                }
                $comment_res = mysqli_query($con ,  $comment_qry) ;
                $count =1;
                 $output .='<tr>
                  <td >
                  <div class="accordion">
                  <h3>'.$crm_row['client'].' <span class="right">'.$crm_row['username'].'</span></h3>
                   <div><p><table class="table table-bordered text-center"><thead class="thead-dark"><th>Requirement</th><th>file</th><th>action</th></thead><tr><td>'.$crm_row['requirement'].'</td>
                   <td>';
                   if($crm_row['file']!=''){
                    $output .=' <a href="download.php?file=' . urlencode($crm_row['file']) . '"><img src="images/download_icon.png" height="20px" width="20px" alt="Download" title="Download"></a>';
                   }
  
                  $output .='</td> <td><a href="notify.php" class="btn btn-primary btn-sm text-white">Notify On</a></td></tr></table><hr/></p><p><h3>Additional Requirements<span style="margin:0 0 0 62.5%;"><a href="comments.php?crmid='.$crm_row['id'].'" class="text-white btn btn-primary btn-sm align-self-end" style="text-decoration:none">Add</a></span></h3><table  class="table   text-center table-hover set-height "><thead class="thead-dark"><tr><th>Sr. No.</th><th>Comment</th><th>File</th><th colspan="2">Actions</th></tr></thead>';


                  while($comment_row = mysqli_fetch_assoc($comment_res))
                  {
                   $output.='<tr><td>'.$count.'</td>';
                   $output.= '<td>'.$comment_row['comment'].'</td><td>';
                   if($comment_row['file']!=''){
                      $output .=' <a href="download.php?file=' . urlencode($comment_row['file']) . '"><img src="images/download_icon.png" height="20px" width="20px" alt="Download" title="Download"></a>';
                    }                  
                   $output.= '</td><td><a href="edit_comment.php?commentid='.$comment_row['commentid'].'&crmid='.$comment_row['crmid'].'" ><img src="gear.png" height="20px" width="20px" alt="update comment" title="Update Comment"></a></td>';
                   $output.= '<td><a data-value="'.$comment_row["commentid"].'" class="del_comment" ><img src="delete.jpeg" height="20px" width="20px" alt="delete comment" title="Delete Comment"></a></td></tr>';
                   $count++;

                  }
                  $output .='</table></p></div>
                  </div>
                  </td>
                  </tr>';
              }
                $output .=' </tbody>
            </table>
          
        </div>
      </main>
    </div>
  </div>
<div id="dialog-confirm" title="Delete Confirmation..!">
  <p ><span class="ui-icon ui-icon-alert" style="float:left; margin:12px 12px 20px 0;"></span>Are You Sure To Delete Comment?</p>
</div>';
   require_once "script.php"; 
 $output.=' </body>
</html>';

echo  $output ;
    ?>

