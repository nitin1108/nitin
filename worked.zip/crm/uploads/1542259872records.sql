-- MySQL dump 10.13  Distrib 5.5.60, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: 25oct
-- ------------------------------------------------------
-- Server version	5.5.60-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'CobaltLMS'),(2,'CorporateLMS'),(3,'Misc'),(4,'Training Institute'),(5,'Moodle'),(6,'CMS'),(7,'Not required'),(8,'CobaltK12'),(9,'CorporateP');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientname` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `specified` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (22,'Cobalt Demo_Theme1(College of computer Engineering)','https://dev.theopenlms.com',1,NULL),(37,'Corporate  Site','https://dev.theopenlms.com',2,NULL),(40,'Canada Wood','https://dev.theopenlms.com',3,NULL),(43,'Leartefl site','https://dev.theopenlms.com',4,NULL),(45,'FIS Global','https://dev.theopenlms.com',5,'Mobile App'),(47,'Support Cobalt','https://dev.theopenlms.com',1,NULL),(49,'DY Patil','https://dev.theopenlms.com',1,NULL),(51,'Corporate LMS','https://dev.theopenlms.com',2,NULL),(55,'Tulane Development','https://dev.theopenlms.com',5,NULL),(56,'Vodafone','https://dev.theopenlms.com',5,NULL),(61,'Special Events Institute','https://dev.theopenlms.com',4,NULL),(81,'Open LMS','https://dev.theopenlms.com',2,NULL),(88,'C4ELink-Client Application','https://dev.theopenlms.com',1,'Course View'),(96,'DYPatil - Staging','https://dev.theopenlms.com',1,NULL),(99,'DY Patil (HTS) - Staging','https://dev.theopenlms.com',1,NULL),(100,'IRCLass','https://dev.theopenlms.com',4,NULL),(103,'Learn TEFL','https://dev.theopenlms.com',4,NULL),(104,'LnTLMS','https://dev.theopenlms.com',2,NULL),(107,'Fractal_Development','https://dev.theopenlms.com',2,NULL),(112,'Educatis eShop user','https://dev.theopenlms.com',6,'Courses'),(113,'Educatis LMS','https://dev.theopenlms.com',1,NULL),(114,'Educatis eShop admin','https://dev.theopenlms.com',6,NULL),(115,'Pennvet','https://dev.theopenlms.com',3,NULL),(116,'Tulane SCPHP ','https://dev.theopenlms.com',5,NULL),(120,'CCH','https://dev.theopenlms.com',1,'Courses'),(122,'Indian School of Business','https://dev.theopenlms.com',1,NULL),(123,'C4ELink','https://dev.theopenlms.com',1,NULL),(126,'TATA','https://dev.theopenlms.com',2,NULL),(128,'LnT','https://dev.theopenlms.com',2,NULL),(129,'GST','https://dev.theopenlms.com',2,NULL),(130,'Fractal','https://dev.theopenlms.com',0,NULL),(137,'CobaltLMS-2','https://dev.theopenlms.com',1,NULL),(138,'Zorac Metro','https://dev.theopenlms.com',7,NULL),(143,'Educatis','https://dev.theopenlms.com',7,NULL),(146,'NPA','https://dev.theopenlms.com',5,NULL),(147,'K12','https://dev.theopenlms.com',8,NULL),(148,'Kovida','https://dev.theopenlms.com',5,NULL),(149,'Eternal Global University ','https://dev.theopenlms.com',1,NULL),(151,'IGTB','https://dev.theopenlms.com',2,NULL),(152,'CDDS (Bangalore)','https://dev.theopenlms.com',5,NULL),(153,'Dypatil(mgmt)','https://dev.theopenlms.com',1,NULL),(154,'Analytics','https://dev.theopenlms.com',3,NULL),(155,'Cobalt-K12','https://dev.theopenlms.com',8,NULL),(156,'The open LMS - Bajaj ILLUME','https://dev.theopenlms.com',2,NULL),(157,'Exult','https://dev.theopenlms.com',7,NULL),(158,'TATA Upgarde','https://dev.theopenlms.com',7,NULL),(159,'LMS DEMO','https://dev.theopenlms.com',5,NULL),(162,'Moodle 3.4','https://dev.theopenlms.com',5,NULL),(163,'Dypatil(BTBI)','https://dev.theopenlms.com',1,NULL),(164,'e-Web Data','https://dev.theopenlms.com',3,NULL),(165,'Gamification','https://dev.theopenlms.com',3,NULL),(166,'OpenLMS 1.1','https://dev.theopenlms.com',2,NULL),(167,'TimesPro','https://dev.theopenlms.com',9,NULL),(168,'OpenLMS1.0','https://dev.theopenlms.com',2,NULL),(171,'OpenLMS (New)','https://dev.theopenlms.com',2,NULL),(172,'hp','',7,NULL),(173,'bc','https://dev.theopenlms.com',7,NULL),(174,'','https://dev.theopenlms.com',0,NULL),(181,'test','test',5,'test'),(182,'test','test',3,'test'),(183,'testclien','testclien',1,'testclien'),(184,'testclien','testclien',1,'testclien'),(185,'testclien12321','jhhjhjg',3,'jghjjghj'),(186,'gdfgdfg','gfdgdf',4,'gfdgdd');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(25) NOT NULL,
  `role` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `entertedby` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=562 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (72,22,'Admin1234','xyz','xyz@123','Rajeshwar','10-31-18'),(119,37,'Admin','xyz','xyz@123','Rajeshwar','08-12-15'),(120,37,'Regional Manager','xyz','xyz@123','Rajeshwar','08-12-15'),(121,37,'Zonal Manager','xyz','xyz@123','Rajeshwar','08-12-15'),(122,37,'Area Manager','xyz','xyz@123','Rajeshwar','08-12-15'),(124,37,'Employee','xyz','xyz@123','Rajeshwar','08-12-15'),(125,37,'Employee','xyz','xyz@123','Rajeshwar','08-12-15'),(126,37,'Employee','xyz','xyz@123','Rajeshwar','08-12-15'),(133,40,'Admin','xyz','xyz@123','Rajeshwar','08-12-15'),(134,40,'Office Admin','xyz','xyz@123','Rajeshwar','08-12-15'),(135,40,'Instructor','xyz','xyz@123','Rajeshwar','08-12-15'),(142,43,'Tutor','xyz','xyz@123','Rajeshwar','08-12-15'),(143,43,'Student','xyz','xyz@123','Rajeshwar','08-12-15'),(145,45,'Admin','xyz','xyz@123','Rajeshwar','08-12-15'),(146,45,'Teacher','xyz','xyz@123','Rajeshwar','08-12-15'),(147,45,'Student','xyz','xyz@123','Rajeshwar','08-12-15'),(149,47,'Admin','xyz','xyz@123','Rajeshwar','08-12-15'),(151,49,'Admin','xyz','xyz@123','Rajeshwar','08-12-15'),(152,49,'Registrar','xyz','xyz@123','Rajeshwar','08-12-15'),(153,49,'Student','xyz','xyz@123','Rajeshwar','08-12-15'),(154,49,'Instructor','xyz','xyz@123','Rajeshwar','08-12-15'),(155,49,'Mentor','xyz','xyz@123','Rajeshwar','08-12-15'),(165,51,'Admin','xyz','xyz@123','Rajeshwar','03-15-16'),(166,51,'Training Manager','xyz','xyz@123','Rajeshwar','03-15-16'),(167,51,'Team Manager','xyz','xyz@123','Rajeshwar','03-15-16'),(168,51,'Employee','xyz','xyz@123','Rajeshwar','03-15-16'),(180,55,'Admin','xyz','xyz@123','Rajeshwar','08-12-15'),(181,56,'Admin','xyz','xyz@123','Rajeshwar','08-12-15'),(186,61,'Admin','xyz','xyz@123','Rajeshwar','08-12-15'),(215,81,'Admin','xyz','xyz@123','Rajeshwar','10-15-15'),(216,81,'Instructor','xyz','xyz@123','Rajeshwar','10-15-15'),(217,81,'Instructor','xyz','xyz@123','Rajeshwar','10-15-15'),(218,81,'Instructor','xyz','xyz@123','Rajeshwar','10-15-15'),(219,81,'Learner','xyz','xyz@123','Rajeshwar','10-15-15'),(220,81,'Learner','xyz','xyz@123','Rajeshwar','10-15-15'),(221,81,'Learner','xyz','xyz@123','Rajeshwar','10-15-15'),(222,81,'Learner','xyz','xyz@123','Rajeshwar','10-15-15'),(223,81,'Learner','xyz','xyz@123','Rajeshwar','10-15-15'),(224,81,'Learner','xyz','xyz@123','Rajeshwar','10-15-15'),(243,88,'Administrator','xyz','xyz@123','Rajeshwar','11-01-18'),(244,88,'Instructor','xyz','xyz@123','Rajeshwar','03-01-16'),(245,88,'student','xyz','xyz@123','Manasa','03-01-16'),(246,88,'Reviewer','xyz','xyz@123','Rajeshwar','03-01-16'),(247,88,'Support person','xyz','xyz@123','Rajeshwar','03-01-16'),(269,96,'admin','xyz','xyz@123','Prashanthi','06-28-17'),(288,100,'admin','xyz','xyz@123','','05-24-16'),(295,103,'','xyz','xyz@123','','07-12-16'),(296,104,'Business Unit Head','xyz','xyz@123','Rajeshwar','08-02-16'),(297,104,'Competency Manager ','xyz','xyz@123','Rajeshwar','08-02-16'),(298,104,'TTPOC','xyz','xyz@123','Rajeshwar','08-02-16'),(299,104,'TLC','xyz','xyz@123','Rajeshwar','08-02-16'),(300,104,'LM','xyz','xyz@123','Rajeshwar','08-02-16'),(301,104,'Employee','xyz','xyz@123','Rajeshwar','08-02-16'),(302,104,'IS','xyz','xyz@123','Rajeshwar','08-02-16'),(303,104,'CA','xyz','xyz@123','Rajeshwar','08-02-16'),(304,104,'SME','xyz','xyz@123','Rajeshwar','08-02-16'),(305,104,'IP','xyz','xyz@123','Rajeshwar','08-02-16'),(308,107,'Admin','xyz','xyz@123','Rajeshwar','08-17-16'),(309,107,'LA','xyz','xyz@123','Rajeshwar','08-17-16'),(310,107,'TC','xyz','xyz@123','Rajeshwar','08-17-16'),(311,107,'CA','xyz','xyz@123','Rajeshwar','08-17-16'),(312,107,'HOD','xyz','xyz@123','Rajeshwar','08-17-16'),(316,104,'admin','xyz','xyz@123','Abhinav','09-21-16'),(323,113,'Admin','xyz','xyz@123','Abhinav','09-21-16'),(324,114,'Admin','xyz','xyz@123','Abhinav','09-21-16'),(325,115,'Admin','xyz','xyz@123','/@dmin1234$\n','09-21-16'),(327,116,'Student ','xyz','xyz@123','Abhinav','12-09-16'),(331,99,'Admin','xyz','xyz@123','Abhinav','05-31-17'),(340,120,'Admin12','xyz','xyz@123','Abhinav','11-01-18'),(344,120,'Student','xyz','xyz@123','Abhinav','02-02-17'),(345,112,'abc','xyz','xyz@123','Abhinav','11-01-18'),(347,122,'Admin','xyz','xyz@123','Abhinav','02-03-17'),(349,107,'HOD','xyz','xyz@123','Abhinav','02-03-17'),(352,122,'Instructor User','xyz','xyz@123','Abhinav','02-03-17'),(353,122,'Student User','xyz','xyz@123','Abhinav','02-03-17'),(354,123,'Admin	','xyz','xyz@123','Abhinav','02-06-17'),(355,123,'Instructor','xyz','xyz@123','Abhinav','02-06-17'),(356,123,'Instructor','xyz','xyz@123','Abhinav','02-06-17'),(357,123,'Student','xyz','xyz@123','Abhinav','02-06-17'),(360,126,'Admin','xyz','xyz@123','Shyam','03-21-17'),(369,129,'Admin','xyz','xyz@123','Shyam','03-21-17'),(370,129,'training Coordinator','xyz','xyz@123','Shyam','03-21-17'),(371,129,'User','xyz','xyz@123','Shyam','03-21-17'),(372,130,'Admin','xyz','xyz@123','Shyam','03-21-17'),(373,126,'Employee','xyz','xyz@123','Nirupa','03-31-17'),(384,128,'Admin','xyz','xyz@123','Usha','05-23-17'),(385,128,'Content Author(CA)','xyz','xyz@123','Usha','05-23-17'),(386,31,'BU HEAD','xyz','xyz@123','Shyam','05-22-17'),(387,128,'Business Unit Head(BUH)','xyz','xyz@123','Usha','05-23-17'),(394,128,'Immediate Supervisor(IS)','xyz','xyz@123','Usha','05-23-17'),(395,128,'Learning Manager(LM)','xyz','xyz@123','Usha','05-23-17'),(396,128,'Competency Manager(CM)','xyz','xyz@123','Usha','05-23-17'),(397,128,'Learning Head(LH)','xyz','xyz@123','Usha','05-23-17'),(398,128,'Technical Learning Coordinator(TLC)','xyz','xyz@123','Usha','05-23-17'),(399,128,'TSIC Head','xyz','xyz@123','Usha','05-23-17'),(400,128,'TTPOC','xyz','xyz@123','Usha','05-23-17'),(401,128,'Subject Matter Expert(SME)','xyz','xyz@123','Usha','05-23-17'),(402,128,'Employee 1','xyz','xyz@123','Usha','05-23-17'),(403,128,'IP','xyz','xyz@123','Usha','05-23-17'),(404,128,'Employee 2','xyz','xyz@123','Usha','05-23-17'),(408,128,'IDP ADMIN ','xyz','xyz@123','Usha','05-23-17'),(409,137,'Admin','xyz','xyz@123','Shyam','07-17-17'),(432,143,'Admin','xyz','xyz@123','Shyam','05-30-17'),(435,140,'sdfsd','xyz','xyz@123','dsfsd','06-03-17'),(443,146,'Admin','xyz','xyz@123','Rajeshwar','06-09-17'),(444,146,'Faculty','xyz','xyz@123','Rajeshwar','06-09-17'),(445,146,'Student','xyz','xyz@123','Rajeshwar','06-09-17'),(446,147,'School Head','xyz','xyz@123','Prashanthi','06-19-17'),(447,147,'Class Teacher','xyz','xyz@123','Prashanthi','06-19-17'),(448,147,'Teacher','xyz','xyz@123','Prashanthi','06-19-17'),(449,148,'Organization Admin','xyz','xyz@123','Prashanthi','09-27-17'),(453,149,'Organization','xyzz','xyz@123','Usha','10-31-18'),(463,151,'Admin','xyz','xyz@123','Usha','07-04-17'),(464,151,'Unit Head/IGTB','xyz','xyz@123','Usha','07-04-17'),(467,147,'Admin','xyz','xyz@123','','07-04-17'),(468,147,'Teacher','xyz','xyz@123','Prashanthi','07-04-17'),(469,152,'Admin','xyz','xyz@123','Rajeshwar','07-14-17'),(470,153,'Admin','xyz','xyz@123','Prashanthi','07-17-17'),(471,153,'Student','xyz','xyz@123','Prashanthi','07-17-17'),(474,153,'Faculty','xyz','xyz@123','Prashanthi','07-17-17'),(475,154,'Admin','xyz','xyz@123','Prashanthi','07-17-17'),(476,155,'Admin','xyz','xyz@123','Shyam','09-07-17'),(477,155,'Registrar','xyz','xyz@123','Shyam','09-07-17'),(478,155,'Instructor','xyz','xyz@123','Shyam','09-07-17'),(479,155,'Student','xyz','xyz@123','Shyam','09-07-17'),(481,156,'Org admin ','xyz','xyz@123','Prashanthi','08-16-17'),(482,156,'Training coordinator','xyz','xyz@123','Prashanthi','08-16-17'),(483,156,'Course manager','xyz','xyz@123','Prashanthi','08-16-17'),(484,156,'Supervisor','xyz','xyz@123','Prashanthi','08-16-17'),(485,156,'Trainer','xyz','xyz@123','Prashanthi','08-16-17'),(486,156,'End user 1','xyz','xyz@123','Prashanthi','08-16-17'),(487,156,'End user 2','xyz','xyz@123','Prashanthi','08-16-17'),(488,156,'End user 3','xyz','xyz@123','Prashanthi','08-16-17'),(489,156,'End user 4','xyz','xyz@123','Prashanthi','08-16-17'),(490,156,'End user 5','xyz','xyz@123','Prashanthi','08-16-17'),(491,157,'Admin','xyz','xyz@123','Rajeshwar','08-29-17'),(492,157,'Student','xyz','xyz@123','Rajeshwar','08-29-17'),(497,158,'Admin','xyz','xyz@123','Rajeshwar','10-24-17'),(498,158,'HR-NTH','xyz','xyz@123','Rajeshwar','10-24-17'),(499,158,'AST-NH','xyz','xyz@123','Rajeshwar','10-24-17'),(500,158,'PD-NH','xyz','xyz@123','Rajeshwar','10-24-17'),(501,158,'Trainer','xyz','xyz@123','Rajeshwar','10-24-17'),(502,159,'Organization Head','xyz','xyz@123','Usha','11-02-17'),(503,159,'Training Coordinator','xyz','xyz@123','Usha','11-02-17'),(504,159,'Course Manager','xyz','xyz@123','Usha','11-02-17'),(505,159,'Trainer','xyz','xyz@123','Usha','11-02-17'),(506,159,'Academy Head','xyz','xyz@123','Usha','11-02-17'),(507,159,'Team Manager','xyz','xyz@123','Usha','11-02-17'),(508,159,'Employee 1','xyz','xyz@123','Usha','11-02-17'),(509,159,'Employee 2','xyz','xyz@123','Usha','11-02-17'),(511,126,'','xyz','xyz@123','','12-26-17'),(512,162,'Admin','xyz','xyz@123','Prashanthi','01-02-18'),(513,162,'Teacher','xyz','xyz@123','Prashanthi','01-02-18'),(514,162,'Student','xyz','xyz@123','Prashanthi','01-02-18'),(515,163,'admin','xyz','xyz@123','prashanthi','02-09-18'),(516,163,'Instructor','xyz','xyz@123','prashanthi','02-09-18'),(517,163,'Student','xyz','xyz@123','prashanthi','02-09-18'),(518,164,'Delhi-OH','xyz','xyz@123','Prashanthi','02-12-18'),(519,164,'Delhi-Training coordinator','xyz','xyz@123','Prashanthi','02-12-18'),(520,164,'Delhi-Course manager','xyz','xyz@123','Prashanthi','02-12-18'),(521,164,'Delhi-Trainer','xyz','xyz@123','Prashanthi','02-12-18'),(522,164,'Delhi-Team manager','xyz','xyz@123','Prashanthi','02-12-18'),(523,164,'Delhi-Employee1','xyz','xyz@123','Prashanthi','02-12-18'),(524,164,'Delhi-Employee2','xyz','xyz@123','Prashanthi','02-12-18'),(525,164,'Delhi-Employee3','xyz','xyz@123','Prashanthi','02-12-18'),(526,164,'Mumbai-OH','xyz','xyz@123','Prashanthi','02-12-18'),(527,164,'Mumbai-Training coordinator','xyz','xyz@123','Prashanthi','02-12-18'),(528,164,'Mumbai-Course manager','xyz','xyz@123','Prashanthi','02-12-18'),(529,164,'Mumbai-Trainer','xyz','xyz@123','Prashanthi','02-12-18'),(530,164,'Mumbai-Team manager','xyz','xyz@123','Prashanthi','02-12-18'),(531,164,'Mumbai-Employee1','xyz','xyz@123','Prashanthi','02-12-18'),(532,164,'Mumbai-Employee2','xyz','xyz@123','Prashanthi','02-12-18'),(533,165,'Admin','xyz','xyz@123','Prashanthi','02-26-18'),(534,165,'Student 1','xyz','xyz@123','Prashanthi','02-26-18'),(535,165,'Student 2','xyz','xyz@123','Prashanthi','02-26-18'),(536,166,'Admin','xyz','xyz@123','Rajeshwar','04-25-18'),(537,166,'OH','xyz','xyz@123','Rajeshwar','04-25-18'),(538,166,'OH','xyz','xyz@123','Rajeshwar','04-25-18'),(539,166,'OH','xyz','xyz@123','Rajeshwar','04-25-18'),(540,166,'Trainer','xyz','xyz@123','Rajeshwar','04-25-18'),(541,166,'Employee','xyz','xyz@123','Rajeshwar','04-25-18'),(542,167,'Admin','xyz','xyz@123','Rajeshwar','04-25-18'),(543,167,'Manager','xyz','xyz@123','Rajeshwar','04-25-18'),(544,167,'Faculty','xyz','xyz@123','Rajeshwar','04-25-18'),(545,167,'Student','xyz','xyz@123','Rajeshwar','04-25-18'),(546,167,'Student','xyz','xyz@123','Rajeshwar','04-25-18'),(547,168,'OH','xyz','xyz@123','Rajeshwar','05-03-18'),(548,168,'Employee','xyz','xyz@123','Rajeshwar','05-03-18'),(549,168,'Employee','xyz','xyz@123','Rajeshwar','05-03-18'),(550,146,'Admin','xyz','xyz@123','Rajeshwar','05-23-18'),(551,146,'Faculty','xyz','xyz@123','Rajeshwar','05-23-18'),(552,146,'Student','xyz','xyz@123','Rajeshwar','05-23-18'),(553,146,'Student','xyz','xyz@123','Rajeshwar','05-23-18'),(554,146,'Admin','xyz','xyz@123','Rajeshwar','05-23-18'),(555,146,'Faculty','xyz','xyz@123','Rajeshwar','05-23-18'),(556,146,'Student','xyz','xyz@123','Rajeshwar','05-23-18'),(557,146,'Student','xyz','xyz@123','Rajeshwar','05-23-18'),(558,171,'Admin','xyz','xyz@123','Nirupa','07-26-18'),(559,171,'OH','xyz','xyz@123','Nirupa','10-31-18'),(560,172,'','xyz','xyz@123','','10-22-18'),(561,173,'','xyz','xyz@123','','10-23-18');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-01 13:09:41
