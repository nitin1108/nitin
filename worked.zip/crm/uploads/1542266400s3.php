<?php
 ini_set('display_errors', 'On');
error_reporting(E_ALL | E_STRICT);
session_start();
?>
<html>
<head>
<script>
	function validate() {
        var x = document.forms["myForm"]["username"].value;
	    var x1 = document.forms["myForm"]["password"].value;
		if(x==null||x==""){
		alert("Name must be filled out");
		return false;
        }
		if (x1 == null || x1 == ""){
			alert("password must be filled out");
			return false;
		}	
    }
</script>	
<?php
$servername="localhost";
$username="root";
$password="leooffice";
$dbname="myDB";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
    die("connection failed:" .$conn->connect_error);
}
//echo "connected successfully";
if($_SERVER["REQUEST_METHOD"] == "POST")
{
if(isset($_POST['submit'])) 
        {
		 $uname = $_POST['username']; 
        $password = $_POST['password'];
		$_SESSION['token'] = $uname;
	  //$ld=$_POST['username'];
	 $_SESSION['ld'] = $password;
	 $role = $_SESSION['role'];
	//if($_POST['username'] == $_SESSION['token']){	 

if($uname == $_POST['username'] and $password == $_POST['password']){
    $_SESSION['sid']=session_id();
	header("location:s5.php");
}      
$sql="SELECT id, username, password FROM emp WHERE username='$uname' AND password='$password'";
print_r($sql);
$result1 = $conn->query($sql);
print_r($result1);

             if($result1->num_rows>0)
            {
				
                  header("Location: http://localhost/htmltemp/s5.php");
   
            }
            else
            {
               header("Location: http://localhost/htmltemp/s3.php");
               die();  
			}
			
  //  }
}
}
?>
<title>Login Page</title>
<style>
  .head{
                background-color:#6495ED;
                padding: 3px;			
   }
   h1{
	font-size:40px;
	color: white;
	width: 85%;
	
	text-align: right;
   }
   .s1 img{
	width: 12%;
	float:left;
	margin-left:150px;
	margin-top: 10px; 
   }
form{
    border:1px solid #6495ED;
    padding: 10px;
    width:25%;
    margin:170px 450px 0;
}
.foot{
 background-color:#708090;
 text-align: center;
 color: white;
 font-size:20px;
 margin-top:60px; 
}
.r1{
 margin-right:30px;
 text-align: justify;
}
.r2{
 margin-right:35px;
 text-align: justify;
}
.r3{
 margin-left:150px; 
}
.r4{
 padding:30px;
 font-size:30px;
 text-align: center;
 margin-left:70px;
}
.r7{
   text-align: right;
   margin-right: 70px;
    margin-top: 75px;
	font-size:20px;
}
input{
 padding: 2px;
}
</style>
</head>
<body>
 <div class="head">
  <div class=s1>
   <img src="pic_img.jpg" alt="image">
   </div>
  <h1>Employee   Login   page</h1>
  
 </div>
<form name="myForm"  method="post" onsubmit="return validate()">
<span class="r4">Login Page</span><br>
<br>
<span class="r1">Username:</span>
<input type="text" name="username"></input><br>
<br>
<span class="r2">Password:</span>
<input type="password" name="password"></input><br><br>
<span class="r3">
<input type="submit" name="submit" value="Submit"></span>
</form>
<div class="r7">
 <a href="http://localhost/htmltemp/s4.php">Do not have an account?</a>
</div>
<div class="foot">
 <h2>Employees &#169 2016. Privacy Policy</h2>
</div>
<?php
if(isset($_POST['submit1'])) {
	 $uname = $_POST['username']; 
        $password = $_POST['password'];
		$confirmpassword=$_POST['confirmpassword'];
		$email=$_POST['email'];
		$phoneno=$_POST['phoneno'];
		$DOB=$_POST['DOB'];
		$gender=$_POST['gender'];
		$timings=$_POST['timings'];
		$role=$_POST['role'];
		$course=$_POST['course'];
		$sql1="INSERT INTO emp (username,password,confirmpassword,email,phoneno,DOB,gender,timings,role,course)
		VALUES ('$uname','$password','$confirmpassword','$email','$phoneno','$DOB','$gender','$timings','$role','$course')";
		//print_r($sql1);
		if($conn->query($sql1)===TRUE){
			echo "records inserted";
		}
		else{
			echo "Error: " . $sql . "<br>" . $conn->error;
		}
}
$conn->close();
?>
</body>
</html>