<?php
     // Icons 
   $output.="<script src='feather.min.js'></script>
    
    <script>
      $(document).ready(function() {
        
         
        $( '.accordion' ).accordion({
      
      active:false,
      collapsible: true
    });
    $('.example').DataTable();
 		      feather.replace();

         $( '#dialog-confirm' ).dialog({
        autoOpen: false
    });


$('.del_comment').click(function(){
  var cid = $(this).attr('data-value');
  var cid = parseInt(cid);

  
  
    $( '#dialog-confirm' ).dialog('open');

    $( '#dialog-confirm' ).dialog({
     
      resizable: false,
      height: 'auto',
      width: 400,
      modal: true,
      buttons: {
        'Delete': function() {
          $( this ).dialog( 'close' );
          
          window.location.replace('delete_comment.php?cid='+cid);
        },
        Cancel: function() {
          $( this ).dialog( 'close' );
        }
      }
    });


    });
    });

    </script>";

 ?>