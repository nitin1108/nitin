<?php

$output=' ';
$output.='<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">

    <title>Dashboard | Ticket</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.css" rel="stylesheet">
    <link href="datatable.bootstrap.min.css" rel="stylesheet">
    <link href="jqui.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
    <script src="jquery.js"></script>
    <script src="jqui.js"></script>
    <script src="datatable.min.js"></script>
    <script src="datatable.bootstrap.min.js"></script>
    <script src="bootstrap.min.js"></script>
    
    <style>
    div span.left{
      float :left;
    }
     div span.right{
      float :right;
    }
    .set-height{
       height: auto !important;
    }
    
    .ht{
      height: 40px;;
    }
       


    </style>


  </head>

  <body>';

  ?>