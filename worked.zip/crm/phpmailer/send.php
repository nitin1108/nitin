<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require 'class.phpmailer.php';
require 'class.smtp.php';

$mail = new PHPMailer;
$mail->setFrom('nitin@eabyas.in');
$mail->addAddress('nitin.m5432@gmail.com');
$mail->Subject = 'Message sent by PHPMailer';
$mail->Body = 'Hello! use PHPMailer to send email using PHP';
$mail->IsSMTP();
$mail->SMTPSecure = 'ssl';
$mail->Host = 'ssl://smtp.zoho.com';
$mail->SMTPAuth = true;
$mail->Port = 465;

//Set your existing gmail address as user name
// $mail->Username = 'nitin@eabyas.in';

//Set the password of your gmail address here
// $mail->Password = 's';
if(!$mail->send()) {
  echo 'Email is not sent.';
  echo 'Email error: ' . $mail->ErrorInfo;
} else {
  echo 'Email has been sent.';
}



// require 'PHPMailerAutoload.php';


// $mail = new PHPMailer;
// // $mail->SMTPDebug = 2;                               // Enable verbose debug output

// $mail->isSMTP();                                      // Set mailer to use SMTP
// $mail->Host = 'tls://smtp.zoho.com';  // Specify main and backup SMTP servers
// $mail->SMTPAuth = true;                               // Enable SMTP authentication
// $mail->Username = 'nitin@eabyas.in';                 // SMTP username
// $mail->Password = '';                           // SMTP password
// $mail->Port = 587;                                    // TCP port to connect to

// $mail->From = 'nitin@eabyas.in';
// $mail->FromName = 'Nitin Marawar';
// $mail->addAddress('nitin.m5432@gmail.com');               // Name is optional
// $mail->addAddress('marawarnitinkumar7@gmail.com');               // Name is optional

// $mail->isHTML(true);                                  // Set email format to HTML

// $mail->Subject = 'Here is the subject';
// $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
// $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

// if(!$mail->send()) {
//     echo 'Message could not be sent.';
//     echo 'Mailer Error: ' . $mail->ErrorInfo;
// } else {
//     echo 'Message has been sent';
// }

?>