<?php

clearstatcache();
// echo fileatime("delete.jpeg");
echo "<br />";
echo "Last access: ".date("F d Y H:i:s.",fileatime("gear.png"));

?>