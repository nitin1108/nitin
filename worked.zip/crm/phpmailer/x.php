<?php

$str='&lt;!DOCTYPE html PUBLIC &quot;-//W3C//DTD XHTML 1.0 Transitional//EN&quot; &quot;http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd&quot;&gt;
&lt;html xmlns=&quot;http://www.w3.org/1999/xhtml&quot;&gt;
    &lt;head&gt;
        &lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;text/html; charset=UTF-8&quot; /&gt;
        &lt;title&gt;&lt;/title&gt;
        &lt;style&gt;&lt;/style&gt;
    &lt;/head&gt;
    &lt;body&gt;
    &lt;h3&gt;HI, This is remainder for Client cl21&lt;/h3&gt;
        &lt;table border=&quot;0&quot; cellpadding=&quot;0&quot; cellspacing=&quot;0&quot;   id=&quot;bodyTable&quot;&gt;
            &lt;tr&gt;
                &lt;td align=&quot;center&quot; valign=&quot;top&quot;&gt;
                    &lt;table border=&quot;1&quot; cellpadding=&quot;20&quot; cellspacing=&quot;0&quot;  id=&quot;emailContainer&quot;&gt;
                    
                    &lt;tr&gt;
                            &lt;th align=&quot;center&quot; valign=&quot;top&quot; &gt;
                                Client.
                            &lt;/th&gt;                            
                            &lt;th align=&quot;center&quot; valign=&quot;top&quot; &gt;
                               Requirement
                            &lt;/th&gt;                            
                            &lt;th align=&quot;center&quot; valign=&quot;top&quot; &gt;
                                Comment
                            &lt;/th&gt;
                            
                        &lt;/tr&gt;
                        &lt;tr&gt;
                            &lt;td align=&quot;center&quot; valign=&quot;top&quot;&gt;
                                cl21
                            &lt;/td&gt;                            
                            &lt;td align=&quot;center&quot; valign=&quot;top&quot;&gt;
                                req cl21 by xyz
                            &lt;/td&gt;                        
                                &lt;td align=&quot;center&quot; valign=&quot;top&quot;&gt;
                                1) add re1 cl21 admin&lt;br&gt;2) add re2 cl21 admin&lt;br&gt;3) add re4 cl21 admin&lt;br&gt;
                            &lt;/td&gt;    
                        &lt;/tr&gt;
                    &lt;/table&gt;
                &lt;/td&gt;
            &lt;/tr&gt;
        &lt;/table&gt;
    &lt;/body&gt;
&lt;/html&gt;';

echo htmlspecialchars_decode($str);
