<?php
echo time();
echo '<br>';
echo date('y-m-d',time());
$x="2018-11-14";
$y=strtotime($x);
echo '<br>'.$y;
$z = date('y-m-d',$y);
echo '<br>'.$z;

$con=mysqli_connect("localhost","root","leooffice","my_crm");
$qry = 'SELECT * from '

?>