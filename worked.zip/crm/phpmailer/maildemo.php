<?php


$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap.min.css'>
    
    <title>Mail Form</title>
    <style>
    .change-margin{
      margin: 100px auto auto auto; 
     }
     </style>
  </head>
  <body>";
   
 
  $output .= "<section>

  <div class='container'> 
  <div class='col-4 change-margin '>  

<form action='send.php' method='post' >

<div class='form-group'>
    <label for='name'>Name</label>
    <input type='text' name='name' class='form-control' id='name' placeholder='Enter Name'>
  </div>

<div class='form-group'>
    <label for='reciepient'>Recipient email</label>
    <input type='email' name='reciepient' class='form-control' id='reciepient' placeholder='Enter Reciepient '>
  </div>
  <div class='form-group'>
    <label for='subject'>Subject</label>
    <input type='text' name='subject' class='form-control' id='subject' placeholder='Enter Subject '>
  </div>
  
<div class='form-group'>
    <label for='message'>Message</label>
    <textarea  name='message' class='form-control' id='message' placeholder='Message' style='height: 150px'></textarea>
  </div>

<div class='button-align'>
<input type='submit' name='send' class='btn btn-primary' value='Send'>
  
<a href='index.php' class='text-white btn btn-primary' >Back</a>
  
</form>
";
 
  

$output .="</div>
</div>
</section></body>
</html> ";

echo $output;





    

  



















