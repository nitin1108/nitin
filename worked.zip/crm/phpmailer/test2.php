

<?php
 require 'class.phpmailer.php';
  require 'class.smtp.php';

$y = date('Y-m-d',time());
 // echo $y;
$con = mysqli_connect("localhost","root","leooffice","my_crm");

$qry = 'SELECT * from notify_on where notifyon="'.$y.'"'; 

 $res = mysqli_query($con , $qry) ;

 while ($row = mysqli_fetch_assoc($res))
  {
 
  	$qry1 = "SELECT client ,requirement from crm where id='".$row['crmid']."'";
  	$res1 = mysqli_query($con , $qry1) ;
  	while ($row1 = mysqli_fetch_assoc($res1))
  	{
  		$client = $row1['client'];
  		$requirement = $row1['requirement'];
  	}
  	$qry2 = "SELECT comment from comments where crmid='".$row['crmid']."'";
  	$res2 = mysqli_query($con , $qry2) ;
  	while ($row2 = mysqli_fetch_assoc($res2))
  	{
  		$comment.= $row2['comment'].'<br>';
  		
  	}
    $notifyto = $row['notifyto'];
    $crmid = $row['crmid'];
   // echo $notifyto;
    // die();
    custom_crm_mail($client,$comment,$requirement,$notifyto,$con,$crmid); 
    $comment= ' ';
   }

   function custom_crm_mail($client,$comment,$requirement,$notifyto,$con,$crmid)
   {
    $qry3 = "SELECT id,name ,email
 FROM users 
 WHERE id IN (".$notifyto.") ";
 
  $res3 = mysqli_query($con , $qry3) ;
   $mail = new PHPMailer;
  $mail->setFrom('nitin@eabyas.in','Admin');

    while ($row3 = mysqli_fetch_assoc($res3))
    {
      // echo $row3['email'].' ';
      // echo $row3['name'].'<br>';
      $mail->addAddress($row3['email'],$row3['name']);
    }
  
$mail->isHTML(true);

  $mail->Subject = 'This is remainder for client '.$client;
  $body = '<html><body>';

$body .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
$body .= "<tr style='background: #eee;'><td><strong>Client Name:</strong> </td><td>" . $client . "</td></tr>";
$body .= "<tr><td><strong>Requirement</strong> </td><td>" . $requirement. "</td></tr>";
$body .= "<tr><td rowspan='2'><strong>Comments:</strong> </td></tr><tr><td rowspan='2'>" . $comment . "</td></tr>";

$body .= "</table>";
$body .= "</body></html>";
   $mail->Body = $body;

  $mail->IsSMTP();
  $mail->SMTPSecure = 'ssl';
  $mail->Host = 'ssl://smtp.zoho.com';
  $mail->SMTPAuth = true;
  $mail->Port = 465;

  // Set your existing gmail address as user name
  $mail->Username = 'nitin@eabyas.in';

  // Set the password of your gmail address here
  $mail->Password = 'Nitinm#0';

  $mail->send();
 
   }
	
 ?>