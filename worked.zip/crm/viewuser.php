<?php

session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']!=1)
{ 
header("location: index.php");
}
$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap.css'>
    <link rel='stylesheet' href='jqui.css'>
    <link href='datatable.bootstrap.min.css' rel='stylesheet'>

    <script src='jquery.js'></script>
    <script src='jqui.js'></script>
    
    <script src='datatable.min.js'></script>
    <script src='datatable.bootstrap.min.js'></script>


    <script>
$(document).ready(function() {
	  $( '#dialog-confirm' ).dialog({
        autoOpen: false
    });

    $('.example').DataTable();

    $('.del_user').click(function(){
  var uid = $(this).attr('data-value');
  var uid = parseInt(uid);


       
    $( '#dialog-confirm' ).dialog('open');

    $( '#dialog-confirm' ).dialog({
     
      resizable: false,
      height: 'auto',
      width: 400,
      modal: true,
      buttons: {
        'Delete': function() {
          $( this ).dialog( 'close' );
          
          window.location.replace('delete_user.php?uid='+uid);
        },
        Cancel: function() {
          $( this ).dialog( 'close' );
        }
      }
    });


    });

} );
</script>

    <title>Manage User</title>
    <style>
    body{
    	margin : 50px auto auto auto;
    }</style>
  </head>
  <body><div class='container'><h3>Manage User
  <span style='margin:0 0 0 77%;'><a href='adduser.php' class='btn btn-primary btn-sm ' style='text-decoration:none'>Add User</a></span></h3><hr/>";



require_once "dbconnect.php";

$sql = 'SELECT * FROM `users` ';

if ($res = mysqli_query($con, $sql))
{
	$count = 1;
	$output.='<table   class="table table-striped table-bordered text-center example"><thead><tr><th>Sr. No.</th><th>Name</th><th>Username</th><th>E-Mail</th><th>Employee ID</th><th>Password</th><th>Update</th><th>Delete</th></tr></thead><tbody>';
	while($row = mysqli_fetch_assoc($res))
	{
		$output.='<tr><td>'.$count.'</td>';
    $output.='<td>'.$row["name"].'</td>';
		$output.='<td>'.$row["username"].'</td>';
		$output.='<td>'.$row["email"].'</td>';
		$output.='<td>'.$row["empid"].'</td>';
		$output.='<td>'.$row["password"].'</td>';
		$output.= '<td><a href="edit_user.php?uid='.$row['id'].'" >
		           <img src="gear.png" height="20px" width="20px" alt="Edit User" title="Edit User"></a></td>';
        $output.= '<td><a data-value="'.$row["id"].'" class="del_user" ><img src="delete.jpeg" height="20px" width="20px" alt="delete user" title="Delete User"></a></td></tr>';
		$count++;                  
	}
				
} 



  $output .="</tbody></table><div id='dialog-confirm' title='Delete Confirmation..!'>
  <p ><span class='ui-icon ui-icon-alert' style='float:left; margin:12px 12px 20px 0;'></span>Are You Sure To Delete User?</p>
</div></div></body>
  </html>";


echo $output;

?>