<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']==''||empty($_SESSION['username']))
{ 
header("location: login.php");
}
require_once "dbconnect.php";

$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
    
    <title>Comments Form</title>
    <style>
    .change-margin{
      margin: 100px auto auto auto; 
     }
     </style>
  </head>
  <body>";


 
  $output .= "<section>

  <div class='container'> 
  <div class='col-4 change-margin '>  
  <form action='' method='post' enctype='multipart/form-data'>";

  $output.= "<div class='form-group'>
     <label for='crm'> Client</label>
     <select name='crm' id='crm' class='custom-select'>";

if(isset($_GET['crmid'])){
  $crm = $_GET['crmid'];
  if(!empty($crm)&&is_numeric($crm))
     {

      $crm_qry = 'SELECT id , client from crm where id='.$crm.'';
        $crm_res = mysqli_query($con , $crm_qry) ;
     while ($crm_row = mysqli_fetch_assoc($crm_res)) {
     $output.= " <option  value='". $crm_row['id']."' selected disabled>". $crm_row["client"]."</option>";
     }
     }

} else{
  if($_SESSION['uid']==1)
   {  $crm_qry = 'SELECT id , client from crm ';}
 else{ $crm_qry = 'SELECT id , client from crm where usermodified="'.$_SESSION['uid'].'"';}
     $crm_res = mysqli_query($con , $crm_qry) ;
     while ($crm_row = mysqli_fetch_assoc($crm_res)) {
     $output.= " <option  value='". $crm_row['id']."'>". $crm_row["client"]."</option>";
     }

     }
 

     $output.="</select>
     </div>";

  $output .="<div class='form-group'>
    <label for='comment'>Comment</label>
    <textarea  name='comment' class='form-control' id='comment' placeholder='Add Comment' style='height: 150px'></textarea>
  </div>
   <div class='form-group'>
    <label for='file'>File input</label>
    <input type='file' class='form-control-file' name='file' id='file' aria-describedby='fileHelp'>
  </div>

<div class='button-align'>
<input type='submit' name='submit' class='btn btn-primary' value='Submit'>
  
<a href='index.php' class='text-white btn btn-primary' style='text-decoration:none'>Back</a>
  
</form>";
 
  extract($_POST);

if(isset($_FILES['file']))
  {
    $tfname=$_FILES['file']['tmp_name'];
    $ufname=$_FILES['file']['name'];
  if(is_uploaded_file($tfname))
  {  
  if(isset($submit))
  {
     if($_FILES['file']['size']<5242880)
     {
      $ranname = time();
      $ranname.=$ufname;
      $suc = move_uploaded_file($tfname, __DIR__.'/uploads/'.$ranname);
     }

    $timestamp = time();
    $uid = $_SESSION['uid'];
    // require_once "dbconnect.php";
    if(!empty($comment)){
    $comment_qry = 'INSERT into comments(crmid , comment , timecreated ,usermodified,file)
     values("'.$crm.'" , "'.$comment.'" , "'.$timestamp.'" , "'.$uid.'","'.$ranname.'")';
              
    if (mysqli_query($con, $comment_qry))
    {
      $_SESSION['status']='comment';
       header("Location: index.php");
    } 
    else
    {
        $output .="<br><span class='text-danger'>not inserted</span>";
    }
  }
  else
  {
    $output .="<br><span class='text-danger'>All Fields Are Required</span>";
  }
  
  }
}
}

$output .="</div>
</div>
</section></body>
</html> ";

echo $output;

?>