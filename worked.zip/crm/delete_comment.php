<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']==''||empty($_SESSION['username']))
{ 
header("location: login.php");
}
require_once "dbconnect.php";
if(isset($_GET['cid']))
{
  $cid = $_GET['cid'];
  $delete_comment_qry = 'DELETE FROM `comments` WHERE id="'.$cid.'"';
              
    if (mysqli_query($con, $delete_comment_qry))
    {
    	$_SESSION['status']='commentdeleted';
       header("Location: index.php");
    } 
}

?>