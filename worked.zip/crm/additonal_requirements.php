<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']==''||empty($_SESSION['username']))
{ 
header("location: login.php");
}
require_once "dbconnect.php";

$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
    
    <title>Comments Form</title>
    <style>
    .change-margin{
      margin: 100px auto auto auto; 
     }
     </style>
  </head>
  <body>";

if(isset($_GET['crmid'])){
  $crmid = $_GET['crmid'];
}

 
  $output .= "<section>

  <div class='container'> 
  <div class='col-4 change-margin '>  
  <form action='' method='post' >";

  $output.= "<div class='form-group'>
     <label for='crm'> Client</label>
     <select name='crm' id='crm' class='custom-select'>";
     $crm_qry = 'select id , client from crm where id='.$crmid.'';
     $crm_res = mysqli_query($con , $crm_qry) ;
     while ($crm_row = mysqli_fetch_assoc($crm_res)) {
     $output.= " <option  value='". $crm_row['id']."' selected >". $crm_row["client"]."</option>";
     }
     $output.="</select>
     </div>";

  $output .="<div class='form-group'>
    <label for='comment'>Comment</label>
    <textarea  name='comment' class='form-control' id='comment' placeholder='Add Comment' style='height: 150px'></textarea>
  </div>

<div class='button-align'>
<input type='submit' name='submit' class='btn btn-primary' value='Submit'>
  
<a href='index.php' class='btn btn-primary text-white' style='text-decoration:none'>Back</a>
  
</form>";
 
  extract($_POST);
  if(isset($submit))
  {
    $timestamp = time();
    $uid = $_SESSION['uid'];
    // require_once "dbconnect.php";

    $comment_qry = 'INSERT into comments(crmid , comment , timecreated ,usermodified )
     values("'.$crm.'" , "'.$comment.'" , "'.$timestamp.'" , "'.$uid.'")';
              
    if (mysqli_query($con, $comment_qry))
    {
       $output .="<br>inserted";
    } 
    else
    {
        $output .="<br>not inserted";
    }
  
  }

$output .="</div>
</div>
</section></body>
</html> ";

echo $output;

?>