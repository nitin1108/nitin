<?php
 require 'class.phpmailer.php';
  require 'class.smtp.php';

$y = date('Y-m-d',time());
 // echo $y;
$con = mysqli_connect("localhost","root","leooffice","my_crm");

$qry = 'SELECT * from notify_on where notifyon="'.$y.'"'; 

 $res = mysqli_query($con , $qry) ;

 while ($row = mysqli_fetch_assoc($res))
  {
 
  	$qry1 = "SELECT client ,requirement from crm where id='".$row['crmid']."'";
  	$res1 = mysqli_query($con , $qry1) ;
  	while ($row1 = mysqli_fetch_assoc($res1))
  	{
  		$client = $row1['client'];
  		$requirement = $row1['requirement'];
  	}
  	$qry2 = "SELECT comment from comments where crmid='".$row['crmid']."'";
  	$res2 = mysqli_query($con , $qry2) ;
  	while ($row2 = mysqli_fetch_assoc($res2))
  	{
  		$comment.= $row2['comment'].'<br>';
  		
  	}
    $notifyto = $row['notifyto'];
   // echo $notifyto;
    // die();
    custom_crm_mail($client,$comment,$requirement,$notifyto,$con); 
    $comment= ' ';
     }

   function custom_crm_mail($client,$comment,$requirement,$notifyto,$con)
   {
    $qry3 = "SELECT id,name ,email
 FROM users 
 WHERE id IN (".$notifyto.") ";
 
  $res3 = mysqli_query($con , $qry3) ;
   $mail = new PHPMailer;
  $mail->setFrom('nitin@eabyas.in','Admin');

    while ($row3 = mysqli_fetch_assoc($res3))
    {
      // echo $row3['email'].' ';
      // echo $row3['name'].'<br>';
      $mail->addAddress($row3['email'],$row3['name']);
    }
  
$mail->isHTML(true);

  $mail->Subject = 'This is remainder for client '.$client;

$body='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title></title>
        <style></style>
    </head>
    <body>
        <table border="0" cellpadding="0" cellspacing="0"   id="bodyTable">
            <tr>
                <td align="center" valign="top">
                    <table border="1" cellpadding="20" cellspacing="0"  id="emailContainer">
                    <caption>HI, This is remainder for Client <strong>'.$client.'</strong></caption>
                    <tr>
                            <th align="center" valign="top" >
                                Client.
                            </th>                            
                            <th align="center" valign="top" >
                               Requirement
                            </th>                            
                            <th align="center" valign="top" >
                                Comment
                            </th>
                            <th align="center" valign="top" >
                                Attachments
                            </th>
                        </tr>
                        <tr>
                            <td align="center" valign="top">
                                '.$Client.'
                            </td>                            
                            <td align="center" valign="top">
                                '.$requirement.'
                            </td>                        
                                <td align="center" valign="top">
                               '.$comment.'
                            </td>
                            <td align="center" valign="top">
                               Attachments
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </body>
</html>';
 $mail->Body = $body;

  $mail->IsSMTP();
  $mail->SMTPSecure = 'ssl';
  $mail->Host = 'ssl://smtp.zoho.com';
  $mail->SMTPAuth = true;
  $mail->Port = 465;

  // Set your existing gmail address as user name
  $mail->Username = 'nitin@eabyas.in';

  // Set the password of your gmail address here
  $mail->Password = 'Nitinm#0';

  $mail->send();
 
   }
   ?>

