<?php

session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']==''||empty($_SESSION['username']))
{ 
header("location: login.php");
}
require_once "dbconnect.php";
$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
    <link rel='stylesheet' href='select2.css'>
    <link rel='stylesheet' href='jqui.css'>
    <script src='jquery.js'></script>
    <script src='select2.js'></script>
    <script src='bootstrap.min.js'></script>
    <script src='jqui.js'></script>

    <style>
	     body
	     {
	      margin:50px;
	     }
	     .change-margin
	     {
	      margin: 100px auto auto auto; 
	     }
    </style>

    <title>Notify</title>

    <script>
	    $( function(){
	    $('#datepicker').datepicker({
	    dateFormat: 'yy-mm-dd'
	    });

        $('.example').select2();
        });
    </script>
	
	</head>
	<body>";
   
  $output.="<div class='container'><div class='col-md-4 col-sm-4 col-lg-4 change-margin  text-primary'>";
  $output.=" <h3 class='display-12 text-center' >Notify On</h3><hr>";

  $output .= "<form action='' method='post'>
			  <div class='form-group'>
		      <label for='crm'> Client</label>
		      <select name='crm' id='crm' class='custom-select'>";
    
  $crm_qry = 'SELECT id , client from crm ';
  $crm_res = mysqli_query($con , $crm_qry) ;

  while ($crm_row = mysqli_fetch_assoc($crm_res))
  {
    $output.= " <option  value='". $crm_row['id']."'>". $crm_row["client"]."</option>";
  }
  
  $output.="</select>
		    </div>
		    <div class='form-group'>
		    <label for='notify-on'>Notify ON</label>
		    <input type='text' id='datepicker' name='notify_on' class='form-control' size='30' 
		     placeholder='Select date' autocomplete='off'>
		    </div>
		    <div class='form-group'>
	        <label>Notify To</label>
	        <select class='form-control example' name='notify[]' multiple='multiple'>";
  
 $notify_user_qry = 'SELECT id,username from users';
 $notify_user_res =  mysqli_query($con ,  $notify_user_qry) ;

 while($notify_user_row = mysqli_fetch_assoc($notify_user_res))
 {
 	$output .= " <option value='".$notify_user_row['id']."'>
 	               ".$notify_user_row['username']."
 	             </option>";
 }
                  
 $output .= "</select>
			 </div>
			 <button type='submit'  name='login' class='btn btn-primary button-center '>Submit</button>
       <a href='index.php' class='text-white btn btn-primary' style='text-decoration:none'>Back</a>
			 </form>";
  

 extract($_POST);
 if(isset($login))
  {
  	 // $notify_on='2018-11-13';
   
    // $z=time();
    // echo '<br>'.$z.'<br>';
    // $n = date('Y-m-d',$z);

    // if($n==$notify_on)
    // {
    //   echo "equal";
    // }

   $no = implode(',',$notify);
   if(!empty($no)&&!empty($notify_on)&&!empty($crm))
   {

          $notify_inser_qry = 'INSERT into notify_on(crmid,notifyon,notifyto) 
                          values("'.$crm.'","'.$notify_on.'","'.$no.'")';
    if (mysqli_query($con, $notify_inser_qry))
    {
      $_SESSION['status'] = "notified";
       header("Location: index.php");
    } 

   }
    else
    {
      $output .="<span class='text-danger'>All Fields Are Required</span>";
    }
  

  }
 $output .="</div>
			</div>
			</body>
			</html>";
 echo $output;

?>
  