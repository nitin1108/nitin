<?php
session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']!=1)
{ 
header("location: index.php");
}

$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap.min.css'>
    
    <title>Add User</title>
    <style>
    .change-margin{
      margin: 100px auto auto auto; 
     }
     </style>
  </head>
  <body>";
    require_once "dbconnect.php";
 
  $output .= "<section>

  <div class='container'> 
  <div class='col-4 change-margin '>  
  <h3>Add User</h3><hr/>

<form action='' method='post' >
<div class='form-group'>
    <label for='name'>Name</label>
    <input type='text' name='name' class='form-control' id='name' placeholder='Enter Name'  >
  </div>

<div class='form-group'>
    <label for='username'>Username</label>
    <input type='text' name='username' class='form-control' id='username' placeholder='Enter User Name'  >
  </div>

  <div class='form-group'>
    <label for='empid'>Employee ID</label>
    <input type='number' name='empid' class='form-control' id='empid' placeholder='Enter Employee ID'  >
  </div>
  <div class='form-group'>
    <label for='email'>E-Mail</label>
    <input type='email' name='email' class='form-control' id='email' placeholder='Enter E-Mail'  >
  </div>

<div class='form-group'>
    <label for='password'>Password</label>
    <input type='password' name='password' class='form-control' id='client' placeholder='Enter Password '>
  </div>
  


<input type='submit' name='submit' class='btn btn-primary' value='Add User'>
  
<a href='index.php' class='text-white btn btn-primary' >Back</a>
  
</form>
";
 
  extract($_POST);
  if(isset($submit))
  {
    
    if(!empty($username)&&!empty($password)&&!empty($email)&&!empty($empid)&&!empty($name)){
        $chkuser = 'select username from users where username = "'.$username.'"';
        $isavail = mysqli_query($con,$chkuser);
        if(mysqli_num_rows($isavail) > 0){
          $output.="<br><span class='text-danger'>User Name Already Exists</span>";

        }
        else{

    $sql = 'INSERT into users(username ,password,email,empid,name)
               values("'.$username.'","'.$password.'","'.$email.'","'.$empid.'","'.$name.'")';
    if (mysqli_query($con, $sql))
    {
        $output .="<br><span class='text-success'>inserted</span>";
    } 
    else
    {
        $output .="<br><span class='text-danger'>not inserted</span>";
    }
    }

    }

    else{
      $output .="<br><span class='text-danger'>All Fields Are Required</span>";
    }
  
  }

$output .="</div>
</div>
</section></body>
</html> ";

echo $output;
