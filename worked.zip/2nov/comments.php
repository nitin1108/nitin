<?php

session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']==''||empty($_SESSION['username']))
{ 
header("location: login.php");
}

$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
    
    <title>Comments Form</title>
    <style>
    .change-margin{
      margin: 100px auto auto auto; 
     }
     </style>
  </head>
  <body>";

 
  $output .= "<section>

  <div class='container'> 
  <div class='col-4 change-margin '>  
  <form action='' method='post' >";

  $output.= "<div class='form-group'>
    <label for='crm'> CRM</label>
     <select name='crm' id='crm' class='custom-select'>";
     $res = mysqli_query($con , $user) ;
     while ($row = mysqli_fetch_assoc($res)) {
     $output.= " <option selected value='". $row['id']."'>". $row["clientname"]."</option>";
     }

     $clients = 'select id,clientname from client';
   $clients_res = mysqli_query($con , $clients) ;
 
   while ($row_clients_res = mysqli_fetch_assoc($clients_res)) {
    if(!empty($row_clients_res["clientname"])&&$row_clients_res["clientname"]!=NULL)
    {

     $output.= " <option value='". $row_clients_res['id']."'>". $row_clients_res["clientname"]."</option>";
     }
     }

     $output.="
     
     </select></div>";

  $output .="<div class='form-group'>
    <label for='comment'>Comment</label>
    <textarea  name='comment' class='form-control' id='comment' placeholder='Add Comment' style='height: 150px'></textarea>
  </div>

<div class='button-align'>
<input type='submit' name='submit' class='btn btn-primary' value='Submit'>
  
<button type='reset' class='btn btn-primary'><a href='' class='text-white' style='text-decoration:none'>Cancel</a></button>
  
</form>";
 
  extract($_POST);
  if(isset($submit))
  {
    $timestamp = time();
    $uid = $_SESSION['uid'];
    require_once "dbconnect.php";
    $sql = 'INSERT into crm(name , client , requirement , timecreated , usermodified)
               values("'.$name.'","'.$client.'","'.$requirement.'",'.$timestamp.','.$uid.')';
    if (mysqli_query($con, $sql))
    {
       $output .="<br>inserted";
    } 
    else
    {
        $output .="<br>not inserted";
    }
  
  }

$output .="</div>
</div>
</section></body>
</html> ";

echo $output;

?>