<?php
session_start();
if(!isset($_SESSION['uid'])||$_SESSION['uid']==''||empty($_SESSION['username']))
{ 
header("location: login.php");
}

$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
    
    <title>CRM Form</title>
    <style>
    .change-margin{
      margin: 100px auto auto auto; 
     }
     </style>
  </head>
  <body>";

 
  $output .= "<section>

  <div class='container'> 
  <div class='col-4 change-margin '>  

<form action='' method='post' >

<div class='form-group'>
    <label for='name'>Name</label>
    <input type='text' name='name' class='form-control' id='name' placeholder='Enter Name'>
  </div>

<div class='form-group'>
    <label for='client'>Client</label>
    <input type='text' name='client' class='form-control' id='client' placeholder='Enter Client '>
  </div>
  
<div class='form-group'>
    <label for='requirement'>Requirement</label>
    <textarea  name='requirement' class='form-control' id='requirement' placeholder='Requirement' style='height: 150px'></textarea>
  </div>

<div class='button-align'>
<input type='submit' name='submit' class='btn btn-primary' value='Submit'>
  
<button type='reset' class='btn btn-primary'><a href='' class='text-white' style='text-decoration:none'>Cancel</a></button>
  
</form>
";
 
  extract($_POST);
  if(isset($submit))
  {
    $timestamp = time();
    $uid = $_SESSION['uid'];
    require_once "dbconnect.php";
    $sql = 'INSERT into crm(name , client , requirement , timecreated , usermodified)
               values("'.$name.'","'.$client.'","'.$requirement.'",'.$timestamp.','.$uid.')';
    if (mysqli_query($con, $sql))
    {
       $output .="<br>inserted";
    } 
    else
    {
        $output .="<br>not inserted";
    }
  
  }

$output .="</div>
</div>
</section></body>
</html> ";

echo $output;





    

  



















