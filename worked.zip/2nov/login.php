<?php
$output = '';
$output .= "<!doctype html>
<html lang='en'>
  <head>

    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

   
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
    <style>body{margin:50px;}
    .change-margin{
      margin: 150px auto auto auto; 
     }
    </style>

    <title>Login </title>
  </head>
  <body>";
  $output.="<div class='container'><div class='col-md-4 col-sm-4 col-lg-4 change-margin  text-primary'>";
  $output.=" <h3 class='display-12 text-center' >Login</h3><hr>
  ";
  $output .= "<form action='' method='post'>
  <div class='form-group'>
    <label for='username'>Username</label>
    <input type='text' name='username' class='form-control' id='username' placeholder='Enter Username'>
  </div>
  <div class='form-group'>
    <label for='password'>Password</label>
    <input type='password' name='password' class='form-control' id='password' placeholder='Password'>
  </div>
  <button type='submit' name='login' class='btn btn-primary button-center'>Login</button>
  
</form>";
    
  
  extract($_POST);
  if(isset($login))
  {
  require_once "dbconnect.php";
  $log_qry = 'SELECT id , username , password from users where username = "'.$username.'" and password = "'.$password.'"';
  $log_res = mysqli_query($con , $log_qry);
  $count = mysqli_num_rows($log_res);
  if($count==1)
  {
   while ($log_row = mysqli_fetch_assoc($log_res))
   {
    session_start();
    $_SESSION['uid'] = $log_row['id'];
     $_SESSION['username'] = $log_row['username'];
      header("location: index.php");
   }
  }
 }
$output .="</div></div>
  </body>
</html>";
   echo $output;
?>
  





    

  



















