<?php

//define('NO_MOODLE_COOKIES', true);
define('AJAX_SCRIPT', true);
global $DB,$CFG,$PAGE,$OUTPUT;
require_once(dirname(__FILE__) . '/../../config.php');
$PAGE->requires->jquery();
// $returnurl = new moodle_url('/local/examination/index.php');
$deleteid = optional_param('delete', 0, PARAM_INT);
$editid = optional_param('edit', 0, PARAM_INT);

if($deleteid) {
	$var = $DB->delete_records('local_subjectwise_marks', array('id'=>$deleteid));
	if($var)
		echo json_encode('deleted');
}
if($editid) {	
	if($data = data_submitted()){
		$toupdate = new stdClass();
		$toupdate->id = $editid;
		$toupdate->examtype = $data->examtype;
		$toupdate->totalmaxmarks_subject = $data->totalmaxmarks_subject;
		$toupdate->totalminmarks_subject = $data->totalminmarks_subject;
		$maxmarksseg = array(); 
		foreach ($data->marks as $key => $value) {
			$maxmarksseg[] = $key.':'.$value;
		}
		$toupdate->maxmarks_segregated =  json_encode($maxmarksseg);
		
		$update = $DB->update_record('local_subjectwise_marks',$toupdate);
		if($update){
			echo json_encode('edited');
		}
	}
}
