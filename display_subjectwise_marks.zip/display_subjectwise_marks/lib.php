<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version details
 *
 * @package    Examination
 * @copyright  2015 rajesh@eayas.in
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
 require_once($CFG->dirroot . '/user/selector/lib.php');

class local_examination {
	/**
	* @method all_programs.
	* @param   $limit limiting the results of all_programs.
	* @return programid.
	* */
	function get_all_programs(){
	  global $DB, $CFG;
	   $program = array();
		$program[null] = '-- Select --';
		  $college_programs = $DB->get_records_sql("SELECT * FROM {local_program}");
		  foreach($college_programs as $college_program){
			$program[$college_program->id] =  $college_program->fullname;
		  }
		return $program;
	}
	function offering_period($programid){
	   global $DB, $CFG;
	   $offeringperiod = array();
	   $today=date('y-m-d');
	   $sql = "SELECT sem.id,sem.fullname AS semester
                FROM {local_activeplan_batch} AS map
                JOIN {local_semester} AS sem ON sem.id = map.semesterid
                WHERE map.programid = $programid AND '$today' BETWEEN DATE(FROM_UNIXTIME(sem.startdate)) AND DATE(FROM_UNIXTIME(sem.enddate))";
	   $semesters = $DB->get_records_sql($sql);
	   $offeringperiod[null] = '-- Select --';
	    foreach($semesters as $semester){
			$offeringperiod[$semester->id] =  $semester->semester;
		  }
		return $offeringperiod;
	}
	public function get_activeplan_batches($semesterid){
        global $DB;
		$batch = array();
        $today=date('y-m-d');
        $sql = "SELECT c.id, c.name, c.idnumber
                FROM {local_activeplan_batch} AS map
                JOIN {local_semester} AS sem ON sem.id = map.semesterid
                JOIN {cohort} AS c ON c.id = map.batchid
                WHERE sem.id = $semesterid AND '$today' BETWEEN DATE(FROM_UNIXTIME(sem.startdate)) AND DATE(FROM_UNIXTIME(sem.enddate))";
        $batchlists=$DB->get_records_sql($sql);
						$batch[null] = '--Select--';		
	    foreach($batchlists as $batchlist){
					$batch[$batchlist->id] =  $batchlist->name;
					}
        return $batch;
    }
	//for getting active semister based on multiple batches
	function get_program_curriculum($programid) {
	  global $DB;
		$sql = "SELECT * FROM {local_curriculum_plan} WHERE programid = {$programid}";
		$out[NULL] = "---Select---";
		$plans = $DB->get_records_sql($sql);
		foreach ($plans as $plan) {
			  $out[$plan->id] = $plan->fullname;
		}
		return $out;
    }
	
	//	function get_program_curriculum($examid) {
//	  global $DB;	
//	  $today=date('Y-m-d');
//	  $out = array();
//	  $sql ="SELECT lcp.id,lcp.fullname
//	  FROM {local_examcreation} AS le
//	  JOIN {local_activeplan_batch} AS map ON map.programid = le.programid AND map.batchid = le.batchid AND map.semesterid = le.semesterid
//	  JOIN {local_semester} AS sem ON sem.id = map.semesterid
//	  JOIN {local_curriculum_plan} AS lcp ON lcp.id = map.planid
//	  JOIN {local_curriculum} AS lc ON lc.id = lcp.curriculumid
//	  JOIN {cohort} AS c ON c.id = map.batchid
//	  JOIN {local_program} AS lp ON lp.id = map.programid
//	  WHERE  '$today' BETWEEN DATE(FROM_UNIXTIME(sem.startdate)) AND DATE(FROM_UNIXTIME(sem.enddate)) AND le.id = $examid";
//	   $out[NULL] = "---Select---";
//	   $plans = $DB->get_records_sql($sql);
//		foreach ($plans as $plan) {
//			  $out[$plan->id] = $plan->fullname;
//		}
//		return $out;
//    }
		function cobalt_courses($examid){
        global $DB, $CFG;
		if($examid){
			$exam = $DB->get_record('local_examcreation',array('id'=>$examid));
			$schedule_exam = $DB->get_record('local_examination_schedule',array('examid'=>$examid));
			if($exam->planid){
			$sql1 = "SELECT c.id,c.fullname
						 FROM {local_curriculum_plancourses} AS lcp
						 JOIN {local_cobaltcourses} AS c ON c.id = lcp.courseid
						 WHERE lcp.planid = $exam->planid";
			}else{
			  $sql1 = "SELECT c.id,c.fullname
						 FROM {local_curriculum_plancourses} AS lcp
						 JOIN {local_cobaltcourses} AS c ON c.id = lcp.courseid
						 WHERE lcp.planid = $schedule_exam->planid";
			}
						 //if(!empty($sud))
						 //$sql .= " AND c.id NOT IN ($sud)";
						 //else
						 //$sql .= " ";
				  $sql2 = "SELECT lc.id,lc.fullname
						 FROM {local_cobaltcourses} AS lc 
						 JOIN {local_department} AS ld ON ld.id = lc.departmentid
						 WHERE ld.fullname = 'examinationcourse'";
				 $rocrd1 =$DB->get_records_sql($sql1);
				 
				 $record2 = $DB->get_records_sql($sql2);
				 $subjects = array(0=>'---Select---');
				 $records =array_merge($record2, $rocrd1);
			   
			 foreach($records as $record){
				   $subjects[$record->id] = $record->fullname;
			   }
			   return $subjects;
		}
    }
	
//	function mapping_courses($planid,$examid){
//        global $DB, $CFG;
//		 $sql = "SELECT *
//				FROM {local_examination_schedule}
//				WHERE planid = $planid AND examid = $examid";     
//        $subjects = $DB->get_records_sql($sql);
//		$subject_list = array();
//		foreach($subjects as $subject){
//			$subject_list[] = $subject->cobaltcourseid;
//		}
//		$sud =implode(',',$subject_list);
//        $sql = "SELECT c.id,c.fullname
//				FROM {local_curriculum_plancourses} AS lcp
//				JOIN {local_cobaltcourses} AS c ON c.id = lcp.courseid
//				WHERE lcp.planid = $planid";
//        $records = $DB->get_records_sql($sql);
//        $subjects = array();	
//      foreach($records as $record){
//			$subjects[$record->id] = $record->fullname;
//        }
//        return $subjects;
//    }
	function mapping_courses($planid,$examid){
        global $DB, $CFG;
		 $sql = "SELECT *
				FROM {local_examination_schedule}
				WHERE examid = $examid";     
        $subjects = $DB->get_records_sql($sql);
		$subject_list = array();
		foreach($subjects as $subject){
			$subject_list[] = $subject->cobaltcourseid;
		}
		$sud =implode(',',$subject_list);
        $sql = "SELECT c.id,c.fullname
				FROM {local_curriculum_plancourses} AS lcp
				JOIN {local_cobaltcourses} AS c ON c.id = lcp.courseid
				WHERE lcp.planid = $planid";
        $records = $DB->get_records_sql($sql);
        $subjects = array();	
      foreach($records as $record){
			$subjects[$record->id] = $record->fullname;
        }
        return $subjects;
    }
	public function get_plan_batches($planid, $programid){
        global $DB;       
        //$today=date('y-m-d');
        //$sql = "SELECT c.id, c.name, c.idnumber
        //        FROM mdl_local_activeplan_batch AS map
        //        JOIN mdl_local_semester AS sem ON sem.id = map.semesterid
        //        JOIN mdl_cohort AS c ON c.id = map.batchid
        //        WHERE programid = $programid AND planid = $planid ";
        //$params= array('programid'=>$programid,'planid'=>$planid);
        $batchlist=$DB->get_records_sql($sql);
        return $batchlist;
    }
			/*
			*@method get_attachedfiles_todownlload
			*@param Int $userid studentid.
			*@param Int $id itemid.
			*return $url[0] is user img path .
			**/
	public function get_attachedfiles_todownlload($userid,$id){     
        global $CFG,$DB;
		
        $usercontext = context_user::instance($userid);
		$file =$DB->get_record_sql("SELECT * FROM {files} WHERE itemid = $id");
		$context = context_user::instance($userid);
		$fs = get_file_storage();
		//		$file = $fs->get_file($fileinfo['contextid'], 'local', '', 
		//        $fileinfo['itemid'], $fileinfo['filepath'], $fileinfo['filename']);
		//		// Delete it if it exists
		//		if ($file) {
		//			$file->delete();
		//		}
		$files = $fs->get_area_files($context->id, 'local', 'user', $file->itemid, 'filename', false);
		$url = array();
		foreach ($files as $file) {
            $isimage = $file->is_valid_image();
            $url[] = file_encode_url("$CFG->wwwroot/pluginfile.php", '/' . $file->get_contextid() . '/' . 'local' . '/' .
                   'user' .'/'.$file->get_itemid(). $file->get_filepath() . $file->get_filename(), !$isimage);
		}
		$photo = "<img src=$url[0] width='60' height='60'>	";

        return $url[0];
    }
		/*
			*@method get_studentreceipt_file
			*@param Int $userid studentid.
			*@param Int $id itemid.
			*return $url[0] is receipt img path .
			**/
	public function get_studentreceipt_file($userid,$id){     
        global $CFG,$DB;
		
        $usercontext = context_user::instance($userid);
		$file =$DB->get_record_sql("SELECT * FROM {files} WHERE itemid = $id");
		$context = context_user::instance($userid);
		$fs = get_file_storage();
		//		$file = $fs->get_file($fileinfo['contextid'], 'local', '', 
		//        $fileinfo['itemid'], $fileinfo['filepath'], $fileinfo['filename']);
		 
		//		// Delete it if it exists
		//		if ($file) {
		//			$file->delete();
		//		}
		$files = $fs->get_area_files($context->id, 'local', 'examfee', $file->itemid, 'filename', false);
		$url = array();
		foreach ($files as $file) {
            $isimage = $file->is_valid_image();
            $url[] = file_encode_url("$CFG->wwwroot/pluginfile.php", '/' . $file->get_contextid() . '/' . 'local' . '/' .
                   'examfee' .'/'.$file->get_itemid(). $file->get_filepath() . $file->get_filename(), !$isimage);
		}
		$photo = "<img src=$url[0] width='60' height='60'>	";

        return $url[0];
    }
	
	function student_class_attendance($classid,$userid){
		global $DB,$USER;
		$atten_id  = $DB->get_field('local_attendance', 'id', array('classid' => $classid));
		$atten_session = $DB->get_records('local_attendance_sessions', array('attendanceid' => $atten_id));
		$total_classes = $DB->count_records_sql("select count(distinct ss.id)
												   from {local_attendance_sessions} as ss                                                    
												   join {local_attendance_log} as lg on lg.sessionid=ss.id
												  where ss.attendanceid=:attendanceid", array('attendanceid' => $atten_id));
		$intial_present = 0;
		foreach ($atten_session as $sessionid) {
			//-----------number of presentees----------------
			$presentid  = $DB->get_field('local_attendance_statuses', 'id', array('attendanceid' => $atten_id,'acronym' => 'P'));
			$presentees = $DB->get_records_sql("SELECT id FROM {local_attendance_log} WHERE sessionid = $sessionid->id AND studentid = $userid AND statusid = $presentid");

			if ($presentees) {
				$intial_present++;
			}
		}
		$total = 0;
		
		if ($total_classes > 0) {
			
			$intial_present;
			$total_classes;
			$total = ($intial_present / $total_classes) * 100;
			$total = round($total, 2);
			$finaltotal = $total . ' %';
		}
		return $finaltotal;
	}
	function students_verification(){
		global $DB,$USER;
			$user = $DB->get_record_sql("SELECT u.*,ud.serviceid,lus.fathername,lus.mothername,ud.programid,ud.batchid,ud.schoolid
											  FROM {user} AS u
											  JOIN {local_userdata} AS ud ON u.id =ud.userid
											  JOIN {local_users} AS lus ON u.id =lus.userid
											  WHERE u.id = $USER->id");
			
			$sql = "SELECT * FROM {local_examination_schedule} ";
			$examination_schedule_records = $DB->get_records_sql($sql,array());
			//$data=array();
			//foreach($examination_schedule_records as $examination_schedule_record){
			//	$list=array();
			//	$list[] = $examination_schedule_record->name;
			//	$noofstudents = $DB->get_records_sql("SELECT studentid FROM {local_examination_apply} WHERE examid =$examination_schedule_record->id");
			//	$list[] =count($noofstudents);
			//	$programname = $DB->get_field('local_program','fullname',array('id'=>$examination_schedule_record->programid));
			//	$list[] =$programname;
			//	$planname = $DB->get_field('local_curriculum_plan','fullname',array('id'=>$examination_schedule_record->planid));
			//	$list[] =$planname;
			//	$data[] =$list;
			//}
			$exam_name = get_string('exam_name', 'local_examination');
            $noofstudents = get_string('noofstudents', 'local_examination');
            $semester = get_string('semester', 'local_examination');
            $program_name = get_string('program_name', 'local_examination');
			
            $table = new html_table();
			$table->id ='student_exam_verification';
            $table->head = array('',$exam_name,$noofstudents,$program_name,$semester);
            //$table->align = array('left', 'left', 'center', 'center');
            //$table->data = $data;
            $output = html_writer::table($table);
			
		return $output;
	}
	function examination_insert($mform,$data){
					global $DB,$USER,$CFG;
					require_once($CFG->libdir . '/gdlib.php');
					require_once($CFG->dirroot . '/local/timetable/stulib.php');
					$enrollclasses = local_timetable_activesemester_student_detail();
					$student_appliedexam = $DB->get_record('local_examination_apply',array('studentid'=>$USER->id,'batchid'=>$data->batchid,'examid'=>$data->examid));
					if(!empty($student_appliedexam)){
						$applied_exam = New stdClass();
						$applied_exam->id = $student_appliedexam->id ;
						//$filename = $mform->get_new_filename('hallticketphoto');
						if(!empty($data->hallticketphoto)){
							$applied_exam->picture = $data->hallticketphoto;
							$newcontextid = context_user::instance($USER->id, MUST_EXIST);
							//$storedfile = $mform->save_stored_file('hallticketphoto', $newcontextid->id, 'local', 'user', $applied_exam->picture, $newfilepath='/',
							//					$newfilename=null, $overwrite=false, $newuserid=null);
								 file_save_draft_area_files($data->hallticketphoto, $newcontextid->id, 'local', 'user',
                   $data->hallticketphoto, array('maxfiles' => 1));
							$localusers = $DB->get_record('local_users',array('userid'=>$USER->id));
							$hallticketphoto = New stdClass();
							$hallticketphoto->id = $localusers->id;
							$hallticketphoto->hallticketitemid = $data->hallticketphoto;
							$hallticketphoto->hallticketifilename = $filename;
							$localuserid = $DB->update_record('local_users',$hallticketphoto);
						}  else{
								$localusers = $DB->get_record('local_users',array('userid'=>$USER->id));
								$data->picture = $localusers->hallticketitemid;
						}
						$applied_exam->status = $data->status ;
						$exam_record = $DB->get_record('local_examcreation',array('id'=>$data->examid));
						$exam_students =$DB->get_record_sql(" SELECT * FROM {local_examination_students} WHERE examid=$data->examid AND FIND_IN_SET($USER->id,studentid)");
						if(!empty($exam_students->hallticketpattern)){
								$applied_exam->hallticketnumber = $this->generate_hallticketnumber($exam_students->hallticketpattern,$data->examid,$exam_students->hallticketstartingno,$exam_students->batchid);
						} else if(!empty($exam_record->hallticketpattern)){
								$applied_exam->hallticketnumber = $this->generate_hallticketnumber($exam_record->hallticketpattern,$data->examid,$exam_record->hallticketstartingno);
						}
						$applied_exam->timecreated = time();
						$DB->update_record('local_examination_apply',$applied_exam);
						$examinationid =$applied_exam->id;
					} else{
						$classids = array();
						$filter_subjects = array_filter($data->subjectid);
						$subjects = implode(',',$filter_subjects);
			
						$scheduledcourses =$DB->get_records_sql("SELECT * FROM  {local_examination_schedule} 
																		WHERE FIND_IN_SET(cobaltcourseid, '$subjects') AND examid =$data->examid ");
						$attendance_subjects = array();
						foreach($scheduledcourses as $scheduledcourse){
							if(empty($scheduledcourse->mappingcourseid)){
								$attendance_subjects[] = $scheduledcourse->cobaltcourseid; 
							} else{
								$attendance_subjects[] = $scheduledcourse->mappingcourseid; 
							}
						}
						$classids =$this->student_classes(implode(',',$attendance_subjects),$USER->id);
						$classes = implode(',',$classids);
						$data->studentid = $USER->id;
						$data->serviceid = $data->rollno;
						$data->subjectid =$subjects;
						$data->classid =$classes;
						$exam_record = $DB->get_record('local_examcreation',array('id'=>$data->examid));
						$exam_students =$DB->get_record_sql(" SELECT * FROM {local_examination_students} WHERE examid=$data->examid AND FIND_IN_SET($USER->id,studentid)");
						if(!empty($exam_students->hallticketpattern)){
								$data->hallticketnumber = $this->generate_hallticketnumber($exam_students->hallticketpattern,$data->examid,$exam_students->hallticketstartingno,$exam_students->batchid);
						} else if(!empty($exam_record->hallticketpattern)){
								$data->hallticketnumber = $this->generate_hallticketnumber($exam_record->hallticketpattern,$data->examid,$exam_record->hallticketstartingno);
						} else{
								$data->hallticketnumber = "0";
						}
					
						//$filename = $mform->get_new_filename('hallticketphoto');
						if(!empty($data->hallticketphoto)){
							$data->picture = $data->hallticketphoto;
							$newcontextid = context_user::instance($USER->id, MUST_EXIST);
							//$storedfile = $mform->save_stored_file('hallticketphoto', $newcontextid->id, 'local', 'user', $data->picture, $newfilepath='/',
							//					$newfilename=null, $overwrite=false, $newuserid=null);
							file_save_draft_area_files($data->hallticketphoto, $newcontextid->id, 'local', 'user',
																	$data->hallticketphoto, array('maxfiles' => 1));
							$localusers = $DB->get_record('local_users',array('userid'=>$USER->id));
							$hallticketphoto = New stdClass();
							$hallticketphoto->id = $localusers->id;
							$hallticketphoto->hallticketitemid = $data->hallticketphoto;
							$hallticketphoto->hallticketifilename = $filename;
							$localuserid = $DB->update_record('local_users',$hallticketphoto);
						} else{
								$localusers = $DB->get_record('local_users',array('userid'=>$USER->id));
								$data->picture = $localusers->hallticketitemid;
						}
						$examfee =$this->feeschedule_details($data->programid,$data->batchid,$USER->id,$data->examid);
						if(!empty($examfee->amount) && empty($examfee->unitprice))
									$data->fee = $examfee->amount;
						else
									$data->fee = ($examfee->amount) * count($filter_subjects);
						$data->coordinatorid = 0;
						$data->createdby = 'student';
						$data->timecreated = time();
						$data->timemodified = time();
						$data->usermodified = $USER->id;
						$examinationid =$DB->insert_record('local_examination_apply',$data);
					}
					return $examinationid;
	}
	
	function hallticket_download($examid,$batchid){
		global $DB,$CFG, $USER,$OUTPUT;
		$sql = "SELECT * FROM {local_examination_apply} WHERE examid = $examid AND batchid = $batchid AND coordinatorstatus =1";
		$halltickets = $DB->get_records_sql($sql,array());
		if(!empty($halltickets)){
			$data = array();
			foreach($halltickets as $hallticket){
				$list = array();
				$list[]= $DB->get_field('local_examcreation','name',array('id'=>$hallticket->examid));
				$list[]= $DB->get_field('cohort','name',array('id'=>$hallticket->batchid));
				$user = $DB->get_record('user',array('id'=>$hallticket->studentid));
				$list[] = $user->firstname.' ' .$user->lastname;
				$list[] = $user->email;
				$list[] = $hallticket->fee;
				$list[] = $hallticket->hallticketnumber;
				if(!empty($hallticket->previousexam))
					$list[] = $hallticket->previousexam;
				else
					$list[] ='--';
				
				if(!empty($hallticket->comment))
					$list[] = $hallticket->comment;
				else
					$list[] ='--';
					
				$localusers = $DB->get_record('local_users',array('userid'=>$hallticket->studentid));
				if(!empty($localusers->hallticketitemid)){
					$temp_file_url =$this->get_attachedfiles_todownlload($hallticket->studentid,$localusers->hallticketitemid);
					$pic = '<img src="'.$temp_file_url.'" width="100" height="120"/>';
				} else if(!empty($hallticket->picture)){
     $temp_file_url =$this->get_attachedfiles_todownlload($hallticket->studentid,$hallticket->picture);
					$pic = '<img src="'.$temp_file_url.'" width="100" height="120"/>';
    } else{
					$userrecord = $DB->get_record('user',array('id'=>$hallticket->studentid));
					$pic = $OUTPUT->user_picture($userrecord, array('courseid' => SITEID, 'size' => 64));
				}
    $uploadphoto = "<div class = 'student_photo_".$hallticket->examid."_$hallticket->studentid' style = 'display:none'>$pic</div>";
				$list[] ="<span class='hallticketphoto' onClick = 'StudentPhoto($hallticket->examid,$hallticket->studentid)'>Student Photo</span>".$uploadphoto;
				
				$url = new moodle_url('/local/examination/hallticketphoto.php', array('studentid'=>$hallticket->studentid));
				$list[] = html_writer::tag('a', get_string('edithallticketphoto', 'local_examination'), array('href' => $url));
		
				$url = new moodle_url('/local/examination/hallticket_pdf.php', array('studentid'=>$hallticket->studentid,'examid'=>$hallticket->examid));
				$list[] = html_writer::tag('a', get_string('download', 'local_examination'), array('href' => $url));
		
				$data[] = $list;
			}
		
			$batchname = get_string('batchname', 'local_examination');
			$examname = get_string('examname', 'local_examination');
			$student = get_string('student', 'local_examination');
			$email = get_string('email', 'local_examination');
			$fee = get_string('fee', 'local_examination');
			$hallticketnumber = get_string('hallticketnumber', 'local_examination');
			$previousexam = get_string('previousexam', 'local_examination');
			$comment = get_string('comment', 'local_examination');
			$download = get_string('download', 'local_examination');
			$hallticketphoto = get_string('hallticketphoto', 'local_examination');
            $edithallticketphoto = get_string('action', 'local_examination');
			
			$table = new html_table();
			$table->head = array($examname,$batchname,$student,$email,$fee,$hallticketnumber,$previousexam,$comment,$hallticketphoto,$edithallticketphoto,$download);
			$table->align = array('left', 'left', 'left', 'left','center', 'left', 'left', 'left');
			$table->data = $data;
			$table->id = "hallticket_download";
			$output = html_writer::table($table);
		} else{
			$output =  html_writer::tag('h4', get_string('nohalltickets', 'local_examination'), array());;
		}
		return $output;
	}
	
	function student_enrollclasses($examid,$userid =false){
		global $DB,$CFG, $USER;
		require_once($CFG->dirroot . '/local/timetable/stulib.php');
		$enrollclasses = local_timetable_activesemester_student_detail($userid);
		$schedule_subject=array();
		foreach($enrollclasses->classes as $class){
			$enrol_class = $DB->get_record_sql("SELECT * FROM {local_clclasses} WHERE id = $class");
			$enrol_subjects = $DB->get_records_sql("SELECT es.id,cc.id AS subjectid, cc.fullname,es.examinationdate,cs.classtype FROM {local_cobaltcourses} AS cc
												    JOIN {local_examination_schedule} AS es ON cc.id = es.cobaltcourseid
													JOIN {local_lecturetype} AS cs ON cs.id =es.exammodeid
												    WHERE cc.id = $enrol_class->cobaltcourseid AND es.examid =$examid AND es.publish = 1");
					
			if(!empty($enrol_subjects)){
				foreach($enrol_subjects as $enrol_subject){
					$row = New stdClass();
					$row->classid = $enrol_class->id;
					$row->subjectid = $enrol_subject->subjectid;
					$row->subjectname = $enrol_subject->fullname;
					$row->examinationdate = $enrol_subject->examinationdate;
					$row->classtype = $enrol_subject->classtype;
					$schedule_subject[] =$row;
				}
			}
		}
		return $schedule_subject;
	}
	
	function student_applied_exams($examid){
		global $DB,$CFG, $USER;
		require_once($CFG->dirroot . '/local/timetable/stulib.php');
		$enrollclasses = local_timetable_activesemester_student_detail();
		$exams = $DB->get_records_sql("SELECT * FROM {local_examination_apply} WHERE studentid =$USER->id  AND programid =$enrollclasses->programid AND batchid =$enrollclasses->batchid AND examid = $examid AND status=1 ");
		$appliedexams = array();
		foreach($exams as $exam){
			$appliedexams[$exam->examid] =$exam->examid;
		}
		$examids = implode(',',$appliedexams);
		return $examids;
	}
	function student_exams(){
		global $DB,$CFG, $USER;
		require_once($CFG->dirroot . '/local/timetable/stulib.php');
		$applied_exams = $this-> student_applied_exams();
		$enrol_classes = local_timetable_activesemester_student_detail();
		if(!empty($applied_exams))
			$schedule_exams = $DB->get_records_sql("SELECT * FROM {local_examcreation} WHERE
													FIND_IN_SET($enrol_classes->batchid,batchid)  AND programid =$enrol_classes->programid AND visible = 1 AND id NOT IN ($applied_exams)");
		else
			$schedule_exams = $DB->get_records_sql("SELECT * FROM {local_examcreation} WHERE
													FIND_IN_SET($enrol_classes->batchid,batchid)  AND programid =$enrol_classes->programid AND visible = 1 ");
		$exams = array();
		$exams[null] ='--select--';
		foreach($schedule_exams as $schedule_exam){
			$exams[$schedule_exam->id] =$schedule_exam->name;
		}
		return $exams;
	}
	
	//By vinod
	function get_exams(){
		global $DB;
		$examlist = array('Select');
		$examlist = $examlist + $DB->get_records_select_menu('local_examcreation', '1=1 ORDER BY timecreated DESC', array(), '', 'id, name');
		return $examlist;
	}
	
	function exam_batches($examid, $planid, $addselect = false){
		global $DB;
		$batchexam = $DB->get_record('local_examcreation', array('id'=>$examid), '*', MUST_EXIST);
		$batches = array();
		
		if($batchexam->batchid == 0){
			return $batches;
		}
		
		$found = strpos($batchexam->batchid, ',');
		if($found == true){
			$batchids = explode(',', $batchexam->batchid);
			foreach($batchids as $batchid){
				$batch = $DB->get_record('cohort', array('id'=>$batchid), '*', MUST_EXIST);
				$batches[$batch->id] = format_string($batch->name);
			}
		} else {
			$batch = $DB->get_record('cohort', array('id'=>$batchexam->batchid), '*', MUST_EXIST);
			$batches[$batch->id] = format_string($batch->name);
		}
		//$activebatches = $DB->get_records_select_menu('local_activeplan_batch', 'planid = ? AND semesterid = ?', array($planid, $batchexam->semesterid), '', 'id, batchid');
		//
		//foreach($batches as $k=>$v){
		//	if(!in_array($k, $activebatches)){
		//		unset($batches[$k]);
		//	}
		//}
		if($addselect){
			$batches = array('Select') + $batches;
		}
		return $batches;
	}
	
	function exam_plans($examid){
		global $DB;
		$schedules = $DB->get_records_select('local_examination_schedule', 'examid = ? GROUP BY planid', array('examid'=>$examid));
		//if(sizeof($schedules) > 1){
		$plans = array('Select');
		foreach($schedules as $schedule){
			$plans[$schedule->planid] = $DB->get_field('local_curriculum_plan', 'fullname', array('id'=>$schedule->planid));
		}
		return $plans;
		//}
		//foreach($schedules as $schedule){
		//	return $schedule->planid;
		//}
		//die(); //Normally we don't come here ;)
	}
	
	function exam_subjects($examid, $planid){ //sreenew
		global $DB, $CFG;
		$schedules = $DB->get_records_select('local_examination_schedule', 'examid = ? GROUP BY cobaltcourseid', array('examid'=>$examid));
		$subjects = array();
		foreach($schedules as $schedule){
			$subjects[$schedule->cobaltcourseid] = $DB->get_field('local_cobaltcourses', 'fullname', array('id'=>$schedule->cobaltcourseid));
		}
		return $subjects;
	}
	
	function get_examtypes(){
		global $DB;
		$examtypes = array('Select');
		$examtypes = $examtypes + $DB->get_records_select_menu('local_lecturetype', '', array(),'', 'id, lecturetype');
		return $examtypes;
	}
	
	function get_markstypes(){
		global $DB;
		$markstypes = array('Select');
		$markstypes = $markstypes + $DB->get_records_select_menu('local_exammarks_types', '', array(), '', 'id, markstype');
		return $markstypes;
	}
	
	function exam_marks($examid, $planid = 0){
		global $DB;
		
		$params = array('examid'=>$examid);
		if($planid > 0){
			$params['planid'] = $planid;
		}
		
		// Marks settings already created
		$examsmarks = $DB->get_records('local_exam_maxmarks', $params);
		
		//Exam types
		$examtypes = $DB->get_records_select_menu('local_lecturetype', '', array(), '', 'id, lecturetype');

		$examtype1 = ''; $examtype2 = '';
		$markstype1 = array(); $marks1 = array();
		$markstype2 = array(); $marks2 = array();

		foreach($examtypes as $k=>$examtype){
			foreach($examsmarks as $exammark){
				if($examtype == 'Theory' && $k==$exammark->examtypeid){
					$examtype1 = $k;
					$markstype1[] = $exammark->markstypeid;
					$marks1[] = $exammark->maxmarks;
				} else if(($examtype == 'Practical' || $examtype == 'Lab') && $k==$exammark->examtypeid){
					$examtype2 = $k;
					$markstype2[] = $exammark->markstypeid;
					$marks2[] = $exammark->maxmarks;
				}
			}
		}
		return array('examtype_1' => $examtype1, 'examtype_2' => $examtype2,
					 'markstype_1' => $markstype1, 'markstype_2' => $markstype2,
					 'marks_1' => $marks1, 'marks_2' => $marks2);
	}
	
	function marksupload_tabs($currenttab){
		global $OUTPUT;
		
		$tabs[] = new tabobject('markssettings', new moodle_url('/local/examination/markssettings.php'), get_string('markssettings', 'local_examination'));
		$tabs[] = new tabobject('samplesheet', new moodle_url('/local/examination/marksupload_sample.php'), get_string('samplesheet', 'local_examination'));
		$tabs[] = new tabobject('marksupload', new moodle_url('/local/examination/marksupload.php'), get_string('bulkuploadofmarks', 'local_examination'));
		$tabs[] = new tabobject('subjectmarks_manual', new moodle_url('/local/examination/marksupload_manual.php'), get_string('uploadsubjectmarks_manual', 'local_examination'));
		echo $OUTPUT->tabtree($tabs, $currenttab);
	}
	
	// Added by harish on 19112018 //
	function get_programs(){
		global $DB;
		$programs = $DB->get_records_select_menu('local_program');
		
		$programs = array(null => get_string('selectprogram', 'local_examination'))+$programs;
		// print_object($programs);exit;
		return $programs;
	}

	function fetch_programs(){
		global $DB;
		$programs = $DB->get_records_sql_menu("SELECT id, fullname FROM {local_program} 
												WHERE visible =1");
		$programs = array(null => get_string('selectprogram', 'local_examination'))+$programs;
		return $programs;
	}

	function get_semestersubjectslist($semester, $program){
		global $DB;
		$subsql = "SELECT lsm.id, lsm.subject_name, lsm.marks_segregated 
					 FROM {local_subjectwise_marks} lsm
					 JOIN {local_program} lp ON lsm.programid = lp.id
					WHERE lsm.semester = '$semester'
					  AND lp.fullname LIKE '%$program%'";
		$records = $DB->get_records_sql($subsql);
		if($records){
			return $records;
		}else{
			return null;
		}
	}

	function fetch_studentdata($record, $subjectname){
		global $DB;
		$record = (object) ($record);
		$data_array = new stdClass();
		$programid = $DB->get_field_sql("SELECT id FROM {local_program}
					WHERE fullname = '$record->program'");
		$planid = $DB->get_field_sql("SELECT id FROM {local_curriculum_plan}
					WHERE fullname = '$record->semester' AND programid = $programid");
		// $planid = "1st BPT";	
		$batchid = $DB->get_field_sql("SELECT id FROM {cohort} WHERE name = '$record->batch'");
		$studentid = $DB->get_field_sql("SELECT id FROM {user} WHERE email = '$record->email_id'");
		$subjectsql = "SELECT id FROM {local_subjectwise_marks} WHERE programid = $programid AND semester = $planid AND subject_name = '$subjectname'";
		// print_object($subsql);exit;
		
		$subjectid = $DB->get_field_sql($subjectsql);
		$data_array->programid = $programid;
		$data_array->planid = $planid;
		$data_array->batchid = $batchid;
		$data_array->studentid = $studentid;
		$data_array->manual_subjectid = $subjectid;
		return $data_array;
	}

	function activeplan_name($data = null){
		global $DB;
		$plan_sql = "SELECT lcp.fullname 
					   FROM {local_activeplan_batch} lab 
					   JOIN {local_curriculum_plan} lcp 
					     ON lcp.id = lab.planid 
					  WHERE lab.batchid = $data->batch 
					  	AND lab.programid = $data->program
					  	AND lcp.id = $data->activeplan";
		return $DB->get_field_sql($plan_sql);
	}

	function batch_students($batchid, $planid, $returncount = false, $page = 0, $perpage = 0, $studentname = '', $serviceid = '', $email='',$examid = ''){
		global $DB;
		$params = array('batchid'=>$batchid, 'planid'=>$planid);
		$params['deleted'] = 1;
		
		//Badluck this NOT WORKING   :(
		//SET @serial=0;
		//SELECT 
		//@serial := @serial+1 AS `serial_number`, 
   
		//$sql = "
		//	SELECT u.*, ud.serviceid
		//		FROM
		//			{local_user_clclasses} AS uc
		//		JOIN {user} AS u ON u.id = uc.userid
		//		JOIN {local_userdata} as ud ON ud.userid = u.id AND ud.batchid = uc.batchid
		//		WHERE uc.registrarapproval = 1 AND uc.batchid = :batchid AND uc.planid = :planid
		//		AND u.deleted <> :deleted";
				
		//$sql = "
		//	SELECT u.*, ud.serviceid
		//		FROM
		//		{user} AS u
		//		JOIN {local_userdata} as ud ON ud.userid = u.id
		//		WHERE ud.batchid = :batchid
		//		AND u.deleted <> :deleted";
		$sql = "
			SELECT u.*, ud.serviceid,ea.hallticketnumber
				FROM
				{user} AS u
				JOIN {local_userdata} as ud ON ud.userid = u.id
				JOIN {local_examination_apply} as ea ON ea.studentid = u.id
				WHERE ud.batchid = :batchid
				AND u.deleted <> :deleted";
		if($serviceid){
            $sql .= " AND ud.serviceid LIKE '%$serviceid%'";
        }
        if($studentname){
            $sql .= " AND CONCAT(u.firstname, ' ', u.lastname) LIKE '%$studentname%'";
        }
		if($email){
            $sql .= " AND u.email LIKE '%$email%'";
        }
		if($examid){
	       $sql .= " AND ea.examid=$examid";
		}
		//$sql .= " GROUP BY ud.userid";
		$sql .= " AND ea.status=1 AND ea.coordinatorstatus =1 GROUP BY ud.userid";
		//This requires when $returncount is set
		if($returncount){
			$records = $DB->get_records_sql($sql, $params);
			return sizeof($records);
		}
			
		if($perpage){
			$sql .= " LIMIT $page, $perpage";
		}
		$users = $DB->get_records_sql($sql, $params);
		return $users;
	}
	
	function batchstudents_count($batchid, $planid, $returncount = false, $page = 0, $perpage = 0, $studentname = '', $serviceid = '', $email='',$examid = '', $subjects = false ,$studenttype = false, $program){
		global $DB;
		$params = array('batchid'=>$batchid, 'planid'=>$planid);
		$params['deleted'] = 1;
		$sql = "SELECT u.id, u.email, CONCAT(u.firstname, ' ', u.lastname) AS fullname, ud.serviceid
				FROM
				{user} AS u
				JOIN {local_userdata} as ud ON ud.userid = u.id
				WHERE ud.batchid = :batchid
				AND u.deleted <> :deleted";
		if($returncount && $studenttype){
			$examset = new local_examination_results();
			$users = $DB->get_records_sql($sql, $params);
			$records = $examset->studenttype_filter($subjects, $users, false, $studenttype, $examid, $planid, $batchid, $program);
			return sizeof($records);
		}elseif($returncount){
			$records = $DB->get_records_sql($sql, $params);
			return sizeof($records);
		}
			
		if($perpage){
			$sql .= " LIMIT $page, $perpage";
		}
		$users = $DB->get_records_sql($sql, $params);
		return $users;

	}

	function uploadingstudents_count($batchid, $planid, $returncount = false, $page = 0, $perpage = 0, $studentname = '', $serviceid = '', $email='',$examid = ''){
		global $DB;
		print_object($batchid);
		$params = array('batchid'=>$batchid, 'planid'=>$planid);
		$params['deleted'] = 1;
		
		$sql = "SELECT u.*, ud.serviceid
				FROM
				{user} AS u
				JOIN {local_userdata} as ud ON ud.userid = u.id
				##JOIN {local_examination_apply} as ea ON ea.studentid = u.id
				WHERE ud.batchid = :batchid
				AND u.deleted <> :deleted";
		if($serviceid){
            $sql .= " AND ud.serviceid LIKE '%$serviceid%'";
        }
        if($studentname){
            $sql .= " AND CONCAT(u.firstname, ' ', u.lastname) LIKE '%$studentname%'";
        }
		if($email){
            $sql .= " AND u.email LIKE '%$email%'";
        }
		// if($examid){
	 //       $sql .= " AND ea.examid=$examid";
		// }
		//$sql .= " GROUP BY ud.userid";
		// $sql .= " AND ea.status=1 AND ea.coordinatorstatus =1 GROUP BY ud.userid";
		//This requires when $returncount is set
		if($returncount){
			$records = $DB->get_records_sql($sql, $params);
			return sizeof($records);
		}
			
		if($perpage){
			$sql .= " LIMIT $page, $perpage";
		}
		$users = $DB->get_records_sql($sql, $params);
		return $users;
	}

	function studentmarksuploading($subjects, $tool){
		global $DB;

	}

	function check_marks_settings($examid, $planid){
		global $DB;
		return $DB->record_exists('local_exam_maxmarks', array('examid'=>$examid, 'planid'=>$planid));
	}

	// function batchusers($batch){
	// 	global $DB;
	// 	$subsql = "SELECT u.id, u.email, CONCAT(u.firstname, ',', u.lastname) AS fullname, lu.serviceid as rollnumber
	// 				 FROM {user} u
	// 				 JOIN {local_userdata} lu ON u.id = lu.userid
	// 				WHERE lu.batchid = $batch";
	// 	print_object($subsql);exit;
	// }

	/* Code Ends by Vinod */
	/*
			*@method user_hallticketdownload
			*@param Int $studentid studentid.
			*@param Int $examid examid.
			*@param Int $batchid batchid.
			*@param Char $generatedby generatedby(hallticket downloaded by examcoordinator or student).
			*return $hallticketid is feeorder table id
			**/
	
	function user_hallticketdownload($studentid,$examid,$batchid,$generatedby){
		global $DB,$USER;

		$data = New stdClass();
		$data->studentid= $studentid;
		$data->examid= $examid;
		$data->batchid= $batchid;
		$data->generatedby= $generatedby;
		$data->timecreated= time();
		$data->timemodified= time();
		$data->usermodified= $USER->id;
		
		$hallticketid =$DB->insert_record('local_hallticket_download',$data);
		if($hallticketid)
			return true;
	}
	
	function scheduledexam_batches($examid){
		global $DB;
		$batchexam = $DB->get_record('local_examcreation', array('id'=>$examid), '*', MUST_EXIST);
		$batches = array();
		$batches[null] = '-select-';

		if($batchexam->batchid == 0){
			return $batches;
		}
		
		$found = strpos($batchexam->batchid, ',');
		if($found == true){
			$batchids = explode(',', $batchexam->batchid);
			foreach($batchids as $batchid){
				$batch = $DB->get_record('cohort', array('id'=>$batchid), '*', MUST_EXIST);
				$batches[$batch->id] = format_string($batch->name);
			}
		} else {
			$batch = $DB->get_record('cohort', array('id'=>$batchexam->batchid), '*', MUST_EXIST);
			$batches[$batch->id] = format_string($batch->name);
		}
		
		return $batches;
	}
	/*
			*@method examfee_pay_link
			*@param Int $orderid orderid.
			*return $form is submit button form
			**/
	function examfee_pay_link($orderid){
		global $DB, $USER, $CFG, $PAGE;
	    require_once($CFG->dirroot . '/local/ccavenue/lib.php');
	   
		$ccavenueform = new local_ccavenue_plugin;
		
		$feeinstnace=$DB->get_record('local_fee_order',array('id'=>$orderid));
		$instance= new stdclass();
	    $instance->cost =$feeinstnace->amount;
		//$instance->cost =1;
		$instance->id = $feeinstnace->id;
		$instance->currency = 'INR';
		$instance->feescheduleid = $feeinstnace->feescheduleid;
		$instance->batchid = $feeinstnace->batchid;
		$instance->planid = $feeinstnace->planid;
		
		$form = $ccavenueform->enrol_page_hook($instance);
		return $form;
	 
	} // end of function
	/*
			*@method insert_examfee_order
			*@param Int $feeheadid feeheadid.
			*@param Int $feecategory feecategory.
			*@param Int $feescheduleid feescheduleid.
			*@param Int $planid planid.
			*@param Int $batchid batchid.
			*@param Int $amount amount.
			*@param Int $examid examid.
			*return $hallticketid is feeorder table id
			**/
	function insert_examfee_order($feeheadid,$feecategory,$feescheduleid,$planid,$batchid,$amount,$examid){
		global $DB,$USER;

		$data = New stdClass();
		$data->feeheadid= $feeheadid;
		$data->feecategory= $feecategory;
		$data->feescheduleid= $feescheduleid;
		$data->planid= $planid;
		$data->batchid= $batchid;
		$data->userid= $USER->id;
		$data->amount= $amount;
		$data->examid= $examid;
		$data->timecreated= time();
		$data->usercreated= $USER->id;
		$data->status= 0;
		$data->visible= 1;
		
		$hallticketid =$DB->insert_record('local_fee_order',$data);
		if($hallticketid)
			return $hallticketid;
	}
	/*
     *@method feeschedule_details
     *@param Int $programid programid.
     *@param Int $batchid batchid.
     *@param Int $studentid studentid.
     *@param Int $examid examid.
     *return $student_batch is feeschedule table details
     **/
	function feeschedule_details($programid,$batchid, $studentid,$examid){
		global $DB,$USER,$CFG;
		$exam = $DB->get_record('local_examcreation', array('id'=>$examid), '*', MUST_EXIST);
		if(empty($exam->batchid)){
			$amountsql = "SELECT fs.* FROM {local_feeschedule} AS fs 
							JOIN {local_feeheads} AS fh ON fh.id = fs.feeheadid
							JOIN {local_feecategory_students} AS fcs ON fcs.feecategoryid = fs.feecategory
							WHERE fs.programid=$programid and 
							 $batchid =fcs.batchid and find_in_set($studentid,fcs.studentid)
							AND UCASE(fh.name) ='EXAM FEE' AND fs.examid=$examid ";
			 $student_batch = $DB->get_record_sql($amountsql);
		} else{
			$amountsql = "SELECT fs.* FROM {local_feeschedule} AS fs 
							 JOIN {local_feeheads} AS fh ON fh.id = fs.feeheadid
							 WHERE fs.programid=$programid and 
							 (( find_in_set($batchid, fs.batch) and (fs.studentid is null or fs.studentid='')) or
							 (find_in_set($batchid, fs.batch) and  find_in_set($studentid, fs.studentid)))
							 AND UCASE(fh.name) ='EXAM FEE' AND fs.examid=$examid ";
			 $student_batch = $DB->get_record_sql($amountsql);
		}
		//if(!empty($student_batch->studentid)){
		//	$amountsql .= " AND FIND_IN_SET($USER->id,fs.studentid)";
		//} else{
		//	$amountsql .= " ";
		//}
		//$examfee = $DB->get_record_sql($amountsql);

		
		return $student_batch;
	}
	/*
     *@method insert_examfee_receipt
     *@param Int $batchid batchid.
     *@param Int $planid planid.
     *@param Int $studentid studentid.
     *@param Int $examid examid.
     *@param Int $chequenumber chequenumber or DD or Receipt number.
     *@param Int $fileitemid is uploaded receipt itemid.
     *return true
     **/
	function insert_examfee_receipt($mform,$batchid,$planid,$studentid,$examid,$chequenumber = false,$fileitemid  = false ){
		global $DB,$USER;
		$data = New stdClass();
		$data->batchid= $batchid;
		$data->planid= $planid;
		$data->studentid= $studentid;
		$data->examid= $examid;
		$data->chequenumber= $chequenumber;
		$filename = $mform->get_new_filename('scancopy');
		if(!empty($fileitemid) && !empty($filename)){
			$data->scancopy= $fileitemid;
			$newcontextid = context_user::instance($USER->id, MUST_EXIST);
			$storedfile = $mform->save_stored_file('scancopy', $newcontextid->id, 'local', 'examfee', $data->scancopy, $newfilepath='/',
							  $newfilename=null, $overwrite=false, $newuserid=null);
		}
		$data->timemodified= time();
		$data->timecreated= time();
		$data->usercreated= $USER->id;
		$data->usermodified= $USER->id;
		
		$chequenumberid =$DB->insert_record('local_examfee_receipt',$data);
		if($chequenumberid)
			return $chequenumberid;
	}
	/*
     *@method examfeereceipt_comment
     *@param Int $receiptid Receiptid.
     *@param Char $commenttext rejected comment.
     *@param Int $studentid studentid.
     *return true
     **/
	function examfeereceipt_comment($receiptid,$commenttext,$studentid){
		global $DB,$USER,$CFG;
		require_once($CFG->dirroot.'/local/sms_gateway/gate_way.php');
		require_once($CFG->dirroot.'/local/sms_gateway/lib.php');
		$user_record = $DB->get_record('user', array('id'=>$studentid));
		$info = new stdclass();
		$info->username = fullname($user_record);
		$info->setto = '919959908989';
		//$info->setto = '91'.$user_record->phone1;
		$info->message = "Dear $info->username,
		Your payment (provided receipt number) has been rejected because of invalid number. Don't worry, you can either resubmit receipt number details or make a payment.";
		$results = local_sms_gateway_sendsms($info);
		if(!empty($results)){
		  echo local_sms_gateway_response($results);
		   //test
		   $response = $results->getStatus()->getName();
			//if($response=='PENDING_ENROUTE'){
				$data = New stdClass();
				$data->id= $receiptid;
				$data->comment= $commenttext;
				$data->status= 2;
				
				$chequenumberid =$DB->update_record('local_examfee_receipt',$data);
			if($chequenumberid)
				return true;
			//}
		}
	}
	function date_validation($examid){
	  	$sql="SELECT les.id,les.examid as examid
			FROM {local_examcreation} as le
		    JOIN {local_examination_schedule} as les.examid = le.id
			WHERE le.id = $examid";
			$existexam = $DB->get_record_sql($sql);
		return $existexam;
	}
	
	function download_hallticket($examid,$multiplerecords = false){
		global $DB,$USER;
		$nofeesql = "SELECT * FROM {local_examination_apply} AS ea
					  WHERE  ea.status = 1 AND ea.coordinatorstatus = 1 AND (ea.fee = 0 OR ea.fee IS NULL) AND ea.examid = $examid ";
		if(empty($multiplerecords))
		$nofeesql .= " AND ea.studentid = $USER->id";
		
		$examhalltickets = $DB->get_records_sql($nofeesql,array());
        $receiptpaysql = "SELECT ea.* FROM {local_examination_apply} AS ea
                           JOIN {local_fee_order} AS fo ON  ea.studentid = fo.userid AND ea.examid =fo.examid
						   JOIN {local_ccavenue} AS cc ON cc.order_id = fo.id AND cc.userid = ea.studentid
                          WHERE ea.coordinatorstatus = 1 AND ea.fee > 0 AND cc.order_status ='Success' AND ea.examid = $examid";
		if(empty($multiplerecords))
		$receiptpaysql .= " AND ea.studentid = $USER->id";
		$receiptpay_halltickets = $DB->get_records_sql($receiptpaysql,array());
		
        $ccavenuesql = "SELECT ea.* FROM {local_examination_apply} AS ea
                           JOIN {local_examfee_receipt} AS re ON  ea.studentid = re.studentid AND ea.examid = re.examid
                          WHERE ea.coordinatorstatus = 1 AND ea.fee > 0 AND re.status =1 AND ea.examid = $examid";
		if(empty($multiplerecords))
		$ccavenuesql .= " AND ea.studentid = $USER->id";
		
		$ccavenue_halltickets = $DB->get_records_sql($ccavenuesql,array());

        $halltickets = array_merge($examhalltickets,$receiptpay_halltickets,$ccavenue_halltickets);
		return $halltickets;
	}
	/*
     *@method student_appliedsubjects
     *@param Char $subjectids subjects.
     *return subject names,exam date and timings
     **/
	function student_appliedsubjects($subjectids,$examid){
		global $DB,$USER;
		
		$exam_records = $DB->get_records_sql("SELECT es.*,cc.id AS subjectid, cc.fullname,cs.lecturetype FROM {local_cobaltcourses} AS cc
													JOIN {local_examination_schedule} AS es ON cc.id = es.cobaltcourseid
													JOIN {local_lecturetype} AS cs ON cs.id =es.exammodeid
													WHERE FIND_IN_SET(es.cobaltcourseid,'$subjectids') AND es.examid =$examid AND es.publish = 1");
		$data =array();						
		foreach($exam_records as $exam_record){
			$row = array();
			$examDate=$exam_record->examinationdate;
			if(!empty($exam_record->examinationdate)){
				$row[] = date('d M Y',$examDate);
			} else{
				$row[] = "----";
			}
			$starttime = date('g:i a', strtotime($exam_record->starttime));
			$endtime = date('g:i a', strtotime($exam_record->endtime));
			if((empty($exam_record->starttime) || $exam_record->starttime == 00) && (empty($exam_record->endtime) || $exam_record->endtime == 00)){
				$row[] = "----";
			} else{
				$row[] =$starttime.' to '.$endtime;
			}
			//$courseid=$exam_record->cobaltcourseid;
			$row[] =$exam_record->fullname.'-'.$exam_record->lecturetype;
			$data[] =$row;
		
		}
		$date = get_string('date', 'local_examination');
		$time = get_string('time', 'local_examination');
		$subject = get_string('subject', 'local_examination');
		
		$table = new html_table();
		$table->head = array($date,$time,$subject);
		$table->align = array('left', 'left', 'left');
		$table->data = $data;
		$table->id = 'appliedsubjects';
		$output = html_writer::table($table);
		return $output;
	}
	
	/*
     *@method examination_examtype
     *@param Char $examid examid.
     *return schoolid examtype
     **/
	function examination_examtype($examid){
	  global $DB,$USER;
	  $sql="SELECT lcs.id,lcs.lecturetype
			FROM {local_examcreation} as le
		    JOIN {local_activeplan_batch} AS leb ON leb.programid = le.programid
			JOIN {local_lecturetype} AS lcs ON lcs.schoolid = leb.schoolid
			WHERE le.id = $examid";
		$records = $DB->get_records_sql($sql);

		$examtype = array(null=>'---Select---');
      foreach($records as $record){

			$examtype[$record->id] = $record->lecturetype;
        }
		return $examtype;
	}
	/*
     *@method examination_examtype
     *@param Int $examid examid.
     *@param Int $planid planid.
     *return subjects
     **/
	
	function scheduledsubjects($examid,$planid){
		global $DB;
        $subjects = $DB->get_records_sql("SELECT DISTINCT sc.cobaltcourseid,sc.*, cc.fullname
                                            FROM {local_cobaltcourses} AS cc
                                            JOIN {local_examination_schedule} AS sc ON cc.id = sc.cobaltcourseid
                                            WHERE sc.examid =$examid " /* AND sc.publish = 1 AND es.planid = $planid*/);
		
		return $subjects;
	}
	
	/*
     *@method examination_examtype
     *@param Int $subjectid subjectid.
     *@param Int $planid examid.
     *return subjects
     **/
	function student_classes($subjectid,$userid){
		global $DB,$CFG, $USER;
		require_once($CFG->dirroot . '/local/timetable/stulib.php');
		$enrollclasses = local_timetable_activesemester_student_detail($userid);
		$schedule_subject=array();
		foreach($enrollclasses->classes as $class){
			$enrol_class = $DB->get_record_sql("SELECT * FROM {local_clclasses} WHERE id = $class AND FIND_IN_SET(cobaltcourseid,'$subjectid')");
			//$enrol_subjects = $DB->get_records_sql("SELECT es.id,cc.id AS subjectid, cc.fullname,es.examinationdate FROM {local_cobaltcourses} AS cc
			//									    JOIN {local_examination_schedule} AS es ON cc.id = es.cobaltcourseid
			//									    WHERE FIND_IN_SET($enrol_class->cobaltcourseid,'$subjectid') AND es.examid =$examid AND es.publish = 1");
			//		
			if(!empty($enrol_class)){
				$schedule_subject[] = $enrol_class->id;
			}
		}
		return $schedule_subject;
	}
	function scheduledexam_students($examid,$planid,$batchid, $removeduplicate = false){
		global $DB;
		$exam = $DB->get_record('local_examcreation', array('id'=>$examid), '*', MUST_EXIST);

        $sql = "
			SELECT u.*, ud.serviceid
				FROM
				{user} AS u
				JOIN {local_userdata} as ud ON ud.userid = u.id
				WHERE ud.batchid IN ($batchid)
				AND u.deleted <> :deleted ";
        if(!empty($exam->studentid)){
            $sql .= " AND (FIND_IN_SET(u.id,'$exam->studentid'))";
        } 
		if($removeduplicate){
			$sql .= " AND ud.userid NOT IN (select studentid from {local_hallticket_download} where examid = {$examid} and batchid = {$batchid})";
		}
		
        $students = $DB->get_records_sql($sql, array('deleted'=>1));
		return $students;
	}
	/*
     *@method published_exams
     *return exams
     **/
	function published_exams(){
		global $DB;
		 $sql = " SELECT DISTINCT ec.id,ec.* FROM {local_examcreation} AS ec
					JOIN {local_examination_students} AS es ON ec.id =es.examid
					JOIN {local_examination_schedule} AS sc ON ec.id =sc.examid
					WHERE sc.publish =1	ORDER BY ec.id DESC";
            
        $newexams = $DB->get_records_sql($sql,array());
		
		/************for old records start************/
		$sql = "SELECT DISTINCT ec.id,ec.name FROM {local_examcreation} AS ec
						   JOIN {local_examination_schedule} AS es ON ec.id =es.examid
						  WHERE ec.visible =1 AND es.publish =1  ORDER BY ec.id DESC";
        $oldexams = $DB->get_records_sql($sql,array());
		/************for old records end************/

		$exams = array_merge($newexams,$oldexams);
		$examsid[NULL] = "---Select---";
		foreach ($exams as $exam) {
			$examsid[$exam->id] = $exam->name;
		}
		return $examsid;
	}
	/*
     *@method published_exams
     *@param Int $subjectid subjectid.
     *@param Int $planid examid.
     *return plans
     **/
	function publishedexam_plans($examid){
		global $DB;
		$planids =array();
		$planids[NULL] = '---Select---';
		
		/************for old records start************/
		$oldsql = "SELECT DISTINCT planid FROM {local_examination_schedule} WHERE examid = $examid AND ( planid !=0 AND planid IS NOT null AND planid!='') ";
        $oldplans = $DB->get_records_sql($oldsql,array());
		/************for old records end************/

		$sql = " SELECT ec.* FROM {local_examcreation} AS ec WHERE ec.id = $examid AND (ec.planid IS NOT null AND ec.planid !=0 AND ec.planid!='') ORDER BY ec.id DESC";
        $newplans = $DB->get_records_sql($sql,array());
		$plans = array_merge($oldplans,$newplans);
		
		foreach ($plans as $plan) {
			$planids[$plan->planid] = $DB->get_field('local_curriculum_plan', 'fullname', array('id'=>$plan->planid));
		}
		return $planids;
	}
	/*
     *@method published_exams
     *@param Int $examid examid.
     *@param text $select Select.
     *return batchs
     **/
	function publishedexam_batchs($examid,$select = false){
		global $DB;
		/************for old records start************/
		$oldsql = "SELECT  batchid FROM {local_examcreation} WHERE id = $examid AND (batchid != '0' AND batchid IS NOT NULL AND batchid !='')";
		$oldbatchs = $DB->get_records_sql($oldsql,array());
		/************for old records end************/

		$sql = " SELECT ec.* FROM {local_examination_students} AS ec WHERE ec.examid = $examid ORDER BY ec.id DESC";
        $newbatchs = $DB->get_records_sql($sql,array());
		$batchs = array_merge($oldbatchs,$newbatchs);
		if(!empty($select))
		$batch_list[NULL] = "---Select---";
		foreach ($batchs as $batch) {
			$batchnames = $DB->get_records_sql("SELECT * FROM {cohort} WHERE FIND_IN_SET(id,'$batch->batchid')");
			foreach ($batchnames as $batchname){
				$batch_list[$batchname->id] = $batchname->name;
			}
		}
		return $batch_list;
	}
	/*
     *@method noneligible_batch_students
     *@param Int $examid examid.
     *@param Int $batchid batchid.
     *return students
     **/
	function noneligible_batch_students($examid,$batchid){
		global $DB;

		$users = $DB->get_records_sql("SELECT u.* FROM {local_userdata} AS ud
										JOIN {user} AS u ON u.id =ud.userid
										JOIN {local_examination_apply} AS ea ON ea.batchid = ud.batchid
										AND ea.studentid =ud.userid WHERE ud.batchid = $batchid
										AND ea.examid = $examid AND UCASE(ea.verified)='NO' AND u.deleted =0"); 
		$user_list =array('select');
		foreach ($users as $user){
			$user_list[$user->id] = $user->firstname.' '.$user->lastname.' - '.$user->email;
		}
		return $user_list;
	}
	
	/*
     *@method publishedexam_batch_students
     *@param Int $examid examid.
     *@param Char $batchid batchid.
     *@param BOOL $removeduplicate 0 OR 1.
     *return students
     **/
	function publishedexam_batch_students($examid,$batchid,$removeduplicate = false){
		global $DB;
		$applied_students = $this->download_hallticket($examid,$multiplerecords = true);
		$appliedstudent_list = array();
		foreach($applied_students as $applied_student){
			$appliedstudent_list[] = $applied_student->studentid;
		}
		$oldexam = $DB->get_record('local_examcreation', array('id'=>$examid), '*', MUST_EXIST);
		if(empty($oldexam->batchid)){
			$scheduledstudents_sql = "SELECT * FROM {local_examination_students} WHERE FIND_IN_SET(batchid,'$batchid') AND examid = :examid";
			$scheduledstudents = $DB->get_records_sql("$scheduledstudents_sql",array('examid'=>$examid));
			$studentlist = array();
			foreach($scheduledstudents as $scheduledstudent){
				$studentlist[]= $scheduledstudent->studentid;
			}
			$students = implode(',',$studentlist);
		} else{
			/************for old records start************/
			$oldexam = $DB->get_record('local_examcreation', array('id'=>$examid), '*', MUST_EXIST);
			if(!empty($oldexam->studentid)){
				$students = $oldexam->studentid;
			} else{
				$batchstudents = $DB->get_records_sql_menu("SELECT id,userid FROM {local_userdata} WHERE batchid=$batchid");
				$students = implode(',',$batchstudents);
			}
			/************for old records end************/
		}
		$sql ="SELECT u.* FROM {local_userdata} AS ud
				JOIN {user} AS u ON u.id =ud.userid
				WHERE FIND_IN_SET(ud.userid,'$students')
				AND FIND_IN_SET(ud.batchid,'$batchid') AND u.deleted =0 ";
		if($removeduplicate && !empty($appliedstudent_list)){
			$list = implode(',',$appliedstudent_list);
			$sql .=  " AND ud.userid NOT IN ($list)"; 
		} 
		$users = $DB->get_records_sql($sql);
		return $users;
	}
		/*
     *@method batch_unenrol_students
     *@param Int $examid examid.
     *@param Int $userid studentsid.
     *@param Int $batchid batchid.
     *return subjects
     **/
	function batch_unenrol_students($examid, $userid,$batchid){
	  global $DB, $CFG, $USER;
	  $class = $DB->get_record('local_examination_students', array('examid'=>$examid,'batchid'=>$batchid));
	  $students = array_diff(explode(',',$class->studentid),array($userid));
	  $user = $DB->get_record('user', array('id'=>$userid), '*', MUST_EXIST);
	  if($uclass_id = $DB->get_record_sql("SELECT * FROM {local_examination_students} WHERE examid=$examid AND batchid =$batchid AND FIND_IN_SET($userid,studentid)")){
		 $uclass_id->studentid = implode(',',array_filter($students));
		  $DB->update_record('local_examination_students', $uclass_id);
		}
	  return true;
	}
	
	function generate_hallticketnumber($hallticketpatten, $examid,$hallticketstartingnumber,$batchid= false){
		 global $DB;
			if(!empty($batchid)){
				$recent_hallticketnumber = $DB->get_record_sql("SELECT * FROM {local_examination_apply} WHERE examid=$examid AND batchid =$batchid  ORDER BY timecreated DESC");
			} else{
				$recent_hallticketnumber = $DB->get_record_sql("SELECT * FROM {local_examination_apply} WHERE examid=$examid ORDER BY timecreated DESC");
			}
			$hallticketpatten_length = strlen(trim($hallticketpatten));
			$lastnumber = substr($recent_hallticketnumber->hallticketnumber, $hallticketpatten_length);
			//if(empty($lastnumber)){
			//	$lastnumber = $hallticketstartingnumber;
			//}
			$hallticketstartingnumber_length = strlen(trim($lastnumber));
			if(empty($lastnumber)){
					$last = $hallticketstartingnumber;
					$hallticketstartingnumber_length = strlen(trim($hallticketstartingnumber));
			} else{
					$last = $lastnumber + 1;
					$hallticketstartingnumber_length = strlen(trim($lastnumber));
			}

			$nextnumber = str_pad( $last, $hallticketstartingnumber_length ,"0",STR_PAD_LEFT);
			$hallticketnumber = $hallticketpatten.$nextnumber;
	
			return $hallticketnumber;
	}
}

/**
 * Base class to avoid duplicating code.
 */
abstract class core_batch_assign_user_selector_base_exam extends user_selector_base {
    protected $context;
    /**
     * @param string $name control name
     * @param array $options should have two elements with keys groupid and courseid.
     */
    public function __construct($name, $options) {
        global $CFG;
        $options['accesscontext'] = context_system::instance();
        parent::__construct($name, $options);
        //$this->classid = $options['classid'];
        $this->batchid = $options['batchid'];
        $this->context = $options['accesscontext'];
		$this->examid= $options['examid'];
        require_once($CFG->dirroot . '/group/lib.php');
    }
//    protected function get_options() {
//        global $CFG;
//        $options = parent::get_options();
//        $options['file'] = 'local/clclasses/classlib.php';
//	    //$options['classid'] = $this->classid;
//		$options['batchid'] = $this->batchid;
//		$options['examid'] = $this->examid;
//        return $options;
//    }
}

class batch_students_selector_exam extends core_batch_assign_user_selector_base_exam {
    public function find_users($search) {
        global $DB;
		$userstoremove = $DB->get_records('local_examination_students',array('examid'=>$this->examid,'batchid'=>$this->batchid));
		list($wherecondition, $params) = $this->search_sql($search, 'u');
        list($sort, $sortparams) = users_order_by_sql('u', $search, $this->accesscontext);
        $params = array_merge($params, $sortparams);
        $sql = "SELECT " . $this->required_fields_sql('u') . "
                FROM {user} AS u
				JOIN {local_userdata} AS ud ON u.id =ud.userid
				JOIN {local_examination_students} AS es
                WHERE $wherecondition AND FIND_IN_SET(u.id,es.studentid)
																AND ud.batchid = $this->batchid AND es.examid=  $this->examid 
                ORDER BY $sort";
        $existingusers = $DB->get_records_sql($sql, $params);
        if (empty($existingusers)) {
            return array();
        }
        // We have users. Out put them in groups by context depth.
        // To help the loop below, tack a dummy user on the end of the results
        // array, to trigger output of the last group.
        $dummyuser = new stdClass;
        $dummyuser->contextid = 0;
        $dummyuser->id = 0;
        $dummyuser->component = '';
        $existingusers[] = $dummyuser;
        $results = array(); // The results array we are building up.
        $doneusers = array(); // Ensures we only list each user at most once.
        $currentcontextid = $this->context->id;
        $currentgroup = array();
        foreach ($existingusers as $user) {
            if (isset($doneusers[$user->id])) {
                continue;
            }
            $doneusers[$user->id] = 1;
            $groupname = $this->this_con_group_name($search, count($currentgroup));
            $results[$groupname] = $currentgroup;
            $currentgroup[$user->id] = $user;
        }
        return $results;
    }
    protected function this_con_group_name($search, $numusers) {
        // Special case in the System context.
        if ($search) {
            return get_string('extusersmatching', 'local_clclasses', $search);
        } else {
            return get_string('extusers', 'local_clclasses');
        }
    }
}

/**
 * User selector subclass for the list of users who are not in a certain group.
 * Used on the add group members page.
 */
class batch_non_students_selector_exam extends core_batch_assign_user_selector_base_exam {
    public function find_users($search) {
        global $DB;
		//protected $context;
        // Get list of allowed roles.
        $context = context_system::instance();
        // Get the search condition.
		list($searchcondition, $searchparams) = $this->search_sql($search, 'u');
        list($sort, $sortparams) = users_order_by_sql('u', $search, $this->accesscontext);
        $orderby = ' ORDER BY ' . $sort;
		if(!empty($this->examid) && !empty($this->batchid)){
			$class = $DB->get_record('local_examination_students', array('examid' => $this->examid,'batchid'=>$this->batchid));
			$exist_students = explode(',',$class->studentid);
			$studentids = implode(',',array_filter($exist_students)); 
		} 
	   $fields = "SELECT 
                " . $this->required_fields_sql('u');
        if($this->batchid > 0){
		  $sql = " FROM {user} AS u
				  JOIN {cohort} as  ba                         
				  JOIN {cohort_members} as cm ON cm.cohortid=ba.id AND cm.userid=u.id
				  JOIN {local_userdata} d ON d.userid = u.id  
				  WHERE  ba.id = :batchid";
		if(array_filter($exist_students)) {
			$sql .= "AND d.userid NOT IN ($studentids)";
		}
		$sql .= "AND $searchcondition";
			$params = $searchparams;
			$params['batchid'] = $this->batchid;
			$users = $DB->get_records_sql("$fields $sql", $params);

			if (!$this->is_validating()) {
			  
				$potentialmemberscount = $DB->count_records_sql("SELECT COUNT(DISTINCT u.id) $sql", $params);
				
				if ($potentialmemberscount > $this->maxusersperpage) {
				  
					return $this->too_many_results($search, $potentialmemberscount);
				  
				}
			}
			$availableusers = $DB->get_records_sql($fields . $sql . $orderby, array_merge($params, $sortparams));
			if (empty($availableusers)) {
				return array();
			}
        }// end of batch condition if
		//}
        else{
           $availableusers =array(); 
        }
        if ($search) {
            $groupname = get_string('potusersmatching', 'local_clclasses', $search);
        } else {
            $groupname = get_string('potusers', 'local_clclasses');
        }
		
        return array($groupname => $availableusers);
    }
}


class local_examination_results {
	
	function results_batch_students($examid,$batchid, $planid, $returncount = false, $studentname = '', $serviceid = '', $email='',$userid=''){
		global $DB;
		$params = array('examid'=>$examid,'batchid'=>"$batchid");
		$params['deleted'] = 1;
   
		$sql = "SELECT u.*, ud.serviceid,ea.hallticketnumber
				FROM {user} AS u 
				JOIN {local_examination_apply} AS ea ON  ea.studentid=u.id
				JOIN {local_userdata} as ud ON ud.userid = u.id 
				WHERE FIND_IN_SET(ud.batchid,(:batchid))  AND ea.status = 1 AND ea.coordinatorstatus =1
				AND u.deleted <> :deleted AND examid=:examid";
		if($serviceid){
            $sql .= " AND ud.serviceid LIKE '%$serviceid%'";
        }
        if($studentname){
            $sql .= " AND CONCAT(u.firstname, ' ', u.lastname) LIKE '%$studentname%'";
        }
		if($email){
            $sql .= " AND u.email LIKE '%$email%'";
        }
		if($userid){
			$sql .= " AND u.id = $userid";
		}
		$sql .= " GROUP BY u.id";
		//This requires when $returncount is set
		if($returncount){
			$records = $DB->get_records_sql($sql, $params);
			return sizeof($records);
		}
		$users = $DB->get_records_sql($sql, $params);
		//print_object(count($users));
		return $users;
	}
	/*
     *@method published_exams
     *@param Int $examid examid.
     *@param Int $planid planid.
     *@param Int $batchid batchid.
     *@param Char $subjectsin subjectid.
     *@param Char $studentname studentname.
     *return batchs
     **/	

	function studenttype_filter($subjects, $users, $returncount = false, $studenttype, $examid, $planid, $batchid, $program){
		global $DB;
		$finalusers = array();
		foreach ($users as $key => $value) {
			$subsql = "SELECT count(lmm.id) FROM {local_subjectwise_marks} lsm
					JOIN {local_manual_studentmarks} lmm 
					ON lsm.id = lmm.manual_subjectid
					WHERE lmm.totalmarks_gained >= lsm.totalminmarks_subject
					AND lmm.studentid = $key
					AND lmm.planid = $planid 
					#AND lsm.semester = $planid";
			// print_object($subsql);
			$result = $DB->count_records_sql($subsql);
			if(!empty($result)){
				if($studenttype == "toppers" && $result == count($subjects)){
					$finalusers[$key] = $value;
				}elseif($studenttype == "atkt" && (count($subjects)-$result) == 1){
					$finalusers[$key] = $value;
				}elseif($studenttype == "fail" && (count($subjects)-$result) > 1){
					$finalusers[$key] = $value;
				}
			}	
		}
		return $finalusers;
	}

	function toppers_result($examid, $planid, $batchid, $subjectsin=false, $studentname=false, $serviceid=false, $email=false, $errors=false,$resulttype = false,$studentid = false){
		global $DB, $OUTPUT, $CFG;
		
		$publishexam_status = $DB->get_field('local_examcreation','publishresults',array('id'=>$examid));
		if(empty($publishexam_status)){
			return "<div>Exam marks not published by COE</div>";
		}
		/**************for student record start*********************/
		if(!empty($studentid)){
			$users = $this->topper_students($examid, $planid, $batchid,$resulttype);
		}
		/**************for student record end*********************/
		
			
		if($resulttype == 'toppers'){
			$users = $this->topper_students($examid, $planid, $batchid,$resulttype);
			if(empty($users)){
				return "<div>Toppers students are not avaliable</div>";
			}
		}else if($resulttype == 'atkt'){
			$users = $this->topper_students($examid, $planid, $batchid,$resulttype);
			if(empty($users)){
				return "<div>ATKT students are not avaliable</div>";
			}
		} else if($resulttype == 'fail'){
			$users = $this->topper_students($examid, $planid, $batchid,$resulttype);
			if(empty($users)){
				return "<div>Fail students are not avaliable</div>";
			}
		} else{
			if(!empty($studentid)){
				$users = $this->results_batch_students($examid,$batchid, $planid, '', '', '', '',$studentid);
			} else{
				$users = $this->results_batch_students($examid,$batchid, $planid, '', '', '', '');
			}
			if(empty($users)){
				return "<div>students are not avaliable</div>";
			}
		}
		
		/**************for student *******************
		   student applied only two subjects but exam is schedule for more than two subject.
		   student has to see two subject for that we are using below condination	  *********************/
		$where = ''; //only for checking, need to remove this
        if($subjectsin != ''){
            $where = ' AND cobaltcourseid IN ('.$subjectsin.')';
        }
		/************** student end*********************/
		
        //Table data itself displaying as the headings of the table, with rowspan and colspan.
		if(!empty($studentid)){ //for student view
			$data =	$this-> results_tableheader($examid, $planid, $batchid, $subjectsin, false, false, false, false);
		} else{
			$data =	$this-> results_tableheader($examid, $planid, $batchid, false, false, false, false, false);
		}
		
        $output = '';
		$output .= '<div class = "exam_results">';
        $table = new html_table();
        $i = 1;
        foreach($users as $user){
            $line = array();
            $line[] = $i;
            //We need hallticket here, change the
            $udata = $DB->get_record('local_userdata', array('userid'=>$user->id));
            $line[] = $user->hallticketnumber;
            $line[] = $user->email;
			$line[]=$user->firstname.' '.$user->lastname;
			$grandtotal = 0;
			$status = array();
			$schedules_subjects = $DB->get_records_select('local_examination_schedule', 'examid = ? '.$where.' GROUP BY cobaltcourseid', array('examid'=>$examid));
            foreach($schedules_subjects as $schedules_subject){
				$student_subjects = $DB->get_record_sql("SELECT * FROM {local_examination_apply} WHERE examid=$examid AND studentid =$user->id AND FIND_IN_SET($schedules_subject->cobaltcourseid,subjectid) ");
				$substatus = array();
				$total = 0;
				$examtypes_marks = $DB->get_records('local_examination_schedule', array('examid'=>$examid, 'cobaltcourseid'=>$schedules_subject->cobaltcourseid));
				foreach($examtypes_marks as $examtypes_mark){
					$maxmarks = $DB->get_records('local_exam_maxmarks', array('examid'=>$examid, 'planid'=>$planid, 'examtypeid'=>$examtypes_mark->exammodeid));
					$sub_total = 0;
					foreach($maxmarks as $maxmark){
						$markstype = $DB->get_record('local_exammarks_types', array('id'=>$maxmark->markstypeid), '*', MUST_EXIST);
					
						$mark = $DB->get_record('local_exam_studentmarks', array('examid'=>$examid, 'planid'=>$planid, 'courseid'=>$schedules_subject->cobaltcourseid,
																				'examtypeid'=>$examtypes_mark->exammodeid, 'markstypeid'=>$maxmark->markstypeid, 'studentid'=>$user->id));
						if(!empty($mark->marks)){
							$line[]=$mark->marks;
						} else{
							if($student_subjects){
								$line[]='Ex';
							}else{
								$line[]='NA';
							}
						}
						if(!empty($mark->marks)){
							$sub_total+=$mark->marks;
							$total+= $mark->marks;
						}
					}
					if($sub_total < $examtypes_mark->minmarks){
						$status[] = 'Fail';
						$substatus[] = 'Fail';
						$subtotal_failcell3 = new html_table_cell();
						if(!empty($sub_total)){
							$subtotal_failcell3->text = $sub_total;
							$subtotal_failcell3->attributes = array('class'=>'subtotal_failcell');
							$line[]=$subtotal_failcell3;
						} else{
							if($student_subjects){
								$subtotal_failcell3->text = 'Ex';
								//$subtotal_failcell3->attributes = array('class'=>'subtotal_failcell');
								$line[]=$subtotal_failcell3;
							}else{
								$subtotal_failcell3->text = 'NA';
								//$subtotal_failcell3->attributes = array('class'=>'subtotal_failcell');
								$line[]=$subtotal_failcell3;
							}
						}
					} else{
						$line[]=$sub_total;
					}
				}
				if(!empty($substatus)){
					$total_failcell3 = new html_table_cell();
					if(!empty($sub_total)){
						$total_failcell3->text = $total;
						$total_failcell3->attributes = array('class'=>'grandtotal_failcell');
						$line[]=$total_failcell3;
						$line[]="FFF";
					} else{
						if($student_subjects){
							$total_failcell3->text = 'Ex';
							//$total_failcell3->attributes = array('class'=>'grandtotal_failcell');
							$line[]=$total_failcell3;
							$line[]="";
						}else{
							$total_failcell3->text = 'NA';
							//$total_failcell3->attributes = array('class'=>'grandtotal_failcell');
							$line[]=$total_failcell3;
							$line[]="";
						}
					}
				} else{
					$line[]=$total;
					$line[]="";
				}
				$grandtotal+=$total;
            } 
			$line[]=$grandtotal;
			if(!empty($status)){
				$grandtotal_failcell3 = new html_table_cell();
				$grandtotal_failcell3->text = 'Fail';
				$grandtotal_failcell3->attributes = array('class'=>'grandtotal_failcell');
				$line[]=$grandtotal_failcell3;
			} else{
				$line[]='Pass';
			}
            $data[] = $line;
            $i++;
        }
        $table->data = $data;
        $output .= html_writer::table($table);
        $output .= "</div>";
			
		return $output;
	}
	/*
     *@method published_exams
     *@param Int $examid examid.
     *@param text $select Select.
     *return batchs
     **/
	function results_tableheader($examid, $planid, $batchid, $subjectsin=false/*, $studentname=false, $serviceid=false, $email=false, $errors=false*/){
		global $DB, $OUTPUT, $CFG;
        $examset = new local_examination();
        //$users = $this->results_batch_students($batchid, $planid, false, $studentname, $serviceid, $email);
        $exam = $DB->get_record('local_examcreation', array('id'=>$examid), '*', MUST_EXIST);
		
		$heads = array(get_string('sno', 'local_examination'),
                       get_string('hallticket', 'local_examination'),
                       //get_string('studentname', 'local_examination'),
                       get_string('email', 'local_examination'));
		
		$data = array();
		$static = array();
		foreach($heads as $head){
			$cell = new html_table_cell();
			$cell->text = $head;
			$cell->rowspan = 6;
			$cell->attributes = array('class'=>'addmarkshead addmarkshead1');
			$static[] = $cell;
		}
		$data[] = $static;
		
        $where = ''; //only for checking, need to remove this
        if($subjectsin != ''){
            $where = ' AND cobaltcourseid IN ('.$subjectsin.')';
        }
		
        //Setting up header
        $schedules = $DB->get_records_select('local_examination_schedule', 'examid = ? '.$where.' GROUP BY cobaltcourseid', array('examid'=>$examid));
        /*$data = array();*/
        $head1 = array();$head2 = array();$head3 = array();$head4 = array();$head5 = array();
		$studentnamecell = new html_table_cell();
		$studentnamecell->text = get_string('studentname', 'local_examination');
		$studentnamecell->rowspan = 3;
		//$studentnamecell->attributes = array('class'=>'addmarkshead addmarkshead1');
		
		$studentnamecell2 = new html_table_cell();
		$studentnamecell2->text = 'max';
		$studentnamecell2->rowspan = 1;
		//$studentnamecell2->attributes = array('class'=>'addmarkshead addmarkshead1');
		
		$studentnamecell3 = new html_table_cell();
		$studentnamecell3->text = 'min';
		$studentnamecell3->rowspan = 1;
		//$studentnamecell3->attributes = array('class'=>'addmarkshead addmarkshead1');
		$head1[] = $studentnamecell;
		$head4[] = $studentnamecell2;
		$head5[] = $studentnamecell3;
		$cobaltcourse = array();
        foreach($schedules as $schedule){
            $cobaltcourse = $DB->get_record('local_cobaltcourses', array('id'=>$schedule->cobaltcourseid), '*', MUST_EXIST);
			//Heading1 to display the subjects scheduled
            $cell1 = new html_table_cell();
            $cell1->text = $cobaltcourse->fullname;
			$cell1->attributes = array('class'=>'addmarkshead addmarkshead1');
			$coursespan = 1;
           //$a1 = array($schedule->cobaltcourseid);
            $total_max_marks = 0;
			$subjectminmarks = 0;
			$examtypes = $DB->get_records('local_examination_schedule', array('examid'=>$examid, 'cobaltcourseid'=>$schedule->cobaltcourseid));

            foreach($examtypes as $examtype){
                $extype = $DB->get_record('local_lecturetype', array('id'=>$examtype->exammodeid), '*', MUST_EXIST);
				//Heading2, Type of exams either theory or practical
                $cell2 = new html_table_cell();
                $cell2->text = $extype->lecturetype;
				$cell2->attributes = array('class'=>'addmarkshead addmarkshead2');
                
				$forcolspan = 1;
                $maxmarks = $DB->get_records('local_exam_maxmarks', array('examid'=>$examid, 'planid'=>$planid, 'examtypeid'=>$examtype->exammodeid));
				
				$exam_total_marks = 0;
                foreach($maxmarks as $maxmark){
                    $markstype = $DB->get_record('local_exammarks_types', array('id'=>$maxmark->markstypeid), '*', MUST_EXIST);
            		
					//This is the marks heading, One exam type is a sum of multiple marks
                    $cell3 = new html_table_cell();
                    $cell3->text = $markstype->shortname;
					$cell3->attributes = array('class'=>'addmarkshead addmarkshead3', 'cobaltcourseid'=>$cobaltcourse->id, 'examtypeid'=>$extype->id, 'markstypeid'=>$markstype->id, 'maxmarks'=>$maxmark->maxmarks);
					
                    $cell4 = new html_table_cell();
                    $cell4->text = $maxmark->maxmarks;
					$cell4->attributes = array('class'=>'addmarkshead addmarkshead4');
					
					$cell5 = new html_table_cell();
                    $cell5->text = '';
					$cell5->attributes = array('class'=>'minmarkshead minmarkshead4');

					$total_max_marks += $maxmark->maxmarks;
					$exam_total_marks += $maxmark->maxmarks;
                    $head3[] = $cell3;
                    $head4[] = $cell4;
                    $head5[] = $cell5;
					
					$forcolspan++;
					$coursespan++;
                }
				$cell3_1 = new html_table_cell();
				$cell3_1->text = 'Total';
				$cell3_1->attributes = array('class'=>'addmarkshead addmarkshead3_total_1');
				$head3[] = $cell3_1;
				
				$cell4_2 = new html_table_cell();
				$cell4_2->text = $exam_total_marks;
				$cell4_2->attributes = array('class'=>'addmarkshead addmarkshead4_total_1');
				$head4[] = $cell4_2;
				
				$cell5_1 = new html_table_cell();
				$cell5_1->text =$schedule->minmarks;
				$cell5_1->attributes = array('class'=>'minmarkshead minmarkshead4_total_1');
				$head5[] = $cell5_1;
				
				$forcolspan = $forcolspan+1;
                $cell2->colspan = $forcolspan > 1 ? ($forcolspan -1) : $forcolspan;
                
                $head2[] = $cell2;
				$subjectminmarks += $schedule->minmarks;
            }
			$cell2_1 = new html_table_cell();
            $cell2_1->text = 'Total';
			$cell2_1->attributes = array('class'=>'addmarkshead addmarkshead2_total_1');
			$head2[] = $cell2_1;
			
			$cell2_2 = new html_table_cell();
            $cell2_2->text = 'Remarks';
			$cell2_2->attributes = array('class'=>'addmarkshead addmarkshead2_total_2');
			$head2[] = $cell2_2;
						
			$cell3_2 = new html_table_cell();
            $cell3_2->text = '---';
			$cell3_2->attributes = array('class'=>'addmarkshead addmarkshead3_total_2');
			$head3[] = $cell3_2;
			
			$cell3_3 = new html_table_cell();
            $cell3_3->text = '---';
			$cell3_3->attributes = array('class'=>'addmarkshead addmarkshead3_total_2');
			$head3[] = $cell3_3;
			
			$cell4_2 = new html_table_cell();
            $cell4_2->text = $total_max_marks;
			$cell4_2->attributes = array('class'=>'addmarkshead addmarkshead4_total_2');
			$head4[] = $cell4_2;
			
			$grardtotal_maxmarks += $total_max_marks;
			
			$cell4_3 = new html_table_cell();
            $cell4_3->text = '---';
			$cell4_3->attributes = array('class'=>'addmarkshead addmarkshead4_total_2');
			$head4[] = $cell4_3;
			
			$cell5_1 = new html_table_cell();
            $cell5_1->text = $subjectminmarks;
			$cell5_1->attributes = array('class'=>'addmarkshead addmarkshead4_total_2');
			$head5[] = $cell5_1;
			$grardtotal_minmarks += $subjectminmarks;
			
			$cell5_1 = new html_table_cell();
            $cell5_1->text = '---';
			$cell5_1->attributes = array('class'=>'addmarkshead addmarkshead4_total_2');
			$head5[] = $cell5_1;
			
			$coursespan = $coursespan+4;
			if(count($examtypes) > 1)
	            $cell1->colspan = $coursespan > 1 ? ($coursespan -1) : $coursespan;
			else
			    $cell1->colspan = $coursespan-2;

            $head1[] = $cell1;
		}
		$grandtotalcell1 = new html_table_cell();
		$grandtotalcell1->text = 'Grand Total';
		$grandtotalcell1->attributes = array('class'=>'totalshead totalshead1');
		$grandtotalcell1->rowspan = 3;
		
		$grandtotalcell2 = new html_table_cell();
		$grandtotalcell2->text = $grardtotal_maxmarks;
		$grandtotalcell2->attributes = array('class'=>'totalshead totalshead1');
		$grandtotalcell2->rowspan = 1;
		
		$grandtotalcell3 = new html_table_cell();
		$grandtotalcell3->text = $grardtotal_minmarks;
		$grandtotalcell3->attributes = array('class'=>'totalshead totalshead1');
		$grandtotalcell3->rowspan = 1;
		
		$head1[]= $grandtotalcell1;
		$head4[]= $grandtotalcell2;
		$head5[]= $grandtotalcell3;

		//$cell1->colspan = $coursespan > 1 ? ($coursespan -1) : $coursespan;
		$resultcell1 = new html_table_cell();
		$resultcell1->text = 'Results';
		$resultcell1->attributes = array('class'=>'toatalshead toatalshead1');
		$resultcell1->rowspan = 5;
		
		$head1[]= $resultcell1;
		
		$data[] = $head1;
        $data[] = $head2;
		$data[] = $head3;
        $data[] = $head4;
        $data[] = $head5;
		
        if(empty($head1)){ //No Subjects are scheduled for the selected records.. ;)
            return '';
        }
        //Table data itself displaying as the headings of the table, with rowspan and colspan.         
		return $data;
	}
	
	/*
     *@method topper_students
     *@param Int $examid examid.
     *@param Int $planid planid.
     *@param Int $batchid batchid.
     *@param Char $resulttype toppers or ATKT or Fail.
     *return $users is students
     **/
	function topper_students($examid, $planid, $batchid,$resulttype){
		global $DB,$USER;
		$users = $this->results_batch_students($examid,$batchid, $planid, '', '', '', '');
		$data =array();
		foreach($users as $user){ // student foreach loop start
            $line = array();
            $udata = $DB->get_record('local_userdata', array('userid'=>$user->id));
			$grandtotal = 0;
			$status = array();
			$fail_atktstatus = array();
			$schedules_subjects = $DB->get_records_select('local_examination_schedule', 'examid = ? GROUP BY cobaltcourseid', array('examid'=>$examid));
            foreach($schedules_subjects as $schedules_subject){//subject for each loop start
				$substatus = array();
				$total = 0;
				$examtypes_marks = $DB->get_records('local_examination_schedule', array('examid'=>$examid, 'cobaltcourseid'=>$schedules_subject->cobaltcourseid));
				foreach($examtypes_marks as $examtypes_mark){ //examtype foreach loop start
					$maxmarks = $DB->get_records('local_exam_maxmarks', array('examid'=>$examid, 'planid'=>$planid, 'examtypeid'=>$examtypes_mark->exammodeid));
					$sub_total = 0;
					foreach($maxmarks as $maxmark){ //marktype foreach loop start
						$markstype = $DB->get_record('local_exammarks_types', array('id'=>$maxmark->markstypeid), '*', MUST_EXIST);
						$mark = $DB->get_record('local_exam_studentmarks', array('examid'=>$examid, 'planid'=>$planid, 'courseid'=>$schedules_subject->cobaltcourseid,
																				'examtypeid'=>$examtypes_mark->exammodeid, 'markstypeid'=>$maxmark->markstypeid, 'studentid'=>$user->id));
						//if($mark->marks)
						//	$line[]=$mark->marks;
						if(!empty($mark->marks)){
							$sub_total+=$mark->marks;
							$total+= $mark->marks;
						}
					} //marktype foreach loop start
					if($sub_total < $examtypes_mark->minmarks){
						$status[] = 'Fail';
						$substatus[] = 'Fail';
					}
				} //examtype foreach loop start
				if(!empty($substatus)){
					$fail_atktstatus [] = 'Fail';
				} 
				$grandtotal+=$total;
            }  //subject for each loop end
			$line[]=$grandtotal;
			if($resulttype == 'toppers'){ //this statement applicable for only student has to pass all subjects 
				if(!empty($status)){
					continue;
				} else{
					$data[$user->id] = $grandtotal;
				}
			} else if($resulttype == 'atkt'){ //this statement applicable for only student fail in one  subjects 
				if(count($fail_atktstatus) == 1) {
					$data[$user->id] = $grandtotal;
				}
			} else if($resulttype == 'fail'){ //this statement applicable for only student fail in more than one subjects 
				if(count($fail_atktstatus) > 1) {
					$data[$user->id] = $grandtotal;
				}
			}
			
        } // student foreach loop end
		arsort($data);
		$users =array();
		foreach($data as $key=>$student_total){
			$sql = "SELECT u.*, ud.serviceid,ea.hallticketnumber
					FROM {user} AS u 
					JOIN {local_examination_apply} AS ea ON  ea.studentid=u.id
					JOIN {local_userdata} as ud ON ud.userid = u.id 
					WHERE FIND_IN_SET(u.id,'$key') GROUP BY u.id";
				
			$users []= $DB->get_record_sql($sql);
		}
		return $users;
	}
	
	/*
     *@method published_exams
     *@param Int $examid examid.
     *return student subject vise marks
     **/
	
	function postexam_subjectmarks($subjectid, $examid, $planid, $batchid, $userid){
		global $DB;
		$dbparams = array('manual_subjectid'=>$subjectid, 'studentid'=>$userid);
		            $dbparams['examid'] = $examid;
		            $dbparams['planid'] = $planid;
		            $dbparams['batchid'] = $batchid;
		            // $dbparams['programid'] = $programid;
		$studentmarks = $DB->get_record('local_manual_studentmarks', $dbparams);
		return $studentmarks; 
	}

	function student_exams_results($examid){
		global $DB,$USER;
		$sql = "SELECT ea.id as eid,u.*, ud.serviceid,ea.hallticketnumber,ea.examid,ea.subjectid
				FROM {user} AS u 
				JOIN {local_examination_apply} AS ea ON  ea.studentid=u.id
				JOIN {local_userdata} as ud ON ud.userid = u.id 
				JOIN {local_exam_studentmarks} as est ON est.studentid = u.id 
				WHERE u.id =$USER->id ";
		// $sql = "SELECT est.*
		// 		##ea.hallticketnumber,ea.examid,ea.subjectid
		// 		FROM {user} AS u 
		// 		##JOIN {local_examination_apply} AS ea ON  ea.studentid=u.id
		// 		JOIN {local_userdata} as ud ON ud.userid = u.id 
		// 		JOIN {local_manual_studentmarks} as est ON est.studentid = u.id 
		// 		##WHERE u.id =$USER->id ";
		if(!empty($examid)){
			$sql .=	" AND ea.examid=$examid ";
		}
		$sql .= " GROUP BY ea.examid ORDER BY ea.examid DESC";
		$results = $DB->get_records_sql($sql);
		//print_object($results);
		$output = "";
		if(!empty($results)){
			foreach ($results as $result){ //foreach start
				$exam =$DB->get_record('local_examcreation',array('id'=>$result->examid));
				$output .= "<div class = 'student_exams_results'>";
				
				if(!empty($exam->publishresults)){ 			//exam results published then only student can see the results
					$output .= "<div class = 'student_information'>";
					$output .='<table><tr><td>'.'Exam Name'.':'.'</td><td><b>'.$exam->name.'</b></td></tr>';
					$username = $DB->get_record('user',array('id'=>$USER->id));
					$userdata = $DB->get_record('local_userdata',array('userid'=>$USER->id));
					$programname = $DB->get_field('local_program','fullname',array('id'=>$exam->programid));
					$batchname = $DB->get_field('cohort','name',array('id'=>$userdata->batchid));
					$output .='<tr><td>'.'Student Name'.':'.'</td><td><b>'.$username->firstname. ' '.$username->lastname.'</b></td></tr>';
					$output .='<tr><td>'.'Program Name'.':'.'</td><td><b>'.$programname.'</b></td></tr>';
					$output .='<tr><td>'.'Batch Name'.':'.'</td><td><b>'.$batchname.'</b></td></tr></table>';
					$output .= "</div>";
					$plan = $DB->get_record_sql("SELECT DISTINCT planid FROM {local_examination_schedule} WHERE examid=$result->examid");
					if(empty($plan->planid)){
										$plan = $DB->get_record_sql("SELECT * FROM {local_examcreation} WHERE id=$result->examid");
					}
					/********** display student marks subject vise *********************/
					$output .=  $this->toppers_result($result->examid,$plan->planid,$userdata->batchid,$result->subjectid,'','','','','',$result->id);
				
				}else{  //exam results not published then only student can see the below message
					$output .= "<div>Exam marks not published by COE</div>";
				}
							$output .= "</div>";
							
			} //foreach end
		}else{
			$output = "<div class='text-center'>No Exams availableeee</div>";
		}
		
		return $output;

	}

	function studentexammarks_dropdown($batchid = false, $planid = false){
    global $DB;
    $output = '';
    $filtersql = "SELECT id, fullname FROM {local_program} lp WHERE lp.visible=1";
    $filterdata = $DB->get_records_sql($filtersql);
    $output .= '<form id="reg_form" method="post" action="">';
    $output .= '<div class="span12"><div class="span6"><div class="span2"><label style="font-weight:bold;">Program <label style="color:red;">*</label></label></div>';
    $output .= '<div class="span4"><select id = "programs" name="program" class = programselect >';

    $output .= '<option value=0 >Select Program</option>';
    foreach($filterdata as $info){
        if($program == $info->id){
            $output .='<option value='.$info->id.' selected>'.$info->fullname.'</option>';
        }else{
            $output .='<option value='.$info->id.'>'.$info->fullname.'</option>';
        }
    }
    $output .='</select></div>';
    $output .= '<label class="error" for="programs" id="program_error">This field is required.</label>';
    $output .= '</div>';
    
    $cohort="SELECT c.id,c.name FROM {cohort} as c
                JOIN {local_batch_map} as map on map.batchid=c.id";
    // if($program){
    //     $cohort.= " WHERE map.programid = $program";
    // }
    $batchcode=$DB->get_records_sql($cohort);
    $output .="<div class='span6'><div class='span2'><label style='font-weight:bold;'>Batch <label style='color:red;'>*</label></label></div>";
    $output .="<div class='span4'><select id='batches' name='batch' class = batchselect>";
    $output .="<option value=0>Select batch</option>";
    foreach($batchcode as $code){
       if($batch == $code->id){
            $output .="<option value=".$code->id." selected>".$code->name."</option>";
        }else{
            $output .="<option value=".$code->id.">".$code->name."</option>";
        }
    }

    $output .="</select></div>";
    $output .= '<label class="error" for="batches" id="batch_error">This field is required.</label>';
    $output .= "</div></div>";
    $output .= '<input name="addfilter" value="Submit" type="submit" id="submitorder">';
    $output .= '</form>';   
    return $output;
	}

	function fetchprogram_batches($program=false){
		global $DB;
		 $batches_sql = 'SELECT c.id, c.name FROM {cohort} c 
					 				   JOIN {local_batch_map} lbm ON c.id = lbm.batchid 
					 				   WHERE lbm.programid = '.$program.'';
		$batch_records = $DB->get_records_sql_menu($batches_sql);
		if(!empty($batch_records)){
			return $batch_records;
		}else{
			return '';
		}
	}

	function batchactiveplans($program=false, $batch=false){
		global $DB;
		 $plans_sql = 'SELECT lcp.id, lcp.fullname 
		 				 FROM {local_activeplan_batch} lab 
					 	 JOIN {local_curriculum_plan} lcp 
					 	   ON lcp.id = lab.planid 
					 	WHERE lab.batchid = '.$batch.' 
					 	  AND lab.programid = '.$program.' ORDER BY lcp.id';
		$activeplans = $DB->get_records_sql_menu($plans_sql);
		
	}

	function student_academic_semestergrades($planid, $userid, $spancount=false, $total_cellcount = false){
		global $DB;
		$loggedin_userrecords_sql = "SELECT lmsm.*, lsm.subject_name, lsm.subject_name, lsm.subject_code, lsm.maxmarks_segregated , lsm.minmarks_segregated   
	                                   FROM {local_manual_studentmarks} lmsm 
	                                   JOIN {local_subjectwise_marks} lsm 
	                                     ON lsm.programid = lmsm.programid
	                                    AND lmsm.manual_subjectid = lsm.id
	                                  WHERE lmsm.studentid = $userid 
	                                   	AND lmsm.coeapproval = 1
	                                    AND lmsm.coordinatorapproval = 1
	                                  AND 1=1";
	    
	    if($planid){
	        $loggedin_userrecords_sql .= " AND lmsm.planid = $planid";
	    }
	    $records = $DB->get_records_sql($loggedin_userrecords_sql);
		if(!empty($records)){
			$data = array();
    		$finalarray = array();
    		$spancountarray = array();
    		$submarkstype = array();
    		foreach ($records as $rec) {
    		// print_object($rec);exit;
    		$maxmarks = json_decode($rec->maxmarks_segregated);
    		$minmarks = json_decode($rec->minmarks_segregated);
    		$actualmarks = (array) json_decode($rec->individualmarks);
    		// print_object(count($maxmarks));
    		// print_object($minmarks);
    		// print_object($actualmarks);
    		$childhead = array();
    		$minmarksarray = array();
    		foreach ($minmarks as $min) {
		        $mintemp = explode(':',$min);
		        $minmarkstype = explode('_',$mintemp[0]);
		        if(isset($childhead[$mintemp[0]])){
		            $childhead[$minmarkstype[0]][$minmarkstype[1]]['min'] = $mintemp[1];
		        }else{
		            $childhead[$minmarkstype[0]][$minmarkstype[1]]['min'] = $mintemp[1];
		        }
		    }

		    foreach($maxmarks as $cat){
		            $temp = explode(':',$cat);
		            $examtype = explode('_',$temp[0]);
		            if(isset($childhead[$examtype[0]])){
		                $childhead[$examtype[0]][$examtype[1]]['max'] = $temp[1];
		            }else{
		                $childhead[$examtype[0]][$examtype[1]]['max'] = $temp[1];
		            }
		    }

		    $subjecttotal_marks = 0;
		    foreach ($actualmarks as $key => $value) {
		    $actualmarkstype = explode('_',$key);
		    if(isset($childhead[$actualmarkstype[0]])){
		            $childhead[$actualmarkstype[0]][$actualmarkstype[1]]['actual'] = $value;
		            // $subjecttotal_marks = $subjecttotal_marks + $value; 
		    }else{
		            $childhead[$actualmarkstype[0]][$actualmarkstype[1]]['actual'] = $value;
		            $subjecttotal_marks = $subjecttotal_marks + $value;
		    }        
		            // $tempmarks += $value;
		            $submarkstype[$rec->subject_name][$actualmarkstype[0]] = $subjecttotal_marks;
		            // unset($subjecttotal_marks);
		    }
		    unset($subjecttotal_marks);
		    
		    $finalarray[$rec->subject_name] = $childhead;
		    $spancountarray[$rec->subject_name] = count($maxmarks);
		    }
		    if($spancount){
		    	return $spancountarray[$spancount];
		    }
		    if($total_cellcount){
		    	return max($spancountarray);
		    }
		    // print_object($finalarray);
			return $finalarray;
		}else{
			return null;
		}
		}
		//added by nitin
	function get_final_subjectcolumns() {
		global $DB,$USER ,$CFG;
	    $sql = "SELECT id, maxmarks_segregated 
	            FROM {local_subjectwise_marks} 
	            WHERE 1";
	    $tempheadrecords = $DB->get_records_sql($sql);
	    $temphead2 = array();
	    $tempdata = array();
	    foreach ($tempheadrecords as $tempheadrecord) {
	    	$temphead3 = $this->dynamic_subjectcolumns($tempheadrecord->id);
	    	$tempdata[] = $temphead3;
			foreach ($temphead3 as $key => $value) {			
				if(count($temphead3)>count($temphead2)) {
					$temphead2[] = ucfirst($key);
				}
			}
	    }
	    $finalhead = $temphead2;
	    $finalheadcount = count( $finalhead );
	    $tempdatas = array(); //$x
 	    foreach($tempdata as $tempdata) {
	    	if(count($tempdata) < $finalheadcount) {
	    		$tempdatacount = count($tempdata);
	    		for($i=0;$i<($finalheadcount-$tempdatacount);$i++) {
	    			$tempdata[] = 'N/A'; 
	    		}
	    	}
	    	$tempdatas[] = $tempdata; 
	    }
	    $data = new stdClass();
	    $data->finalhead = $finalhead; 
	    $data->tempdata = $tempdatas;
	    return $data; 
	}
	//added by nitin
	function dynamic_subjectcolumns($subjectwise_marks_id) {
		global $DB;
		$marks = $DB->get_field_sql("SELECT maxmarks_segregated 
		                             FROM {local_subjectwise_marks} 
		                             where id=$subjectwise_marks_id
		                             order by id asc");
		$temp_result = json_decode($marks);
		$temp_array = array();
		foreach($temp_result as $value){
		    $separate_result = explode(':', $value);
		    $temp_array[$separate_result[0]] = $separate_result[1];
		}
		return $temp_array;
	}
	//added by nitin
	function get_subjectwise_marks() {
		global $DB;
		$qry = "SELECT lsm.id , lcp.id AS semesterid ,lcp.fullname as semester_name , lsm.subject_name , lsm.examtype , 
				lsm.totalmaxmarks_subject , lsm.totalminmarks_subject 
				FROM {local_subjectwise_marks} lsm 
				LEFT JOIN {local_curriculum_plan}  lcp
				ON lsm.semester = lcp.id
				ORDER BY lsm.id ASC ";
		$records = $DB->get_records_sql($qry);
		$subjectwisemarksobject = $this->custom_generate_table($records);
		return $subjectwisemarksobject;	
	}
	//added by nitin
	function custom_generate_table($object) {
		$tableobject = new html_table();
		$tableobject->id = 'displaysubjectmarks';
		$tableobject->attributes['class'] = 'subjectmarks';
		$tableobject->width = '100%';
		$tableobject->head = array();
		$headarray = array();
		foreach ($object as $key => $value) {
			$value = (array) $value;
			$tableobject->data[] = $value;	
			if(empty($headarray)) {
				foreach ($value as $key1 => $value1) {
					$headarray[$key1] = ucwords(str_replace('_',' ',$key1));
				}
			}	
		}
		$tableobject->head = $headarray;		
		return $tableobject;
	}

}

