
function mapping_examid(map_examid,map_planid){
           $.ajax({
                    type: "post",
                     url: M.cfg.wwwroot + "/local/examination/ajax.php?action=plan_courses&exam_id="+map_examid+"&cobalt_planid="+map_planid,            
                     success: function (resp)    {
                         var template = '';
                    $.each( resp.mappingcourse, function(key, value) {
					template +=	'<option value = ' +key + ' >' +value + '</option>';
				});
                        $(".select_mapping_course").html(template);
                    }
               });
           
}
$(document).ready(function () {
        var exam_id = $( "#id_programid" ).val();
        var plan_id = $( "#id_curriculumid" ).val();
        
    $( "#page-local-examination-schedule_exam #mform1 #fitem_id_semesters .fselect" ).append( "<span class='customcourse' style = 'padding: 12px;font-size: small;font-weight: 600' onclick = 'mapping_examid("+exam_id+","+plan_id+")'>Add new subject</span>" );
    $( "#page-local-examination-schedule_exam #mform1 #fitem_id_exammodeid .fselect" ).append( "<span class='exammode' style = 'padding: 12px;font-size: small;font-weight: 600'>Add new examtype</span>" );




//        var ex_type = $('.examtype_popup').dialog({
//        resizable: true,
//        autoOpen: false,
//        width: 500,
//		title : 'Create Exam Type',
//        modal: true
//    });
//        $('.examtype').click(function(){
//        ex_type.dialog('open');        		
//	});
//	$('.submit_examtype').click(function(){
//        
//		var examtype = $('#examtype_name').val();
// 
//
//		if(examtype === null || examtype === ''){
//			$('#id_error_name').css('display', 'initial');
//			return false;
//		} else{
//			$('#id_error_name').css('display', 'none');
//		}
//	if (examtype !== null || examtype !== 'NULL') {
//		$.ajax({
//			type: "post",
//             url: M.cfg.wwwroot + "/local/examination/ajax.php?action=examtype&examtype="+examtype,       
//                success: function (resp)    {
//                $('.examtype_popup').dialog('close');
//				$('#id_examtypeid').append('<option selected="selected" value="' + resp + '">' + examtype + '</option>');    //Appending Option in Select Box and set as selected
//                        //window.location.reload();
//                    },
//			});
//    }
//    });
//for create exammode
    
        var dlg = $('.exammode_popup').dialog({
                resizable: true,
                autoOpen: false,
                width: 500,
                title : 'Create Exam Type',
                modal: true
            });
                $('.exammode').click(function(){
                dlg.dialog('open');        		
            });
            $('.submit_exammode').click(function(){
                var exammode = $('#exam_mode').val();
                var examid = $( ".select.autosubmit.singleselect" ).val();
    
                if(exammode === null || exammode === ''){
                    $('#id_error_name').css('display', 'initial');
                    return false;
                } else{
                    $('#id_error_name').css('display', 'none');
                }
            if (exammode !== null || exammode !== 'NULL') {
                $.ajax({
                    type: "post",
                     url: M.cfg.wwwroot + "/local/examination/ajax.php?action=exammode&exammode="+exammode+"&exam_id="+examid,       
                        success: function (resp)    {
                        $('.exammode_popup').dialog('close');
                        $('#id_exammodeid').append('<option selected="selected" value="' + resp.exammode + '">' + exammode + '</option>');    //Appending Option in Select Box and set as selected
                            },
                    });
            }
            });
            
        //for create exammode
        var customcourse_popup = $('.customcourse_popup').dialog({
                resizable: true,
                autoOpen: false,
                width: 500,
                title : 'Create Course',
                modal: true
            });
                $('.customcourse').click(function(){
                customcourse_popup.dialog('open');        		
            });
            $('.submit_customcourse').click(function(){
                var custocourse = $('#custom_course').val();
                var mapping_course  = $('#mapping_course').val();
                var examid = $( ".select.autosubmit.singleselect" ).val();
                if(custocourse === null || custocourse === ''){
                    $('#id_error_name').css('display', 'initial');
                    return false;
                } else{
                    $('#id_error_name').css('display', 'none');
                }
            if (custocourse !== null || custocourse !== 'NULL') {
                $.ajax({
                    type: "post",
                     url: M.cfg.wwwroot + "/local/examination/ajax.php?action=customcourse&customcourse="+custocourse+"&exam_id="+examid+"&mapping_courseid="+mapping_course,            
                        success: function (resp)    {
                        $('.customcourse_popup').dialog('close');
                        $('#id_semesters').append('<option selected="selected" value="' + resp.custom_course + '">' + custocourse + '</option>');
                        },
                    });
            }
            });
            //added by nitin
            $('#display_subjectwise_marks').DataTable();
});
//added by nitin
$(document).ready(function() {       
    $("#displaysubjectmarks").DataTable({
        searching: true,
        responsive: true,
        "ordering": false,
        "lengthMenu": [[10, 25,50,100, -1], [10,25, 50,100, "All"]],
        "destroy": true
    });
});
//added by nitin
function deletesubject(subjectid) {
    $( function() {
        $( "#dialog-confirm" ).dialog({
            resizable: false,
            height: "auto",
            width: 400,
            modal: true,
            buttons: {
                "Delete item": function() {
                    $.ajax({  
                        cache: false,
                        url: "subjectmarksajax.php?delete="+subjectid, 
                        success: function (data) {   
                            location.reload();
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            alert(textStatus);
                        }
                    });
                },
                Cancel: function() {
                    $( this ).dialog( "close" );
                }
            }
        });
    });
}   
//added by nitin
function editsubject(subjectid) {
    $( "#subjectwisemarkspopup"+subjectid ).dialog({
        title: "Update Marks",
        modal: true,
    });
    $("#page-local-examination-subjectwisemarksview .ui-dialog").addClass('local_examination_subjectwisemarks_popup');
}
//added by nitin
function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
       return false;
    return true;
}
