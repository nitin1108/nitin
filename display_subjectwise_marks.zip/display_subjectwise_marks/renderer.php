<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version details
 *
 * @package    Examination
 * @copyright  2016 rajesh@eayas.in
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once($CFG->dirroot . '/local/examination/lib.php');
class local_examination_renderer extends plugin_renderer_base {

    function examtype_popup($action){
        global $CFG, $PAGE, $OUTPUT;
        switch($action){
        case 'examtype':
        $examtype_popup = '<form autocomplete="off" method="post" accept-charset="utf-8" class="mform" id="examtypecreation_form" onsubmit="try { var myValidator = validate_examtypecreation_form; } catch(e) { return true; } return myValidator(this);">
                                    <div id="fitem_id_name" class="fitem required fitem_ftext ">
                                        <div class="fitemtitle">
                                            <label for="examtype_name">Exam Type Name <span style="color:red">*</span></label>
                                        </div>
                                        <div class="felement ftext">
                                            <span id="id_error_name" class="error" tabindex="0" style="display:none;"> You must supply a value here.</span>
                                            <input name="name" type="text" id="examtype_name">
                                        </div>
                                    </div>   
                                    <fieldset class="hidden">
                                        <div>
                                            <div id="fgroup_id_buttonar" class="fitem fitem_actionbuttons fitem_fgroup">
                                                <div class="felement fgroup">
                                                    <input name="submitbutton" value="Create" type="button" id="id_submitbutton" class="submit_examtype">                                       
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </fieldset>
                                    
                                    </form>';
        return $examtype_popup;
        case 'exammode':
            $exammode_popup = '<form autocomplete="off" method="post" accept-charset="utf-8" class="mform" id="examtypecreation_form" onsubmit="try { var myValidator = validate_examtypecreation_form; } catch(e) { return true; } return myValidator(this);">
                                    <div id="fitem_id_name" class="fitem required fitem_ftext ">
                                        <div class="fitemtitle">
                                            <label for="examode_name">Exam Type Name <span style="color:red">*</span></label>
                                        </div>
                                        <div class="felement ftext">
                                            <span id="id_error_name" class="error" tabindex="0" style="display:none;"> You must supply a value here.</span>
                                            <input name="name" type="text" id="exam_mode">
                                        </div>
                                    </div>   
                                    <fieldset class="hidden">
                                        <div>
                                            <div id="fgroup_id_buttonar" class="fitem fitem_actionbuttons fitem_fgroup">
                                                <div class="felement fgroup">
                                                    <input name="submitbutton" value="Create" type="button" id="id_submitbutton" class="submit_exammode">                                       
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </fieldset>
                                    
                                    </form>';
        return $exammode_popup;
        case 'customcourse':
        $customcourse_popup = '<form autocomplete="off" method="post" accept-charset="utf-8" class="mform" id="customcourse_creation_form" onsubmit="try { var myValidator = validate_customcourse_creation_form; } catch(e) { return true; } return myValidator(this);">
                                    <div id="fitem_id_name" class="fitem required fitem_ftext ">
                                        <div class="fitemtitle">
                                            <label for="customcourse_name">Course Name <span style="color:red">*</span></label>
                                        </div>
                                        <div class="felement ftext">
                                            <span id="id_error_name" class="error" tabindex="0" style="display:none;"> You must supply a value here.</span>
                                            <input name="name" type="text" id="custom_course">
                                        </div>
                                    </div>
                                    <div class="fitemtitle">
                                            <label for="id_mapping_course">Mapping Courses:
                                     </div
                                    <div class="felement fselect">
                                         <select class="select_mapping_course" id ="mapping_course"  multiple="multiple" >
                                    </div>
                                    <fieldset class="hidden">
                                        <div>
                                            <div id="fgroup_id_buttonar" class="fitem fitem_actionbuttons fitem_fgroup">
                                                <div class="felement fgroup">
                                                    <input name="submitbutton" value="Create" type="button" id="id_submitbutton" class="submit_customcourse">                                       
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </fieldset>
                                    </form>';
        return $customcourse_popup; 
     }
    }
    
    public function publish_exam(){
        global $DB, $OUTPUT,$CFG,$PAGE,$USER;
        $sql = "SELECT le.id,le.name
                          FROM {local_examcreation} as le
                          JOIN {local_examination_schedule} as es ON es.examid = le.id";
        $sql.= ' ORDER BY le.id ';
        $examination_details = $DB->get_records_sql($sql,array());
        // print_object($examination_details);exit;
        // $data = array();
        // if(!empty($examination_details)){
        //     foreach($examination_details as $examdata){
        //         $list = array();
        //         print_object($examdata);exit;
        //     }
        // }else{
            // $data = 'No records';
        // }
        $table = new html_table();
        // $table->data = 'No records';
        //$table->head = array( '',
        //                    get_string('examname', 'local_examination'),
        //                    get_string('program', 'local_examination'),
        //                     get_string('semester', 'local_examination'),
        //                    get_string('noofaplied','local_examination'),
        //                     get_string('action','local_examination')  );
        if(has_capability('local/examination:manage_students_verification', context_user::instance($USER->id))){            //for examcoordinator
            $table->head = array( '',
                get_string('examname', 'local_examination'),
                get_string('program', 'local_examination'),
                get_string('eligiblestudents','local_examination'),
                'No of student applied' );
            $table->id ='publishedexams';

        } else{
            $table->head = array( '',
                    get_string('examname', 'local_examination'),
                    get_string('program', 'local_examination'),
                     get_string('batch', 'local_examination'),
                    get_string('eligiblestudents','local_examination'),
                    'Schedule Exam',
                    'SMS Status',
                    'Exam Fees',
                    get_string('action','local_examination'),
                    );
            $table->id ='publish_exams';
        }
        $output = html_writer::table($table);
        return $output;
    }
    public function examschedule_edit($examid){
      global $DB;
      $exams = new stdClass();
      $exam_details = $DB->get_record('local_examcreation', array('id'=>$examid));
      $exams->id = $exam_details->id;
      $exams->programid = $exam_details->programid;
      $exams->planid = $exam_details->planid;
      $exams->batchid = $exam_details->batchid;
      $exams->name = $exam_details->name;
      $exams->visible = $exam_details->visible;
      //$update_exam = $DB->update_record('local_examcreation', array('id'=>$examid));
      //    redirect($returnurl);
          
    }
    
    public function subject_edit($subjectid){
      global $DB;
      $subjects = new stdClass();
      $subject_details = $DB->get_record('local_examination_schedule', array('id'=>$subjectid));
      $subjects->id = $subject_details->id;
      $subjects->programid = $subject_details->examid;
      $subjects->curriculumid = $subject_details->curriculumid;
      $subjects->customcourseid = $subject_details->customcourseid;
      $subjects->semesters = $subject_details->cobaltcourseid;
      $subjects->exammode = $subject_details->exammodeid;
      $subjects->examinationdate = date('d/m/y',$subject_details);
      $subjects->starttime = $subject_details->starttime;
      $subjects->endtime = $subject_details->endtime;
      $subjects->maxmarks = $subject_details->maxmarks;
      $subjects->minmarks = $subject_details->minmarks;  
    }
    
    function examination_tabs($currenttab) {
        global $OUTPUT;
        $systemcontext = context_system::instance();
        $toprow = array();
        switch ($currenttab) {
         case 'examcreate':
                $toprow[] = new tabobject('examcreate', new moodle_url('/local/examination/examcreation.php'), get_string('createexam', 'local_examination'));
                $toprow[] = new tabobject('schedule_Exam', new moodle_url('/local/examination/schedule_exam.php'), get_string('schedule_Exam', 'local_examination'));
                $toprow[] = new tabobject('publishexam', new moodle_url('/local/examination/publishexam.php'), get_string('publishexam', 'local_examination'));
                $toprow[] = new tabobject('studentsapplicationstatus', new moodle_url('/local/examination/applicationstatus.php'), get_string('studentapplicationstatus', 'local_examination'));
        break;
        case 'schedule_Exam':
                $toprow[] = new tabobject('createexam', new moodle_url('/local/examination/examcreation.php'), get_string('createexam', 'local_examination'));
                $toprow[] = new tabobject('schedule_Exam', new moodle_url('/local/examination/schedule_exam.php'), get_string('schedule_Exam', 'local_examination'));
                $toprow[] = new tabobject('publishexam', new moodle_url('/local/examination/publishexam.php'), get_string('publishexam', 'local_examination'));
                $toprow[] = new tabobject('studentsapplicationstatus', new moodle_url('/local/examination/applicationstatus.php'), get_string('studentapplicationstatus', 'local_examination'));
        break;
        case 'publishexam':
                $toprow[] = new tabobject('createexam', new moodle_url('/local/examination/examcreation.php'), get_string('createexam', 'local_examination'));
                $toprow[] = new tabobject('schedule_Exam', new moodle_url('/local/examination/schedule_exam.php'), get_string('schedule_Exam', 'local_examination'));
                $toprow[] = new tabobject('publishexam', new moodle_url('/local/examination/publishexam.php'), get_string('publishexam', 'local_examination'));
                $toprow[] = new tabobject('studentsapplicationstatus', new moodle_url('/local/examination/applicationstatus.php'), get_string('studentapplicationstatus', 'local_examination'));
        break;
        case 'studentsapplicationstatus':
                $toprow[] = new tabobject('createexam', new moodle_url('/local/examination/examcreation.php'), get_string('createexam', 'local_examination'));
                $toprow[] = new tabobject('schedule_Exam', new moodle_url('/local/examination/schedule_exam.php'), get_string('schedule_Exam', 'local_examination'));
                $toprow[] = new tabobject('publishexam', new moodle_url('/local/examination/publishexam.php'), get_string('publishexam', 'local_examination'));
                $toprow[] = new tabobject('studentsapplicationstatus', new moodle_url('/local/examination/applicationstatus.php'), get_string('studentapplicationstatus', 'local_examination'));
        break;
        case 'empty':
                $toprow[] = new tabobject('createexam', new moodle_url('/local/examination/examcreation.php'), get_string('createexam', 'local_examination'));
                $toprow[] = new tabobject('schedule_Exam', new moodle_url('/local/examination/schedule_exam.php'), get_string('schedule_Exam', 'local_examination'));
                $toprow[] = new tabobject('publishexam', new moodle_url('/local/examination/publishexam.php'), get_string('publishexam', 'local_examination'));
                $toprow[] = new tabobject('studentsapplicationstatus', new moodle_url('/local/examination/applicationstatus.php'), get_string('studentapplicationstatus', 'local_examination'));
        break;
        }
       echo $OUTPUT->tabtree($toprow, $currenttab);
    }
    
    function examcoordinator_tabs($currenttab) {
        global $OUTPUT;
        $systemcontext = context_system::instance();
        $toprow = array();
        if ($currenttab) {
            $toprow[] = new tabobject('publishexam', new moodle_url('/local/examination/publishexam.php'), get_string('publishedexam', 'local_examination'));
            $toprow[] = new tabobject('studentverification', new moodle_url('/local/examination/students_verification.php'), get_string('students_verification', 'local_examination'));
            $toprow[] = new tabobject('hallticketgeneration', new moodle_url('/local/examination/hallticket_generation.php'), get_string('hallticket_generation', 'local_examination'));
            $toprow[] = new tabobject('studentreceipt', new moodle_url('/local/examination/examfee_receipt.php'), get_string('studentreceipt', 'local_examination'));
            $toprow[] = new tabobject('manualapplication', new moodle_url('/local/examination/exam_notappliedstudent.php'), get_string('manualapplication', 'local_examination'));
            $toprow[] = new tabobject('enableonlineapplication', new moodle_url('/local/examination/enableapplication.php'), get_string('enableonlineapplication', 'local_examination'));
            $toprow[] = new tabobject('studentsapplicationstatus', new moodle_url('/local/examination/applicationstatus.php'), get_string('studentapplicationstatus', 'local_examination'));
        }
       echo $OUTPUT->tabtree($toprow, $currenttab);
    }
    
    function students_tabs($currenttab) {
        global $OUTPUT,$DB,$USER;
        $systemcontext = context_system::instance();
        $toprow = array();
        if ($currenttab) {
            $toprow[] = new tabobject('applyexam', new moodle_url('/local/examination/examination.php'), get_string('examination_apply','local_examination'));
            $applidexam = $DB->get_record_sql("SELECT * FROM {local_examination_apply} WHERE studentid=$USER->id AND coordinatorstatus =0 ORDER BY id DESC");
            if(!empty($applidexam))
                $toprow[] = new tabobject('uploadphoto', new moodle_url('/local/examination/feepayment.php?examinationid='.$applidexam->id), get_string('uploadphoto', 'local_examination'));
            else
                $toprow[] = new tabobject('uploadphoto', new moodle_url('/local/examination/feepayment.php'), get_string('uploadphoto', 'local_examination'));

            $toprow[] = new tabobject('hallticket', new moodle_url('/local/examination/examhallticket.php'), get_string('halltickets', 'local_examination'));
        }
       echo $OUTPUT->tabtree($toprow, $currenttab);
    }
    
    //coded by sheetal
    function status_tabs($currenttab , $examid) {
        global $OUTPUT;
        $toprow = array();

        $toprow[] = new tabobject('successful', new moodle_url('/local/examination/checkstatus.php?view=1&examid='.$examid.''), get_string('successful', 'local_examination'));
        $toprow[] = new tabobject('unsuccessful', new moodle_url('/local/examination/checkstatus.php?view=2&examid='.$examid.''), get_string('unsuccessful', 'local_examination'));
        echo $OUTPUT->tabtree($toprow, $currenttab);
    }
    //end by sheetal
    
     function student_halltickets($examid) {
        global $USER,$DB,$CFG;
        require_once($CFG->dirroot . '/local/examination/lib.php');
        $examination =New local_examination();
        $halltickets =$examination-> download_hallticket($examid);
        //$halltickets = array_merge($examhalltickets,$onlinepay_halltickets,$ccavenue_halltickets);
        if(!empty($halltickets)){
            $data = array();
            foreach($halltickets as $hallticket){
                $list = array();
                $list[]= $DB->get_field('local_examcreation','name',array('id'=>$hallticket->examid));
                $list[]= $DB->get_field('cohort','name',array('id'=>$hallticket->batchid));
                $user = $DB->get_record('user',array('id'=>$hallticket->studentid));
                $list[] = $user->email;
                $list[] = $hallticket->fee;
                $list[] = $hallticket->hallticketnumber;
                if(!empty($hallticket->previousexam))
                    $list[] = $hallticket->previousexam;
                else
                    $list[] ='----';
                
                if(!empty($hallticket->comment))
                    $list[] = $hallticket->comment;
                else
                    $list[] ='----';
                $url = new moodle_url('/local/examination/hallticket_pdf.php', array('studentid'=>$hallticket->studentid,'examid'=>$hallticket->examid));
                $download_hallticket = $DB->get_record('local_hallticket_download',array('studentid'=>$hallticket->studentid,'examid'=>$hallticket->examid,'batchid'=>$hallticket->batchid));
                
                //if(empty($download_hallticket))
                    $list[] = html_writer::tag('a', get_string('download', 'local_examination'), array('href' => $url));
                //else
                //  $list[] = "Downloaded";
        
                //$list[] = html_writer::tag('a','download',array('studenid'=>$hallticket->studentid));
                $data[] = $list;
            }
            $batchname = get_string('batchname', 'local_examination');
            $examname = get_string('examname', 'local_examination');
            $email = get_string('email', 'local_examination');
            $fee = get_string('fee', 'local_examination');
            $hallticketnumber = get_string('hallticketnumber', 'local_examination');
            $previousexam = get_string('previousexam', 'local_examination');
            $comment = get_string('comment', 'local_examination');
            $download = get_string('download', 'local_examination');
            
            $table = new html_table();
            $table->head = array($examname,$batchname,$email,$fee,$hallticketnumber,$previousexam,$comment,$download);
            $table->align = array('left', 'left', 'left', 'left','center', 'left', 'left', 'left');
            $table->data = $data;
            $output = html_writer::table($table);
        } else{
            $output =  html_writer::tag('h4', get_string('nohalltickets', 'local_examination'), array());;
        }
        return $output;
    }
    function scheduledexam(){
        
        global $USER,$DB,$CFG,$OUTPUT;
        require_once($CFG->dirroot . '/local/timetable/stulib.php');
        require_once($CFG->dirroot . '/local/examination/lib.php');
        $examination =New local_examination();
        $activesem = local_timetable_activesemester_student_detail();
        $userdata = $DB->get_record('local_userdata', array('userid'=>$USER->id), '*', MUST_EXIST);
        //if(!empty($activesem->semesterid) && !empty($activesem->classes)){
            $sql = "SELECT ec.id,ec.* FROM {local_examcreation} AS ec
                      JOIN {local_examination_students} AS es ON ec.id =es.examid
                      JOIN {local_examination_schedule} AS sc ON ec.id =sc.examid
                      WHERE ec.programid = $activesem->programid
                      AND FIND_IN_SET($userdata->batchid,es.batchid)
                      AND sc.publish =1
                      AND es.planid = $activesem->planid 
                      AND (FIND_IN_SET($USER->id,es.studentid) OR es.studentid IS null OR es.studentid ='' OR es.studentid =0)
                      ORDER BY ec.id DESC";
            $newexams = $DB->get_records_sql($sql,array());
            
            $sql = "SELECT DISTINCT ec.id,ec.* FROM {local_examcreation} AS ec
                      JOIN {local_examination_schedule} AS es ON ec.id =es.examid
                      WHERE ec.programid = $activesem->programid
                      ##AND ec.semesterid = $activesem->semesterid
                      ##AND es.planid=$activesem->planid 
                      AND FIND_IN_SET($userdata->batchid,ec.batchid)
                      AND ec.visible =1 AND es.publish =1
                      AND (FIND_IN_SET($USER->id,ec.studentid) OR ec.studentid IS null OR ec.studentid ='' OR ec.studentid =0)
                      ORDER BY ec.id DESC";
            
           
            $oldexams = $DB->get_records_sql($sql,array());
            $exams =array_merge($newexams,$oldexams);
            $output ="";
            if(!empty($exams)){
                foreach($exams as $exam){
                    $data = array();
                    $subsql = "SELECT * FROM {local_examination_schedule} WHERE examid = $exam->id
                    and publish =1 ORDER BY examinationdate ASC";
                    $subjects = $DB->get_records_sql($subsql,array());
                    $output .="<div class='scheduledexam'>";
                    $output .=html_writer::tag('h3', $exam->name, array('style' => 'text-align:center;'));
                    foreach($subjects as $subject){
                        $list = array();
                        $list[] = $DB->get_field('local_cobaltcourses','fullname',array('id'=>$subject->cobaltcourseid));
                        $list[] =$DB->get_field('local_lecturetype','lecturetype',array('id'=>$subject->exammodeid));
                        if(!empty($subject->examinationdate)){
                            $list[] =Date('d M Y',$subject->examinationdate);
                        } else{
                            $list[] = "----";
                        }
                        //$start_hour = substr($subject->starttime,0, 5);
                        if(empty($subject->starttime) || $subject->starttime == 00){
                             $starttime = "----";

                        } else{
                            $starttime = date('g:i a', strtotime($subject->starttime));

                        }
                        $list[] =$starttime;
                        //$end_hour = substr($subject->endtime,0, 5);
                        if(empty($subject->endtime) || $subject->endtime == 00){
                            $endtime = "----";
                        } else{
                            $endtime = date('g:i a', strtotime($subject->endtime));
                        }
                        $list[] =$endtime;
                        $list[] =$subject->maxmarks;
                        $list[] =$subject->minmarks;                  
                        $data[] = $list;
                    }
                    $examtype = get_string('examtype', 'local_examination');
                    $subject = get_string('subject', 'local_examination');
                    $examdate = get_string('examdate', 'local_examination');
                    $starttime= get_string('starttime', 'local_examination');
                    $endtime = get_string('endtime', 'local_examination');
                    $maxmarks = get_string('maxmarks', 'local_examination');
                    $minmarks = get_string('minmarks', 'local_examination');
                    
                    $table = new html_table();
                    $table->head = array($subject,$examtype,$examdate,$starttime,$endtime,$maxmarks,$minmarks);
                    $table->align = array('left', 'left', 'center', 'center','center', 'center', 'center');
                    $table->data = $data;
                    $output .= html_writer::table($table);
                    $applyexam = $DB->get_record('local_examination_apply',array('examid' =>$exam->id,'studentid'=>$USER->id,'status'=>1));
                    
                    $output .="<div class='applyexam_button'>";
                    $halltickets = $examination->download_hallticket($exam->id);
                    if(!empty($halltickets)){
                        $output .="<div class = 'tab_information' >".html_writer::tag('p', get_string('downloadexam_hallticket', 'local_examination'),array())."</div>";
                       // $output .=html_writer::tag('a', get_string('applyforexam', 'local_examination'),array('href' => $CFG->wwwroot . '/local/examination/examination.php?examid='.$exam->id,'style'=>'text-align:center','class'=>'videotutorial'));
                       // $output .='&nbsp&nbsp&nbsp&nbsp'.html_writer::tag('a', get_string('payfee', 'local_examination'),array('href' => $CFG->wwwroot . '/local/examination/feepayment.php?examinationid='.$applyexam->id,'style'=>'text-align:center','class'=>'videotutorial'));
                        $output .= '&nbsp&nbsp&nbsp&nbsp'.html_writer::tag('a', get_string('hallticket_download', 'local_examination'),array('href' => $CFG->wwwroot . '/local/examination/examhallticket.php?examid='.$exam->id,'style'=>'text-align:center','class'=>'videotutorial'));
                    } else if(!empty($applyexam)){
                        if(empty($applyexam->fee))
                            $output .="<div class = 'tab_information' >".html_writer::tag('p', get_string('coordinatorverification', 'local_examination'),array())."</div>";
                        else{
                            $feesql = "SELECT * FROM {local_examination_apply} AS ea
                                        WHERE ea.studentid = $USER->id AND ea.status =1 AND ea.coordinatorstatus = 1 AND ea.fee > 0  AND ea.examid =$exam->id ";
                            $examfee = $DB->get_record_sql($feesql,array());
                            if(!empty($examfee)){
                                $receipt_payfee  = $DB->get_record_sql("SELECT * FROM {local_examfee_receipt} WHERE examid =$exam->id AND studentid = $USER->id ORDER BY id DESC ");
                                if(empty($receipt_payfee->status) && !empty($receipt_payfee->examid)){
                                    $output .="<div class = 'tab_information' >".html_writer::tag('p', get_string('receiptexamfee_text', 'local_examination'),array())."</div>";
                                } else{
                                    if($receipt_payfee->status ==2)
                                        $output .="<div class = 'tab_information' >".html_writer::tag('p', get_string('receiptexamfee_reject', 'local_examination'),array())."</div>";
                                    else
                                        $output .="<div class = 'tab_information' >".html_writer::tag('p', get_string('payexamfee_text', 'local_examination'),array())."</div>";

                                    $output .=html_writer::tag('a', get_string('payfee', 'local_examination'),array('href' => $CFG->wwwroot . '/local/examination/feepayment.php?examinationid='.$applyexam->id,'style'=>'text-align:center','class'=>'videotutorial'));

                                }
                            } else{
                                $output .="<div class = 'tab_information' >".html_writer::tag('p', get_string('coordinatorverification', 'local_examination'),array())."</div>";
                            }
                        }
                    } else{
                        //$subsql = "SELECT * FROM {local_examination_schedule} WHERE examid = $exam->id and publish =1 ORDER BY examinationdate ASC";
                        //$subjects = $DB->get_record_sql($subsql,array());
                        //if($subjects->examinationdate > time()){
                            $output .="<div class = 'tab_information' >".html_writer::tag('p', get_string('applyexam', 'local_examination',$exam),array())."</div>";
                            $output .=html_writer::tag('a', get_string('applyforexam', 'local_examination'),array('href' => $CFG->wwwroot . '/local/examination/examination.php?examid='.$exam->id,'style'=>'text-align:center','class'=>'videotutorial'));
                        //} else{
                        //     $output .='<div class= "tab_information">'.html_writer::tag('p', get_string('applydate_completed', 'local_examination'),array('style'=>'text-align:center;color:#f00;'))."</div>";
                        //}
                    }
                    $output .="</div>";
                    $output .="</div>";//end div scheduledexam class
                }
            } else{
                $output =  html_writer::tag('h4', get_string('examnotscheduled', 'local_examination'), array());;
            }
        //} else{
        //    $output =  html_writer::tag('h4', get_string('currentsem', 'local_examination'), array());;
        //}
        return $output;
    }
    
    function students_examfeereceipt(){
        global $USER,$DB,$CFG,$OUTPUT,$PAGE;
        require_once($CFG->dirroot . '/local/examination/lib.php');
        $examination =New local_examination();

        $sql = "SELECT re.*,c.name,u.firstname,u.lastname,ec.name as examname FROM {local_examfee_receipt} AS re 
                JOIN {cohort} AS c ON re.batchid = c.id
                JOIN {user} AS u ON u.id = re.studentid
                JOIN {local_examcreation} AS ec ON ec.id = re.examid";
        $studentreceipts = $DB->get_records_sql($sql,array());
        if(!empty($studentreceipts)){
            $data =array();
            foreach($studentreceipts as $receipt){
                $list = array();
                $list[] =$receipt->firstname.''.$receipt->lastname;
                $list[] =$receipt->examname;
                $list[] =$receipt->name;
                $list[] =$receipt->chequenumber;
                if(!empty($receipt->scancopy)){
                    $temp_file_url =$examination->get_studentreceipt_file($receipt->studentid,$receipt->scancopy);
                    $list[] ='<a href="'.$temp_file_url.'">Examfee Scancopy</a>';
                } else{
                    $list[] ="----";
                }
                if($receipt->status == 1)
                    $list[] ="<span style ='color:#008000;'>Approved</span>";
                else if($receipt->status == 2)
                    $list[] ='<span style ="color:#f00;">Rejected:</span><br><b>Reason</b>: '.$receipt->comment;
                else{
                    $approve_button =html_writer::tag('a',html_writer::empty_tag('img', array('src' => $CFG->wwwroot . '/pix/i/grade_correct.png', 'width' => '15px', 'height' => '15px','class'=>'comment_img'.$receipt->id)) , array('href' => $CFG->wwwroot . '/local/examination/examfee_receipt.php?receiptid='.$receipt->id.'&studentid='.$receipt->studentid,'class'=>'comment_approve'. $receipt->id.' popup_confirm_'.$receipt->id));
                    $PAGE->requires->event_handler('.popup_confirm_'.$receipt->id, 'click', 'M.util.show_confirm_dialog', array('message' => get_string('approveconfirm', 'local_examination')));
                    $reject_button = html_writer::empty_tag('img', array('src' => $CFG->wwwroot . '/pix/i/invalid.png', 'width' => '15px', 'height' => '15px','class'=>'comment_img'.$receipt->id));
                    $toggle ='<span class="comment_reject'.$receipt->id.'"></span>'.$approve_button .' '. html_writer::tag('a',$reject_button , array('onclick'=>'reviewComments('.$receipt->id.')'));
                    $toggle.= "<div class='commenting$receipt->id' id='dialog1' style='display:none;'>";
                    $toggle.='<form action="' . $CFG->wwwroot . '/local/examination/examfee_receipt.php" method ="POST">';
                    $toggle.='<span class="error" style="display:none;color:#f00">You must supply a value here.</span><textarea rows="2" id="comment_area' . $receipt->id . '" cols="15" name="comment" >Receipt number not available</textarea>';
                    $toggle.='<br /><input type="submit" name="submit" value = "Reject">
                                <input type="hidden" name="studentid" value ="'.$receipt->studentid.'">
                                <input type="hidden" name="status" value ="2">
                                <input type="hidden" name="receiptid" value = "'.$receipt->id.'">';
                    $toggle.='</form>';
                    $toggle .='</div>';
                
                    $list[] = new html_table_cell($toggle);
                }
                $data[] = $list;
            }
            $studentname= get_string('student', 'local_examination');
            $exam = get_string('examname', 'local_examination');
            $batch= get_string('batch', 'local_examination');
            $chequenumber = get_string('scancopy', 'local_examination');
            $receiptnumber = get_string('receiptnumber', 'local_examination');
            $action = get_string('action', 'local_examination');
            
            $table = new html_table();
            $table->head = array($studentname,$exam,$batch,$receiptnumber,$chequenumber,$action);
            $table->align = array('left', 'left', 'left', 'left','center');
            $table->data = $data;
            $table->id = "students_receipts";
            $output  = html_writer::table($table);
        } else{
            $output =  html_writer::tag('h4', get_string('examfeereceipts', 'local_examination'), array());;
        }
        return $output;
    }
    function ccavenue_scheduledexamfee($examid){
        
        global $USER,$DB,$CFG,$OUTPUT;
        require_once($CFG->dirroot . '/local/examination/lib.php');
        $examination =New local_examination();
        $data = array();
        $sql = "SELECT * FROM {local_examcreation} WHERE id =$examid";
        $exam = $DB->get_record_sql($sql,array());
        $studentexam = $DB->get_record_sql("SELECT * FROM {local_examination_apply} WHERE examid = $examid AND studentid = $USER->id");
        $subject_count = explode(',',$studentexam->subjectid);
        $subjects = $DB->get_records_sql("SELECT es.* FROM {local_examination_schedule} AS es 
                                            WHERE FIND_IN_SET(es.cobaltcourseid,'$studentexam->subjectid') AND es.examid =$examid AND es.publish = 1 ORDER BY examinationdate ASC");
                        
        $output = "";
        if(!empty($subjects)){
            $output .= "<div class = 'student_information'>";
            $output .='<table><tr><td>'.'Exam Name'.':'.'</td><td><b>'.$exam->name.'</b></td></tr>';
            $username = $DB->get_record('user',array('id'=>$USER->id));
            $userdata = $DB->get_record('local_userdata',array('userid'=>$USER->id));
            $programname = $DB->get_field('local_program','fullname',array('id'=>$exam->programid));
            $batchname = $DB->get_field('cohort','name',array('id'=>$userdata->batchid));
            $output .='<tr><td>'.'Student Name'.':'.'</td><td><b>'.$username->firstname. ' '.$username->lastname.'</b></td></tr>';
            $output .='<tr><td>'.'Program Name'.':'.'</td><td><b>'.$programname.'</b></td></tr>';
            $output .='<tr><td>'.'Batch Name'.':'.'</td><td><b>'.$batchname.'</b></td></tr></table>';
            $output .= "</div>";

            foreach($subjects as $subject){
               $list = array();
               if(!empty($subject->cobaltcourseid))
                    $list[] = $DB->get_field('local_cobaltcourses','fullname',array('id'=>$subject->cobaltcourseid));
               else
                    $list[] = $DB->get_field('local_cobaltcourses','fullname',array('id'=>$subject->customcourse));
                
                $list[] =$DB->get_field('local_lecturetype','lecturetype',array('id'=>$subject->exammodeid));
                if(!empty($subject->examinationdate)){
                    $list[] =Date('d M Y',$subject->examinationdate);
                } else{
                    $list[] ="----";
                }
                //$list[] =$subject->starttime.' to '.$subject->endtime;
                if((empty($subject->starttime) || $subject->starttime == 00) && (empty($subject->endtime) || $subject->endtime == 00)){
                     $list[] = "----";
                } else{
                    $list[] =date('g:i a', strtotime($subject->starttime)).' to '.date('g:i a', strtotime($subject->endtime));
                }
                $data[] = $list;
            }
            $examtype = get_string('examtype', 'local_examination');
            $subject = get_string('subject', 'local_examination');
            $examdate = get_string('examdate', 'local_examination');
            $starttime= get_string('starttime', 'local_examination');
            $endtime = get_string('endtime', 'local_examination');
            $time_heads = get_string('time_head', 'local_examination');
            //$minmarks = get_string('minmarks', 'local_examination');
            
            $table = new html_table();
            $table->head = array($subject,$examtype,$examdate,$time_heads/*,$starttime.' & '.$endtime*/);
            $table->align = array('center', 'left', 'left', 'center');
            $table->size = array('35%', '15%', '20%', '30%');
            $table->data = $data;
            $table->id = 'exam_conformation';
            $output .= html_writer::table($table);
            //$amountsql = "SELECT fs.* FROM {local_feeschedule} AS fs 
            //                           JOIN {local_feeheads} AS fh ON fh.id = fs.feeheadid
            //                          WHERE fs.programid=$exam->programid 
            //                            AND FIND_IN_SET($userdata->batchid,fs.batch)
            //                            AND UCASE(fh.name) ='EXAM FEE' ";
            //$student_batch = $DB->get_record_sql($amountsql);
            $student_batch =$examination->feeschedule_details($exam->programid,$userdata->batchid,$USER->id,$examid);
            if(!empty($student_batch->amount) && empty($student_batch->unitprice))
                $totalexamfee = $student_batch->amount;
            else
                $totalexamfee = ($student_batch->amount) * count($subject_count);
                
                setlocale(LC_MONETARY, 'en_IN');

            $output .= '<div style= "margin: 2% 0% 2% 35%;font-size: 16px;margin-top:10px;">'.'Total Exam fee : '.'<b>Rs.'.money_format('%!.0i',$totalexamfee).'.00/-</b></div>';
            $output .= '<div class="ccavenue_terms"><li>Terms &amp; Conditions </li>
                               <li>Privacy Policy </li></div>';
            $output .= '<span class="pull-left span12 text-center desktop-first-column">Please Click Proceed button to proceed for payment transaction.</span>';
        } else{
            $output =  html_writer::tag('h4', get_string('examnotscheduled', 'local_examination'), array());;
        }
        return $output;
    }
    function examination_accordian($mform1,$mform2, $position){
        $response ='
        <div id="examination_accordion">
                        <h3>Download Sample Sheet</h3>
                        <div>
                             <p>'.$mform1->render().'</p>
                        </div>
                        <h3>Bulk Schedule</h3>
                        <div>
                            <p>'.$mform2->render().'</p>
                        </div>
                        <h3>Section 3</h3>
                        <div>
                            <p> </p>
                        <ul>
                            <li>List item one</li>
                            <li>List item two</li>
                            <li>List item three</li>
                        </ul>
                        </div>
                            <h3>Section 4</h3>
                        <div>
                            <p>     </p>
                            <p>        </p>
                        </div>
                    </div> ';
        return $response;
    }
    
    
    /*
     * Added by Vinod   
     */
    function addmarksform_display($examid, $planid, $batchid, $subjectsin, $page, $perpage, $studentname, $serviceid, $email, $errors){
        global $DB, $OUTPUT, $CFG;
        $examset = new local_examination();
        $users = $examset->batch_students($batchid, $planid, false, $page * $perpage, $perpage, $studentname, $serviceid, $email,$examid);
        
        $exam = $DB->get_record('local_examcreation', array('id'=>$examid), '*', MUST_EXIST);
        
        
        $heads = array(/*get_string('sno', 'local_examination'),*/
                       get_string('hallticket', 'local_examination'),
                       get_string('studentname', 'local_examination'),
                       get_string('email', 'local_examination'));
        
        $data = array();
        $static = array();
        foreach($heads as $head){
            $cell = new html_table_cell();
            $cell->text = $head;
            $cell->rowspan = 5;
            $cell->attributes = array('class'=>'addmarkshead addmarkshead1');
            $static[] = $cell;
        }
        $data[] = $static;
        
        
        
        $where = '';
        if($subjectsin != ''){
            $where = ' AND cobaltcourseid IN ('.$subjectsin.')';
        }
        //Setting up header
        $schedules = $DB->get_records_select('local_examination_schedule', 'examid = ? '.$where.' GROUP BY cobaltcourseid', array('examid'=>$examid));
    
        
        
        /*$data = array();*/
        $head1 = array();$head2 = array();$head3 = array();$head4 = array();
        foreach($schedules as $schedule){
            
            $cobaltcourse = $DB->get_record('local_cobaltcourses', array('id'=>$schedule->cobaltcourseid), '*', MUST_EXIST);
            //Heading1 to display the subjects scheduled
            $cell1 = new html_table_cell();
            $cell1->text = $cobaltcourse->fullname;
            $cell1->attributes = array('class'=>'addmarkshead addmarkshead1', 'cobaltcourseid'=>$cobaltcourse->id);
            
            $coursespan = 1;
            
            $subjecttotal_marks = 0;
            $examtypes = $DB->get_records('local_examination_schedule', array('examid'=>$examid, 'cobaltcourseid'=>$schedule->cobaltcourseid));
            foreach($examtypes as $examtype){
                $extype = $DB->get_record('local_lecturetype', array('id'=>$examtype->exammodeid), '*', MUST_EXIST);
                //Heading2, Type of exams either theory or practical
                $cell2 = new html_table_cell();
                $cell2->text = $extype->lecturetype;
                $cell2->attributes = array('class'=>'addmarkshead addmarkshead2');
                
                $forcolspan = 1;
                $maxmarks = $DB->get_records('local_exam_maxmarks', array('examid'=>$examid, 'planid'=>$planid, 'examtypeid'=>$examtype->exammodeid));
                
                foreach($maxmarks as $maxmark){
                    $markstype = $DB->get_record('local_exammarks_types', array('id'=>$maxmark->markstypeid), '*', MUST_EXIST);
                    
                    //This is the marks heading, One exam type is a sum of multiple marks
                    $cell3 = new html_table_cell();
                    $cell3->text = $markstype->shortname;
                    $cell3->attributes = array('class'=>'addmarkshead addmarkshead3', 'cobaltcourseid'=>$cobaltcourse->id, 'examtypeid'=>$extype->id, 'markstypeid'=>$markstype->id, 'maxmarks'=>$maxmark->maxmarks);
                    
                    $cell4 = new html_table_cell();
                    $cell4->text = $maxmark->maxmarks;
                    $cell4->attributes = array('class'=>'addmarkshead addmarkshead4');
                    
                    $subjecttotal_marks += $maxmark->maxmarks;

                    $head3[] = $cell3;
                    $head4[] = $cell4;
                    
                    $forcolspan++;
                    $coursespan++;
                }
                $cell2->colspan = $forcolspan > 1 ? ($forcolspan -1) : $forcolspan;
                
                $head2[] = $cell2;
            }
            //$coursespan += sizeof($head3);
           
            $celltotal1 = new html_table_cell();
            $celltotal1->text = 'Total';
            $celltotal1->rowspan = 2;
            $celltotal1->attributes = array('class'=>'addmarkstotal addmarkstotal1');
            $head2[] = $celltotal1;
            
            $celltotal2 = new html_table_cell();
            $celltotal2->text = $subjecttotal_marks;
            $celltotal2->colspan = 1;
            $celltotal2->attributes = array('class'=>'addmarkstotal addmarkstotal2');
            $head4[] = $celltotal2;
            
            //$cell1->colspan = $coursespan > 1 ? ($coursespan -1) : $coursespan;
            $cell1->colspan = $coursespan;
            $head1[] = $cell1;
        }
        $data[] = $head1;
        $data[] = $head2;
        $data[] = $head3;
        $data[] = $head4;
        
        if(empty($head1)){ //No Subjects are scheduled for the selected records.. ;)
            return '';
        }
        //Table data itself displaying as the headings of the table, with rowspan and colspan.         
        
        
        $output = '';
        $output .= '<form action="" method="post" >';
        $table = new html_table();
        $i = 1;
        foreach($users as $user){
            $line = array();
            //$line[] = $i;
            //We need hallticket here, change the
            $udata = $DB->get_record('local_userdata', array('userid'=>$user->id));
            $line[] = $user->hallticketnumber;
            
            $line[] = html_writer::tag('a', fullname($user), array('href'=>$CFG->wwwroot.'/local/users/profile.php?id='.$user->id, 'target'=>'_blank'));
            $line[] = html_writer::tag('a', $user->email, array('href'=>'mailto:'.$user->email));
            foreach($head1 as $course){
                $courseids = (object) $course->attributes;
                $examtypes = $DB->get_records('local_examination_schedule', array('examid'=>$examid,  'cobaltcourseid'=>$courseids->cobaltcourseid));
                $subjecttotal = 0;
                $j = 0;
                foreach($examtypes as $examtype){
                    $maxmarks = $DB->get_records('local_exam_maxmarks', array('examid'=>$examid, 'planid'=>$planid, 'examtypeid'=>$examtype->exammodeid));
                    foreach($maxmarks as $maxmark){
                        $mark = $DB->get_record('local_exam_studentmarks', array('examid'=>$examid, 'planid'=>$planid, 'courseid'=>$courseids->cobaltcourseid,
                                                                                 'examtypeid'=>$examtype->exammodeid, 'markstypeid'=>$maxmark->markstypeid, 'studentid'=>$user->id));
                        $value = '';
                        if($mark){
                            $value = $mark->marks;
                            $subjecttotal+= $mark->marks;
                        }
                        //$classname = 'subsubjectmarks_'.$courseids->cobaltcourseid.'_'.$user->id;
                        $classname = 'subsubjectmarks_'.$courseids->cobaltcourseid.'_'.$user->id;
                        $idname = 'subject_marks_'.$courseids->cobaltcourseid.'_'.$user->id.'_'.$j;
                        $inputname = 'marks_'.$courseids->cobaltcourseid.'_'.$examtype->exammodeid.'_'.$maxmark->markstypeid.'_'.$maxmark->maxmarks.'_'.$user->id;
                        //onkeyup="subjectmarksFunction('.$courseids->cobaltcourseid.','.$examtype->exammodeid.','.$maxmark->markstypeid.','.$maxmark->maxmarks.','.$user->id.')"
                        $line[] = '<input type="text" name="'.$inputname.'" value="'.$value.'" class = "'.$classname.'" id= "'.$idname.'"size="5px" data-id_'.$j.' = "'.$maxmark->maxmarks.'" onfocusout = "validatemarks('.$maxmark->maxmarks.', \''.$inputname.'\',\''.$classname.'\','.$courseids->cobaltcourseid.','.$user->id.')"/>'; //class='$errors[$inputname]->class'
                        $j++;
                    }
                }
                $input_subjectname = 'subjecttotal_'.$courseids->cobaltcourseid.'_'.$user->id;
                $classname = 'subjecttotalmarks_'.$courseids->cobaltcourseid.'_'.$user->id;
                $line[] = '<input type="text" name="'.$input_subjectname.'" value="'.$subjecttotal.'" class="'.$classname.'" data-id ="'.$user->id.'" data-c-id ="'.$courseids->cobaltcourseid.'" size="5px" readonly/>'; //class='$errors[$inputname]->class'
            }
            $data[] = $line;
            $i++;
        }
        $table->data = $data;
        $output .= html_writer::table($table);
        $output .= '<div style="text-align: center;">';
        $output .= '<input type="hidden" name="submitmarks" value="1" />';
        $output .= '<input type="hidden" name="exam" value="'.$examid.'" />';
        $output .= '<input type="hidden" name="planid" value="'.$planid.'" />';
        $output .= '<input type="hidden" name="batch" value="'.$batchid.'" />';
        $output .= '<input type="submit" name="submit" value="Save changes" />';
        $output .= '<input type="submit" name="submitandgonext" value="Save changes and go to next page" />';
        $output .= '</div>';
        $output .= '</form>';
        
        return $output;
    }
    
    function addmarks_searchoptions($url, $serviceid, $studentname, $email, $urlparams){
        global $DB, $CFG;
        $urlparams = (object) $urlparams;
        $search = '<div class="grades_search_field">';
        $search .= '<form action="'.$url.'" method="get" >';
        $search .= '<b>Name: </b><input type="text" name="studentname" value="'.$studentname.'" />&nbsp;&nbsp;&nbsp;';
        $search .= '<b>Email: </b><input type="text" name="email" value="'.$email.'" />&nbsp;&nbsp;&nbsp;';
        $search .= '<b>Roll Number:</b> <input type="text" name="serviceid" value="'.$serviceid.'" />';
        $search .= '<input type="hidden" name="exam" value="'.$urlparams->exam.'" />';
        $search .= '<input type="hidden" name="planid" value="'.$urlparams->planid.'" />';
        $search .= '<input type="hidden" name="batch" value="'.$urlparams->batch.'" />';
        $search .= '<input type="hidden" name="subjectsin" value="'.$urlparams->subjectsin.'" />';
        $search .= '&nbsp;<input type="submit" name="search" value="Search" />';
        $search .= '&nbsp;<input type="submit" name="resetbutton" value="Reset" />';
        $search .= '</form>';
        $search .= '</div>';
        return $search;
    }
    
     function publish_examresults_form($url = false, $urlparams = false){
        global $DB, $CFG;
        $urlparams = (object) $urlparams;
        $publish = '<div class="grades_search_field">';
        $publishexam_results = $DB->get_record('local_examcreation',array('id'=>$urlparams->exam));
        if(!empty($publishexam_results->publishresults)){
            $publish .= '<form action="'.$url.'" method="get" onsubmit="return sendsmsValidate()">';
            //$publish .= '<b>Publish Exam: </b><input type="checkbox" name="publishexam" class ="publishexam_checkbox" checked="checked" disabled>&nbsp;&nbsp;&nbsp;';
            $publish .= '<b class="application_done">Exam results published</b>&nbsp;&nbsp;&nbsp;';
        } else{
            $publish .= '<form action="'.$url.'" method="get" onsubmit="return publishValidate()">';
            $publish .= '<b>Publish Exam: </b><input type="checkbox" name="publishexam" class ="publishexam_checkbox">&nbsp;&nbsp;&nbsp;';
        }
        $publish .= '<b>Send SMS: </b><input type="checkbox" name="sendsms" class ="sendsmsstatus_checkbox">&nbsp;&nbsp;&nbsp;';
       // $search .= '<b>Roll Number:</b> <input type="text" name="serviceid" value="'.$serviceid.'" />';
        $publish .= '<input type="hidden" name="exam" value="'.$urlparams->exam.'" />';
        $publish .= '<input type="hidden" name="planid" value="'.$urlparams->planid.'" />';
        $publish .= '<input type="hidden" name="batch" value="'.$urlparams->batch.'" />';
        $publish .= '<input type="hidden" name="subjectsin" value="'.$urlparams->subjectsin.'" />';
        if(!empty($publishexam_results->publishresults)){
            $publish .= '&nbsp;<input type="submit" name="Publish" value="Send SMS" id ="examresults_submit"/>';
        } else{
            $publish .= '&nbsp;<input type="submit" name="Publish" value="Publish" id ="examresults_submit"/>';
        }
        $publish .= '</form>';
        $publish .= '</div>';
        return $publish;
    }
    /*
     * Code ends by Vinod
     **/
    
    /*
     *@method student_appliedsubjects
     *@param Int $examid examid.
     *@param Int $planid planid.
     *@param Char $batchid batchid.
     *return student application status
     **/
    
    function publish_postexamresults_form($url = false, $urlparams = false){
        global $DB, $CFG;
        $urlparams = (object) $urlparams;
        $publish = '<div class="grades_search_field">';
        $params = array();
        $params['examid'] = $urlparams->exam;
        $params['planid'] = $urlparams->planid;
        $params['batchid'] = $urlparams->batch;
        $params['programid'] = $urlparams->program;
        // $params['coeapproval'] = 0;
        $publishexam_results = $DB->get_record('local_manual_studentmarks', $params);
        // print_object($publishexam_results);
        $publish .= '<input type="hidden" name="exam" id="exam" value="'.$urlparams->exam.'" />';
        $publish .= '<input type="hidden" name="planid" id="planid" value="'.$urlparams->planid.'" />';
        $publish .= '<input type="hidden" name="batch" id="batch" value="'.$urlparams->batch.'" />';
        $publish .= '<input type="hidden" name="program" id="program" value="'.$urlparams->program.'" />';
        // print_object($publishexam_results);
        if($publishexam_results->coeapproval == 0){
            // if(!empty)
            $publish .= "<div id='publish_exam'><label>Publish the exam results</label>
                            <button onClick = postexampublishValidate();>Publish</button></div>";
        }else if($publishexam_results->coeapproval == 1){
            $batch = $DB->get_field('cohort', 'name', array('id' => $urlparams->batch));
            $publish .= "<div id='publish_exam'>Results already submitted to Exam coordinator for <b>$batch</b></div>";

        }
        // print_object($url);exit;
       //  if($publishexam_results->coeapproval == 1){
       //      // print_object($publishexam_results);exit;
       //      $publish .= '<form method="get" onsubmit="return sendsmsValidate()">';
       //      $publish .= '<b class="application_done">Exam results published</b>&nbsp;&nbsp;&nbsp;';
        
       //  } else if($publishexam_results->coeapproval == 0){
       //      $publish .= '<form  method="get" onsubmit="return postexampublishValidate('.$params.')">';
       //      $publish .= '<b>Publish Exam: </b><input type="checkbox" name="publishexam" class ="postexampublish_checkbox">&nbsp;&nbsp;&nbsp;';
       //      $publish .= '&nbsp;<input type="submit" name="Publish" value="Publish" id ="examresults_submit"/>';
       //  }
       // // $search .= '<b>Roll Number:</b> <input type="text" name="serviceid" value="'.$serviceid.'" />';
       //  $publish .= '<input type="hidden" name="exam" value="'.$urlparams->exam.'" />';
       //  $publish .= '<input type="hidden" name="planid" value="'.$urlparams->planid.'" />';
       //  $publish .= '<input type="hidden" name="batch" value="'.$urlparams->batch.'" />';
       //  $publish .= '<input type="hidden" name="program" value="'.$urlparams->program.'" />';
        
       //  $publish .= '</form>';
        $publish .= '</div>';
        return $publish;
    }

    function students_applicationstatus($examid,$planid,$batchid){
        global $USER,$DB,$CFG,$OUTPUT,$PAGE;
        require_once($CFG->dirroot . '/local/examination/lib.php');
        $examination =New local_examination();
        $students = $examination->publishedexam_batch_students($examid,$batchid);
        //$students=$examination->batch_students($batchid,$planid);
        if(!empty($students)){
            $data =array();
            foreach($students as $key=>$student){
                $student->batchid = $DB->get_field('local_userdata','batchid',array('userid'=>$student->id));
                $list = array();
                $list[] = html_writer::tag('a', $student->firstname.' '.$student->lastname, array('href'=>$CFG->wwwroot.'/local/users/profile.php?id='.$student->id));;
                $list[] =$student->email;
                $list[] =$student->phone1;
                $studentappliedexam = $DB->get_record('local_examination_apply',array('batchid'=>$student->batchid,'examid'=>$examid,'studentid'=>$student->id));
                if(!empty($studentappliedexam)){
                    if((strtoupper($studentappliedexam->verified) == 'YES' || empty($studentappliedexam->reason)) && !empty($studentappliedexam->status)){
                        $list[] ='<span class = "application_done">Yes</span>';
                        $list[] =date("d M Y",$studentappliedexam->timecreated);
                        $list[] ='----';
                        $receiptnumber = $DB->get_record('local_examfee_receipt',array('batchid'=>$student->batchid,'examid'=>$examid,'studentid'=>$student->id,'status'=>1));
                        $ccsql = "SELECT cc.* FROM {local_fee_order} AS fo 
                                    JOIN {local_ccavenue} AS cc ON cc.order_id = fo.id AND cc.userid = fo.userid
                                   WHERE fo.userid = $student->id AND cc.order_status ='Success' AND fo.examid = $examid";
                        $payment = $DB->get_record_sql($ccsql,array());
                        if(empty($receiptnumber) && empty($payment)){
                            $list[] =  '----';
                            $list[] =  '----';
                        } else if(!empty($receiptnumber)){
                            $list[] ='<span class = "application_done">Yes</span>';
                            $list[] =$receiptnumber->chequenumber;
                        } else{
                            $list[] ='<span class = "application_done">Yes</span>';
                            $list[] =$payment->tracking_id; 
                        }
                        $list[] =$studentappliedexam->hallticketnumber;
                        $hallticket_download = $DB->get_records('local_hallticket_download',array('batchid'=>$student->batchid,'examid'=>$examid,'studentid'=>$student->id));
                        if(!empty($hallticket_download)){
                            $list[] = '<span class = "application_done">Yes</span>';
                        } else{
                            $list[] = '----';
                        }
                    } else{
                        $list[] = '<span class = "application_pending">No</span>';
                        $list[] = '----';
                        $list[] = $studentappliedexam->reason;
                        $list[] = '----';
                        $list[] = '----';
                        $list[] = '----';
                        $list[] = '----';
                    }
                } else{
                    $list[] = '<span class = "application_pending" >No</span>';
                    $list[] = '----';
                    $list[] = '----';
                    $list[] = '----';
                    $list[] = '----';
                    $list[] = '----';
                    $list[] = '----';
                }
               
                $localusers = $DB->get_record('local_users',array('userid'=>$student->id));
                if(!empty($localusers->hallticketitemid)){
                    $temp_file_url =$examination->get_attachedfiles_todownlload($student->id,$localusers->hallticketitemid);
                    $pic = '<img src="'.$temp_file_url.'" width="100" height="120"/>';
                } else if(!empty($studentappliedexam->picture)){
                    $temp_file_url =$examination->get_attachedfiles_todownlload($student->id,$studentappliedexam->picture);
                    $pic = '<img src="'.$temp_file_url.'" width="100" height="120"/>';
                } else{
                    $userrecord = $DB->get_record('user',array('id'=>$student->id));
                    $pic = $OUTPUT->user_picture($userrecord, array('courseid' => SITEID, 'size' => 64));
                }
                $uploadphoto = "<div class = 'student_photo_".$examid."_$student->id' style = 'display:none'>$pic</div>";
                $list[] ="<span class='hallticketphoto' onClick = 'StudentPhoto($examid,$student->id)'>Student Photo</span>".$uploadphoto;
                
                $url = new moodle_url('/local/examination/hallticketphoto.php', array('studentid'=>$student->id));
                $list[] = html_writer::tag('a', get_string('edithallticketphoto', 'local_examination'), array('href' => $url));
        
                $data[] = $list;
            }
            $studentname= get_string('student', 'local_examination');
            $email = get_string('email', 'local_examination');
            $phoneno= get_string('phone', 'local_examination');
            $applied= get_string('applied', 'local_examination');
            $date= get_string('applieddate', 'local_examination');
            $reason= get_string('reason', 'local_examination');
            $fee= get_string('fee', 'local_examination');
            $hallticket= get_string('hallticketnumber', 'local_examination');
            $receiptnumber = get_string('receiptnumber', 'local_examination');
            $download = get_string('hallticketdownload', 'local_examination');
            $hallticketphoto = get_string('hallticketphoto', 'local_examination');
            $edithallticketphoto = get_string('action', 'local_examination');
            
            $table = new html_table();
            $table->head = array($studentname,$email,$phoneno,$applied,$date,$reason,$fee,$receiptnumber,$hallticket,$download,$hallticketphoto,$edithallticketphoto);
            $table->align = array('left', 'left', 'left', 'left','center');
            $table->data = $data;
            $table->id = "students_applicationstatus";
            $output  = html_writer::table($table);
        } else{
            $output =  html_writer::tag('h4', get_string('studentsnotavailable', 'local_examination'), array());;
        }
        return $output;
    }

    function publishedresults(){
        global $DB;
        
    }

    function addstudentmarks_manualdisplay($subjects, $examid, $planid, $batchid, $subjectsin, $page, $perpage, $errors, $program,$studenttype=false, $exam_ceo=false, $publishpostexam=false){
        global $DB, $OUTPUT, $CFG;
        $examset = new local_examination_results();
        // $sql = "SELECT u.id, u.email, CONCAT(u.firstname, ' ', u.lastname) AS fullname, lu.serviceid as rollnumber
        //              FROM {user} u
        //              JOIN {local_manual_studentmarks} lmsm ON u.id = lmsm.studentid 
        //              JOIN {local_userdata} lu ON u.id = lu.userid
        //             WHERE lu.batchid = $batchid";
        
        // if($publishpostexam){
        // $sql = "SELECT u.id, u.email, CONCAT(u.firstname, ' ', u.lastname) AS fullname, lu.serviceid as rollnumber
        //              FROM {user} u
        //              JOIN {local_manual_studentmarks} lmsm ON u.id = lmsm.studentid 
        //              JOIN {local_userdata} lu ON u.id = lu.userid
        //             WHERE lu.batchid = $batchid AND lmsm.coeapproval = 1";
        // }else{
        $sql = "SELECT u.id, u.email, CONCAT(u.firstname, ' ', u.lastname) AS fullname, lu.serviceid as rollnumber
                     FROM {user} u
                     JOIN {local_userdata} lu ON u.id = lu.userid
                    WHERE lu.batchid = $batchid";    
        // }
        if($perpage && $perpage != -1){
            $sql .= " LIMIT $page, $perpage";
        }
        $users = $DB->get_records_sql($sql);
        // print_object($studenttype);
        // print_object($users);exit;
        if($studenttype){
            $users = $examset->studenttype_filter($subjects, $users, false, $studenttype, $examid, $planid, $batchid, $program);   
        }
        // $users = $examset->batch_students($batchid, $planid, false, $page * $perpage, $perpage, $studentname, $serviceid, $email,$examid);
        if(!empty($users)){
        $heads = array();
        // $exam = $DB->get_record('local_examcreation', array('id'=>$examid), '*', MUST_EXIST);
        if($exam_ceo){
            $heads = array("<input type='checkbox' name='check_user' value='$user->id' class='check_all_users'>Select all students");
        }
        $array2 = array(get_string('rollnumber', 'local_examination'),
                       get_string('studentname', 'local_examination'),
                       get_string('email', 'local_examination'));
        $heads = array_merge($heads,$array2);
        
        $data = array();
        $static = array();
        foreach($heads as $head){
            $cell = new html_table_cell();
            $cell->text = $head;
            $cell->rowspan = 5;
            $cell->attributes = array('class'=>'addmarkshead addmarkshead1');
            $static[] = $cell;
        }
        $data[] = $static;
        
        
        /*$data = array();*/
        $head1 = array();$head2 = array();$head3 = array();$head4 = array();
        foreach($subjects as $subject){
            //Heading1 to display the subjects scheduled
            $cell1 = new html_table_cell();
            $cell1->id  = $subject->id;
            $cell1->text = $subject->subject_name;
            $cell1->attributes = array('class'=>'addmarkshead addmarkshead1', 'marks_segregated'=>$subject->maxmarks_segregated,'total_maxmarks' => $subject->totalmaxmarks_subject);
            
            $coursespan = 1;
            $subjectcategorized = json_decode($subject->maxmarks_segregated);
            $childhead = array();
            foreach($subjectcategorized as $cat){
            $temp = explode('_',$cat);
            if(isset($childhead[$temp[0]])){
                $childhead[$temp[0]][] = $temp[1];
            }else{
                $childhead[$temp[0]][] = $temp[1];
            }
            }
            $subjecttotal_marks = 0;
            foreach($childhead as $key => $value){
                //Heading2, Type of exams either theory or practical
                $cell2 = new html_table_cell();
                $cell2->text = $key;
                $cell2->attributes = array('class'=>'addmarkshead addmarkshead2');
                
                $forcolspan = 1;
                foreach($value as $val){
                    $subheading3 = (explode(':',$val));
                    //This is the marks heading, One exam type is a sum of multiple marks
                    $cell3 = new html_table_cell();
                    $cell3->text = $subheading3[0];
                    $cell3->attributes = array('class'=>'addmarkshead addmarkshead3', 'subjectid'=>$subject->id, 'examtypeid'=>$key, 'markstypeid'=>$subheading3[0], 'maxmarks'=>$subheading3[1]);
                    
                    $cell4 = new html_table_cell();
                    $cell4->text = $subheading3[1];
                    $cell4->attributes = array('class'=>'addmarkshead addmarkshead4');
                    
                    $subjecttotal_marks += $subheading3[1];

                    $head3[] = $cell3;
                    $head4[] = $cell4;
                    
                    $forcolspan++;
                    $coursespan++;
                }
                $cell2->colspan = $forcolspan > 1 ? ($forcolspan -1) : $forcolspan;
                
                $head2[] = $cell2;
            }
            //$coursespan += sizeof($head3);
           
            $celltotal1 = new html_table_cell();
            $celltotal1->text = 'Total';
            $celltotal1->rowspan = 2;
            $celltotal1->attributes = array('class'=>'addmarkstotal addmarkstotal1');
            $head2[] = $celltotal1;
            
            $celltotal2 = new html_table_cell();
            $celltotal2->text = $subjecttotal_marks;
            $celltotal2->colspan = 1;
            $celltotal2->attributes = array('class'=>'addmarkstotal addmarkstotal2');
            $head4[] = $celltotal2;
            
            //$cell1->colspan = $coursespan > 1 ? ($coursespan -1) : $coursespan;
            $cell1->colspan = $coursespan;
            $head1[] = $cell1;
        }
        $data[] = $head1;
        $data[] = $head2;
        $data[] = $head3;
        $data[] = $head4;
        if(empty($head1)){ //No Subjects are scheduled for the selected records.. ;)
            return '';
        }
        //Table data itself displaying as the headings of the table, with rowspan and colspan.         
        $output = '';
        $output .= '<form action="" method="post">';
        $table = new html_table();
        $i = 1;
        // $users = batchusers($tool->batch);
        $userdata = array();
        foreach($users as $user){
            $line = array();
            //$line[] = $i;
            if($exam_ceo){
                $line[] = "<input type='checkbox' name='check_user[]' value='$user->id' class='check_allusers'>";
            }

            //We need hallticket here, change the
            $line[] = $user->rollnumber;
            
            $line[] = html_writer::tag('a', $user->fullname, array('href'=>$CFG->wwwroot.'/local/users/profile.php?id='.$user->id, 'target'=>'_blank'));
            $line[] = html_writer::tag('a', $user->email, array('href'=>'mailto:'.$user->email));
            foreach($head1 as $course){
                $subjectmarks = $examset->postexam_subjectmarks($course->id, $examid, $planid, $batchid, $user->id);
                $courseids = (object) $course->attributes;
                $subjectcategorized = json_decode($courseids->marks_segregated);
                $categorizedmarks = (array) json_decode($subjectmarks->individualmarks);
                $subjecttotal = 0;
                $j = 0;
                foreach($subjectcategorized as $cat){
                    $maxmarks = (explode(':',$cat)); 
                        $classname = 'subsubjectmarks_'.$course->id.'_'.$user->id;
                        $idname = 'subject_marks_'.$course->id.'_'.$user->id.'_'.$j;
                        $inputname = 'user['.$user->id.']['.$course->id.']';
                        $line[] = '<input type="text" class = "'.$classname.'" name="'.$inputname.'['.$maxmarks[0].']" value="'.$categorizedmarks[$maxmarks[0]].'" id= "'.$idname.'"size="5px" data-id_'.$j.' = "'.$maxmarks[1].'" onfocusout = "validatepostexammarks('.$maxmarks[1].', \''.$idname.'\',\''.$classname.'\','.$course->id.','.$user->id.')" onkeypress="return isNumberKey(event)"/>
                           ';
                        
                        $j++;
                }
                // $input_subjectname = 'subjecttotal_'.$course->id.'_'.$user->id;
                // $classname = 'subjecttotalmarks_'.$course->id.'_'.$user->id;
                $classname = 'user['.$user->id.']['.$course->id.']';
                $idname = 'user_'.$course->id.'_'.$user->id;
                $line[] = '<input type="text" name="'. $classname .'[totalmarks]" id = "'.$idname.'" value="'.$subjectmarks->totalmarks_gained.'" class="'.$course->text.'" data-id ="'.$user->id.'" data-c-id ="'.$course->id.'" size="5px" onkeypress="return isNumberKey(event)"/>'; //
            }
            // $userdata[$user->id] = $line;
            unset($subjectcategorized);
            // $userdata[$user->id] = $line;
            // print_object($line);exit;
            $data[] = $line;
            $i++;
        }
        $table->data = $data;
        $output .= '<div id="printablediv">';
        $output .= html_writer::table($table);
        $output .= '</div>';
        if($exam_ceo){
            $output .= '<input name="mail" value="sms" type="hidden">';
            $output .= '<div class="span12 sms-margin text-center"><span class="send_mail"><b>Notification Via </b><label style=color:red;>*</label>';
            $output .= '<input type="checkbox" name="smsid" id="smsid" class="attendsms">SMS</span>';
            $output .= '<span class="send_mail"><input type="checkbox" name="mailid" id="mailid" class="attendsms">Email</span></div>';
            // $output .= '<div class="span12 sms-margin text-center"><span class="send_mail"><b>Send Notification to </b><label style=color:red;>*</label><input type="checkbox" name="studentsmsid" id="studentsmsid" class="attendmail">Student</span>';
            // $output .= '<span class="send_mail"><input type="checkbox" name="parentsmsid" id="parentsmsid" class="attendmail">Parent</span></div>';
            $output .= '<div class="span12 text-center">Custom Message'.$OUTPUT->help_icon('sendattendance', 'local_attendance').' : <textarea name="message" rows="4" cols="50"></textarea></div>';
            $output .= '<input name="submit_message" value="Publish" type="submit" id="sendmail" class="Sendmail">';

        }
        $output .= '<div style="text-align: center;">';
        $output .= '<input type="hidden" name="submitstudentmarks" value="1" />';
        $output .= '<input type="hidden" name="exam" value="'.$examid.'" />';
        $output .= '<input type="hidden" name="planid" value="'.$planid.'" />';
        $output .= '<input type="hidden" name="batch" value="'.$batchid.'" />';
        $output .= '<input type="hidden" name="program" value="'.$program.'" />';
        $output .= '<input type="submit" name="submit" value="Save changes" />';
        $output .= '<input type="submit" name="submitandgonext" value="Save changes and go to next page" />';
        $output .= '</div>';
        $output .= '</form>';
        $output .= "<div style='text-align: center; margin-left: 120px;'>
                    <input type='submit' id='printpagebutton' value='Print'  onclick=\"printDiv('printablediv')\"/>
                </div>";
        
        // echo $output;exit;
        return $output;
    }else{
        return '<div class="alert alert-info" role="alert" style="margin-top:50px;text-align:center;" >
          No Students 
          </div></div>';
    }
    }

    /*---Results Tabs---------------*/   
    function tabs($currenttab,$examid = false,$planid = false,$batchid = false) {
        global $OUTPUT;
        $systemcontext = context_system::instance();
        $toprow = array();
        if ($currenttab) {
            if($examid >0 && $planid > 0 && $batchid > 0){
                $toprow[] = new tabobject('resultdetails', new moodle_url('/local/examination/results.php?name=string&exams='.$examid.'&planid='.$planid.'&batchs='.$batchid), get_string('results', 'local_examination'));
                $toprow[] = new tabobject('toppersdetails', new moodle_url('/local/examination/toppers_results.php?name=string&exams='.$examid.'&planid='.$planid.'&batchs='.$batchid), get_string('toppers', 'local_examination'));
                $toprow[] = new tabobject('atktdetails', new moodle_url('/local/examination/atkt_results.php?name=string&exams='.$examid.'&planid='.$planid.'&batchs='.$batchid), get_string('atkt', 'local_examination'));
                $toprow[] = new tabobject('faildetails', new moodle_url('/local/examination/fail_results.php?name=string&exams='.$examid.'&planid='.$planid.'&batchs='.$batchid), get_string('fail', 'local_examination'));    
            } else{
                $toprow[] = new tabobject('resultdetails', new moodle_url('/local/examination/results.php'), get_string('results', 'local_examination'));
                $toprow[] = new tabobject('toppersdetails', new moodle_url('/local/examination/toppers_results.php'), get_string('toppers', 'local_examination'));
                $toprow[] = new tabobject('atktdetails', new moodle_url('/local/examination/atkt_results.php'), get_string('atkt', 'local_examination'));
                $toprow[] = new tabobject('faildetails', new moodle_url('/local/examination/fail_results.php'), get_string('fail', 'local_examination'));    
            }
        }
       echo $OUTPUT->tabtree($toprow, $currenttab);
    }
    //Added by nitin
    function display_subjectwise_marks() {
        global $OUTPUT;
        $local_examination_results = new local_examination_results;
        $subjectwise_marks = $local_examination_results->get_subjectwise_marks();//$y;
        $final_subjectcolumns = $local_examination_results->get_final_subjectcolumns();//$z       
        $subjectwise_marks->head = array_merge($subjectwise_marks->head,$final_subjectcolumns->finalhead);//head merge
        $subjectwise_marks->head[] = 'Action';
        unset($subjectwise_marks->head['id']);
        unset($subjectwise_marks->head['semesterid']);
        $datatotalcount = count($subjectwise_marks->data);
        $finaltabledata = array();//$x
        for($i=0;$i<$datatotalcount;$i++) {
            $finaltabledata[] = array_merge($subjectwise_marks->data[$i] ,$final_subjectcolumns->tempdata[$i]);//data merge          
        }
        $finaldata2 = array();
        foreach ($finaltabledata as $finaldata) {
            $popup = $this->edit_subjectwise_marks($finaldata);
            $actions = array();
            $actions[] = html_writer::img($OUTPUT->pix_url('/t/edit'),'Edit', array('id' => $finaldata['id'],'title' => 'Edit' ,'onclick' => 'editsubject('.$finaldata['id'].')')).
            '  '.html_writer::img($OUTPUT->pix_url('/t/delete'),'Delete', array('id' => $finaldata['id'] ,'title' => 'Delete' ,'onclick' => 'deletesubject('.$finaldata['id'].')')).$popup;
            unset($finaldata['id']);  
            unset($finaldata['semesterid']);  
            $finaldata2[] = array_merge($finaldata,$actions);
        }   
        unset($subjectwise_marks->data);
        $subjectwise_marks->data = $finaldata2;
        $subjectwise_marks = html_writer::table($subjectwise_marks);
        return $subjectwise_marks;    
    }
    //added by nitin
    function edit_subjectwise_marks($subjectwisemarkdata) {
        global $CFG , $OUTPUT , $DB;
        $sid = $subjectwisemarkdata['id'] ;
        unset($subjectwisemarkdata['id']);
        unset($subjectwisemarkdata['semesterid']);
        $popup = "";
        $popup .= " <script type='text/javascript'>
                        $(document).ready(function() {
                            $('#subjectwisemarkspopup".$sid."').on('click', '#Cancel".$sid."', function () {
                               $('#subjectwisemarkspopup".$sid."').dialog('close');
                            });
                            $('#displaysubjectmarks tbody #subjectwisemarkspopup".$sid."').on('click', '#update".$sid."', function (e) {
                                e.preventDefault();
                                $.ajax({
                                    type: 'POST',
                                    url: $('.updatesubjectdata".$sid."').attr('action'),
                                    data: $('.updatesubjectdata".$sid."').serialize(),
                                    cache: true,
                                    success: function(data) {
                                        // alert(data); 
                                        location.reload()                              
                                    },
                                    error: function(xhr, status, error) {
                                        alert(status);
                                    }            
                                });  
                                return false;
                            });
                        });                            
                    </script> ";
        $popup .= " <div id='subjectwisemarkspopup".$sid."' style='display:none;'>";
        $actionpage = $CFG->wwwroot.'/local/examination/subjectmarksajax.php?edit='.$sid;
        $popup .= '<form name="subjectmarkform'.$sid.'" method="post" action="'.$actionpage.'" class="updatesubjectdata'.$sid.'">';
        
        $popup .= ' <label for="subjectname"><b>Subject Name: </b></label></br>
                    <input type = "text" name ="subjectname" value = "'.$subjectwisemarkdata['subject_name'].'" readonly autocomplete = "off"></br>';
        $popup .= ' <label for="examtype"><b>Exam Type: </b></label></br>
                    <input type = "text" name ="examtype" value = "'.$subjectwisemarkdata['examtype'].'" id ="examtype'.$sid.'"  required autocomplete = "off"></br>';
        $popup .= ' <label for="totalmaxmarks_subject"><b>Total Max Marks Subject: </b></label></br>
                    <input type = "text" name ="totalmaxmarks_subject" id = "totalmaxmarks_subject'.$sid.'" value = "'.$subjectwisemarkdata['totalmaxmarks_subject'].'" onkeypress="return isNumberKey(event)" required autocomplete = "off">
                    </br>';
        $popup .= ' <label for="totalminmarks_subject"><b>Total Min Marks Subject: </b></label></br>
                    <input type = "text" name ="totalminmarks_subject" id = "totalminmarks_subject'.$sid.'" value = "'.$subjectwisemarkdata['totalminmarks_subject'].'" onkeypress="return isNumberKey(event)" required autocomplete = "off">
                    </br>';
        $local_examination_results = new local_examination_results;
        $dynamic_subjectcolumns = $local_examination_results->dynamic_subjectcolumns($sid);
        foreach ($dynamic_subjectcolumns as $dynamic_subjectcolumn => $value) {
            $label = explode('_',$dynamic_subjectcolumn);
            $popup .= ' <label for="'.$dynamic_subjectcolumn.'"><b>'.ucfirst($label['0']).' '.ucfirst($label['1']).': </b></label></br>
                        <input type = "text" name ="marks['.$dynamic_subjectcolumn.']" value = "'.$value.'" id = "'.$dynamic_subjectcolumn.$sid.'" onkeypress="return isNumberKey(event)" required autocomplete = "off"></br>'; 
        }
        $popup .= '<input type = "submit" name ="upatemarks" value = "Update Marks" id="update'.$sid.'">';
        $popup .= '&nbsp;&nbsp;<input type = "reset"  value = "Cancel"  id="Cancel'.$sid.'" >';
        $popup .= '</form>';
        $popup .= '</div>';
        return $popup;
        
    }    
}

