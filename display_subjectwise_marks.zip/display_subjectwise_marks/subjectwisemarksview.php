<?php
require_once(dirname(__FILE__).'/../../config.php');
global $DB, $USER, $CFG,$PAGE,$OUTPUT;
$systemcontext = context_system::instance();
$PAGE->set_context($systemcontext);
$PAGE->set_pagelayout('admin');
$PAGE->set_url('/local/examination/subjectwisemarksview.php');
$PAGE->requires->jquery();
$PAGE->requires->js('/local/examination/js/jquery.dataTables.min.js',true);
$PAGE->requires->js('/local/examination/js/jsfunctions.js');
$PAGE->requires->css('/local/examination/css/datatable.min.css',true);
require_login();
$PAGE->navbar->add('subjectwisemarksview', new moodle_url($CFG->wwwroot . '/local/examination/subjectwisemarksview.php'));
$PAGE->set_heading('View Subject Wise Marks');
$PAGE->set_title('View Subject wise Marks');
echo $OUTPUT->header();
$renderer = $PAGE->get_renderer('local_examination');
$output = $renderer->display_subjectwise_marks();
$output .= '<div id="dialog-confirm" title="Are you Sure To Delete?" style = "display:none">
  <p><span class="ui-icon ui-icon-alert" style="float:left; margin:12px 12px 20px 0;"></span>This item will be permanently deleted and cannot be recovered. Are you sure?</p>
</div>';
echo $output;
echo $OUTPUT->footer();
